// Game engine: world generation, player, collisions, progression and rendering.
// Coordinates: world space with y growing DOWNWARD. Higher platforms have smaller y.
// The camera top (camTop) only ever moves upward, so the view follows the climb.
import { LOW_END, LOGICAL_W as W, LOGICAL_H as H, PHYS, HIT_COIN_LOSS, ZONES, PLATFORMS, ENEMIES, COLLECTIBLES, POWERUPS, CHARACTERS, OUTFITS, EFFECTS, stageInfo, bandFor, BOSS_EVERY_M } from './config.js';
import { stepPlayer, landedOn, playerHitRect, circleRectOverlap, clamp, lerp } from './physics.js';
import { makeRow, makeStartRow, zoneIndexFor } from './generator.js';
import { Pool, Fx } from './fx.js';
import { Assets } from './assets.js';
import { updateBoss, drawBoss } from './boss.js';
import { Sound } from './audio.js';

const START_Y = 820;          // world y of the starting platform
const VIEW_ANCHOR = 0.62;     // SpongeBob sits this far down the screen while climbing
const WORLD_BUFFER = 1300;    // generate this far above the camera
const CULL_BELOW = 260;       // remove objects this far below the screen
const BG_PARALLAX = 0.35;     // background scroll speed relative to the climb

export function computeMods(loadout) {
  const ch = CHARACTERS.find((c) => c.id === loadout.character) || CHARACTERS[0];
  const m = ch.mods || {};
  return {
    bounce: m.bounce || 1,
    accel: m.accel || 1,
    maxSpeed: m.maxSpeed || 1,
    coinMult: m.coinMult || 1,
    magnet: m.magnet || 1,
    extraChance: m.extraBounceChance || 0,
  };
}

function freshRun() {
  return {
    score: 0, heightScore: 0, metres: 0, coins: 0, itemPoints: 0, bounces: 0, bubbles: 0,
    tokens: 0, enemiesHit: 0, enemiesDefeated: 0, bossesDefeated: 0, premium: 0, powerups: {}, powerupsUsed: 0,
    revives: 0, reviveUsed: false, zoneMax: 1, startedAt: 0,
  };
}

export class Game {
  constructor(canvas, input, hooks = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.input = input;
    this.hooks = hooks;
    this.loadout = { character: 'spongebob', outfit: 'none', effect: 'bubbles' };
    this.mods = computeMods(this.loadout);
    this.settings = { reducedEffects: false, sensitivity: 1 };
    this.rng = Math.random;
    this.state = 'idle'; // idle | playing | paused | dying | over
    this.stage = stageInfo(1);

    this.fx = new Fx(240);
    this.platPool = new Pool(() => ({}));
    this.itemPool = new Pool(() => ({}));
    this.enemyPool = new Pool(() => ({}));
    this.platforms = [];
    this.items = [];
    this.enemies = [];
    this.decor = [];
    this.rockWarn = [];

    this.time = 0;
    this.timers = {};
    this.megaReady = false;
    this.coinGuard = 0;
    this.camTop = START_Y - H * VIEW_ANCHOR;
    this.minY = START_Y;
    this.lastRow = null;
    this.p = this.makePlayer(START_Y);
    this.run = freshRun();
    this.lastZone = 0;
    this.bgFade = null;
    this.banner = null;
    this.rockTimer = 0;
    this.dyingT = 0;
    this.shake = 0;
    this.trailT = 0;
  }

  // ---------- setup -------------------------------------------------------

  makePlayer(y) {
    return { x: W / 2, y, prevY: y, vx: 0, vy: -PHYS.jumpVel, squash: 0, invuln: 0, hurtT: 0, landT: 0, dead: false };
  }

  setLoadout(l) {
    this.loadout = { ...this.loadout, ...l };
    this.mods = computeMods(this.loadout);
  }

  setSettings(s) {
    this.settings = { ...this.settings, ...s };
    this.fx.reduced = !!this.settings.reducedEffects;
  }

  emit(name, ...args) {
    const fn = this.hooks[name];
    if (!fn) return;
    try { fn(...args); } catch (e) { console.error(e); }
  }

  clearWorld() {
    for (const pl of this.platforms) this.platPool.put(pl);
    for (const it of this.items) this.itemPool.put(it);
    for (const e of this.enemies) this.enemyPool.put(e);
    this.platforms.length = 0;
    this.items.length = 0;
    this.enemies.length = 0;
    this.decor.length = 0;
    this.rockWarn.length = 0;
    this.boss = null;
    this.nextBossM = BOSS_EVERY_M;
    this.fx.clear();
  }

  // ---------- run lifecycle -----------------------------------------------

  start() {
    this.clearWorld();
    this.run = freshRun();
    this.run.startedAt = performance.now();
    this.p = this.makePlayer(START_Y);
    this.camTop = START_Y - H * VIEW_ANCHOR;
    this.minY = START_Y;
    this.coinGuard = 0;
    this.timers = {};
    this.megaReady = false;
    this.lastZone = 0;
    this.bgFade = null;
    this.banner = this.stage
      ? { text: this.stage.worldName, sub: `WORLD ${this.stage.world}`, t: 2.6 }
      : { text: ZONES[0].name, sub: ZONES[0].subtitle, t: 2.6 };
    this.rockTimer = 2.5;
    this.dyingT = 0;
    this.shake = 0;
    this.trailT = 0;
    this.trailSprites = [];
    this.boss = null;
    this.nextBossM = BOSS_EVERY_M;
    const row0 = makeStartRow(START_Y);
    this.spawnRow(row0, true);
    this.lastRow = row0;
    this.extendWorld();
    this.state = 'playing';
    this.input.setEnabled(true);
    Sound.startMusic(0);
  }

  pause() {
    if (this.state !== 'playing') return false;
    this.state = 'paused';
    this.input.setEnabled(false);
    Sound.duck(true);
    return true;
  }

  resume() {
    if (this.state !== 'paused') return false;
    this.state = 'playing';
    this.input.setEnabled(true);
    Sound.duck(false);
    return true;
  }

  quit() {
    this.state = 'idle';
    this.input.setEnabled(false);
    Sound.stopMusic();
    Sound.duck(false);
    this.clearWorld();
  }

  /** Revive once per run. Places SpongeBob on a visible platform with a short grace period. */
  revive() {
    if (this.run.reviveUsed) return false;
    if (this.state !== 'over' && this.state !== 'dying') return false;
    this.run.reviveUsed = true;
    this.run.revives++;
    Sound.play('revive');
    const p = this.p;
    const targetY = this.camTop + H * 0.6;
    let best = null;
    let bestD = Infinity;
    for (const pl of this.platforms) {
      if (pl.broken || pl.dead || pl.falling || pl.kind === 'breakable') continue;
      if (pl.y < this.camTop + 140 || pl.y > this.camTop + H - 120) continue;
      const d = Math.abs(pl.y - targetY);
      if (d < bestD) { bestD = d; best = pl; }
    }
    if (best) {
      p.x = clamp(best.x, 24, W - 24);
      p.y = best.y;
      p.vy = -PHYS.jumpVel;
    } else {
      p.y = targetY;
      p.vy = -PHYS.jumpVel * 1.2;
    }
    p.vx = 0;
    p.prevY = p.y;
    p.invuln = 2.5;
    p.hurtT = 0;
    p.dead = false;
    p.squash = 0;
    this.dyingT = 0;
    this.state = 'playing';
    this.input.setEnabled(true);
    Sound.startMusic(this.stage ? this.stage.world : 1);
    Sound.duck(false);
    this.fx.text(p.x, p.y - 140, 'REVIVED!', '#ffd23f', 30);
    return true;
  }

  // ---------- world generation --------------------------------------------

  spawnRow(row, isStart) {
    const def = PLATFORMS[row.kind] || PLATFORMS.normal;
    const img = Assets.get(def.sprite);
    const h = img ? def.w * img.height / img.width : def.w * 0.4;
    const pl = this.platPool.get();
    pl.kind = row.kind;
    pl.x = row.x;
    pl.baseX = row.x;
    pl.y = row.y;
    pl.w = def.w;
    pl.h = h;
    pl.amp = row.amp || 0;
    pl.speed = row.speed || 0;
    pl.t = 0;
    pl.mult = def.mult || 1;
    pl.coins = def.coins || 0;
    pl.sprite = def.sprite;
    pl.broken = false;
    pl.breakT = 0;
    pl.ice = !!def.ice;
    pl.vanish = !!def.vanish;
    pl.vanishT = 0;
    pl.respawnT = 0;
    pl.hidden = false;
    pl.falling = false;
    pl.vy = 0;
    pl.dead = false;
    this.platforms.push(pl);
    if (!isStart) for (const it of row.items) this.spawnItem(it);
  }

  spawnItem(it) {
    if (it.cat === 'deco') {
      this.decor.push({ x: it.x, y: it.y, s: it.s || 1, sprite: 'deco_tiki' });
      return;
    }
    if (it.cat === 'enemy') {
      const def = ENEMIES[it.type];
      if (!def) return;
      const e = this.enemyPool.get();
      e.type = it.type;
      e.x = it.x; e.y = it.y;
      e.baseX = it.x; e.baseY = it.y;
      e.t = it.phase || 0;
      const room = Math.min(e.baseX - 24, W - 24 - e.baseX);
      const maxAmp = it.type === 'mine' ? 110 : 150;
      e.amp = clamp(room, 0, maxAmp);
      e.r = def.r; e.w = def.w; e.sprite = def.sprite;
      e.vy = 0; e.dead = false;
      this.enemies.push(e);
      return;
    }
    const i = this.itemPool.get();
    i.cat = it.cat;
    i.type = it.type;
    i.x = it.x; i.y = it.y;
    i.t = Math.random() * 6;
    i.dead = false;
    if (it.cat === 'power') {
      const pdef = POWERUPS[it.type];
      if (!pdef) return;
      i.r = 26; i.w = 50; i.sprite = pdef.sprite; i.color = pdef.color;
    } else {
      const def = COLLECTIBLES[it.type];
      if (!def) return;
      i.r = def.r; i.w = def.w; i.sprite = def.sprite; i.color = null;
    }
    this.items.push(i);
  }

  extendWorld() {
    let guard = 0;
    while (this.lastRow.y > this.camTop - WORLD_BUFFER && guard++ < 80) {
      const metres = Math.max(0, (START_Y - this.lastRow.y) / 10);
      const zi = zoneIndexFor(metres);
      const row = makeRow(this.lastRow, metres, this.rng, zi, this.stage);
      this.spawnRow(row, false);
      this.lastRow = row;
    }
  }

  spawnRock(x) {
    const def = ENEMIES.rock;
    const e = this.enemyPool.get();
    e.type = 'rock';
    e.x = x; e.y = this.camTop - 60;
    e.baseX = x; e.baseY = e.y;
    e.t = 0; e.amp = 0;
    e.r = def.r; e.w = def.w; e.sprite = def.sprite;
    e.vy = 280; e.dead = false;
    this.enemies.push(e);
  }

  // ---------- per-frame update --------------------------------------------

  update(dt) {
    if (this.state === 'playing') this.tick(dt);
    else if (this.state === 'dying') this.tickDying(dt);
    this.fx.update(dt);
    if (dt > 0) {
      this.time += dt;
      if (this.banner) {
        this.banner.t -= dt;
        if (this.banner.t <= 0) this.banner = null;
      }
      if (this.bgFade) {
        this.bgFade.t += dt / 1.6;
        if (this.bgFade.t >= 1) this.bgFade = null;
      }
      if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 2);
    }
  }

  tick(dt) {
    dt = Math.min(dt, 1 / 30);
    const p = this.p;

    for (const k in this.timers) {
      this.timers[k] -= dt;
      if (this.timers[k] <= 0) delete this.timers[k];
    }
    const slow = this.timers.slowmo ? 0.5 : 1;
    if (this.timers.speed && !this.settings.reducedEffects && Math.abs(p.vx) > 120 && Math.random() < 0.5) {
      this.fx.burst(p.x - Math.sign(p.vx) * 22, p.y - 30, 1, { color: '#7CFF6B', speed: 30, life: 0.3, size: 4, shape: 'spark' });
    }
    const dir = this.input.dir();
    const speedMul = this.timers.speed ? 1.5 : 1;
    const onIce = (this.p.iceT || 0) > 0;
    if (onIce) this.p.iceT -= dt;
    const m = { maxSpeed: this.mods.maxSpeed * speedMul, accel: this.mods.accel * this.settings.sensitivity, grip: onIce ? 0.45 : 1 };

    // physics in small sub-steps so fast falls never skip a platform
    const steps = Math.max(1, Math.ceil(dt * 120));
    const sdt = dt / steps;
    for (let s = 0; s < steps; s++) {
      stepPlayer(p, sdt, dir, m);
      if (p.vy > 0) this.checkLanding();
    }

    p.invuln = Math.max(0, p.invuln - dt);
    p.hurtT = Math.max(0, p.hurtT - dt);
    p.squash = Math.max(0, p.squash - dt * 5);
    p.landT = Math.max(0, p.landT - dt);
    this.minY = Math.min(this.minY, p.y);

    this.updatePlatforms(dt, slow);
    this.updateEnemies(dt, slow);
    this.updateRocks(dt);
    this.updateItems(dt);
    this.checkHazards();
    updateBoss(this, dt);
    if (this.state !== 'playing') return;

    this.updateCamera(dt);
    this.extendWorld();
    this.cull();
    this.updateProgress();
    if (p.y > this.camTop + H + 70) {
      this.die(true);
      return;
    }
    this.updateTrailSprites(dt);
    this.emitTrail(dt);
  }

  checkLanding() {
    const p = this.p;
    for (let i = 0; i < this.platforms.length; i++) {
      const pl = this.platforms[i];
      if (!pl.hidden && landedOn(p, pl)) {
        this.land(pl);
        return;
      }
    }
  }

  land(pl) {
    const p = this.p;
    p.y = pl.y; // snap to the surface
    p.iceT = pl.ice ? 1.6 : 0;
    let mult = pl.mult;
    if (this.timers.superBounce) mult *= 1.3;
    if (this.megaReady) {
      this.megaReady = false;
      mult *= 1.5;
      this.fx.burst(p.x, p.y, 26, { color: '#ffd23f', speed: 260, life: 0.8, size: 5, shape: 'spark' });
      this.fx.text(p.x, p.y - 130, 'MEGA BOUNCE!', '#ff4da6', 28);
      Sound.play('mega');
    }
    mult *= this.mods.bounce;
    if (this.mods.extraChance > 0 && Math.random() < this.mods.extraChance) {
      mult *= 1.12;
      this.fx.text(p.x, p.y - 90, 'EXTRA BOUNCE', '#9be15d', 20);
      Sound.play('extra');
    }
    mult = Math.min(mult, 2.1);
    p.vy = -PHYS.jumpVel * mult;
    p.squash = 1;
    p.landT = 0.12;

    if (pl.vanish) pl.vanishT = 1.2; // fades out after a short moment
    if (pl.kind === 'breakable' && pl.breakT <= 0) {
      pl.breakT = 0.45;
      Sound.play('crack');
    }
    if (pl.coins) {
      this.addCoins(pl.coins, p.x, p.y - 40);
      this.fx.text(p.x, p.y - 70, 'JELLY POP!', '#ff9ce6', 20);
    }
    this.fx.burst(p.x, p.y, 7, { color: '#fff6c8', speed: 110, life: 0.4, size: 3, up: -30 });
    Sound.play('land');
    Sound.play('jump');
    this.run.bounces++;
    this.emit('onBounce');
  }

  updatePlatforms(dt, slow) {
    for (let i = 0; i < this.platforms.length; i++) {
      const pl = this.platforms[i];
      if (pl.dead) continue;
      if (pl.falling) {
        pl.vy += 1200 * dt;
        pl.y += pl.vy * dt;
        if (pl.y > this.camTop + H + 200) pl.dead = true;
        continue;
      }
      if (pl.vanish) {
        if (pl.hidden) {
          pl.respawnT -= dt;
          if (pl.respawnT <= 0) { pl.hidden = false; pl.vanishT = 0; }
        } else if (pl.vanishT > 0) {
          pl.vanishT -= dt;
          if (pl.vanishT <= 0) { pl.hidden = true; pl.respawnT = 1.8; this.fx.burst(pl.x, pl.y, 8, { color: '#bfefff', speed: 80, life: 0.5, size: 3 }); }
        }
      }
      if (pl.kind === 'moving') {
        pl.t += dt * slow;
        pl.x = pl.baseX + Math.sin(pl.t * pl.speed) * pl.amp;
      }
      if (pl.breakT > 0) {
        pl.breakT -= dt;
        if (pl.breakT <= 0) {
          pl.breakT = 0;
          pl.broken = true;
          pl.falling = true;
          pl.vy = 0;
          this.fx.burst(pl.x, pl.y, 10, { color: '#c4612b', speed: 120, life: 0.6, size: 4, g: 900 });
        }
      }
    }
  }

  updateEnemies(dt, slow) {
    for (let i = 0; i < this.enemies.length; i++) {
      const e = this.enemies[i];
      if (e.dead) continue;
      e.t += dt * slow;
      switch (e.type) {
        case 'jelly':
          e.y = e.baseY + Math.sin(e.t * 2.6) * 18;
          e.x = e.baseX + Math.sin(e.t * 0.8) * Math.min(10, e.amp);
          break;
        case 'fastJelly':
          e.x = e.baseX + Math.sin(e.t * 1.7) * e.amp;
          e.y = e.baseY + Math.sin(e.t * 3.1) * 10;
          break;
        case 'urchin':
          e.x = e.baseX + Math.sin(e.t * 0.9) * Math.min(24, e.amp);
          e.y = e.baseY;
          break;
        case 'largeJelly':
          e.y = e.baseY + Math.sin(e.t * 1.3) * 34;
          e.x = e.baseX + Math.sin(e.t * 0.6) * Math.min(40, e.amp);
          break;
        case 'mine':
          e.x = e.baseX + Math.sin(e.t * 1.1) * e.amp;
          e.y = e.baseY;
          break;
        case 'bubble':
          e.baseY -= 36 * dt * slow;
          e.y = e.baseY;
          e.x = e.baseX + Math.sin(e.t * 2.2) * 16;
          if (e.y < this.camTop - 120) e.dead = true;
          break;
        case 'rock':
          e.vy += 60 * dt;
          e.y += e.vy * dt * slow;
          if (e.y > this.camTop + H + 120) e.dead = true;
          break;
        default:
          break;
      }
    }
  }

  updateRocks(dt) {
    const metres = this.run.metres;
    if (metres < ENEMIES.rock.minM) return;
    for (let i = this.rockWarn.length - 1; i >= 0; i--) {
      const w = this.rockWarn[i];
      w.t -= dt;
      if (w.t <= 0) {
        this.rockWarn.splice(i, 1);
        this.spawnRock(w.x);
      }
    }
    this.rockTimer -= dt;
    if (this.rockTimer <= 0) {
      const extra = clamp((metres - ENEMIES.rock.minM) / 600, 0, 1);
      this.rockTimer = lerp(2.6, 1.5, extra) * (0.8 + Math.random() * 0.4);
      const x = 40 + Math.random() * (W - 80);
      this.rockWarn.push({ x, t: 1.1 });
      Sound.play('warn');
    }
  }

  updateItems(dt) {
    const p = this.p;
    const box = playerHitRect(p);
    const magnetOn = !!this.timers.magnet;
    const R = 200 * this.mods.magnet;
    for (let i = 0; i < this.items.length; i++) {
      const it = this.items[i];
      if (it.dead) continue;
      it.t += dt;
      if (magnetOn && (it.cat === 'coin' || it.cat === 'bonus')) {
        const dx = p.x - it.x;
        const dy = (p.y - 40) - it.y;
        const d = Math.hypot(dx, dy);
        if (d < R && d > 0.1) {
          const step = Math.min(d, 560 * dt);
          it.x += dx / d * step;
          it.y += dy / d * step;
        }
      }
      if (circleRectOverlap(it.x, it.y, it.r, box.x0, box.y0, box.x1, box.y1)) this.collect(it);
    }
  }

  collect(it) {
    it.dead = true;
    if (it.cat === 'power') {
      this.applyPower(it.type, it.x, it.y);
      return;
    }
    const def = COLLECTIBLES[it.type];
    if (!def) return;
    if (it.type === 'token') {
      this.run.tokens++;
      this.emit('onToken');
    }
    if (def.coins) {
      const coins = Math.round(def.coins * this.mods.coinMult * (this.timers.double ? 2 : 1));
      this.addCoins(coins);
      if (coins >= 5) this.fx.text(it.x, it.y - 20, '+' + coins, '#ffe066', 20);
    }
    this.run.itemPoints += def.points;
    if (def.premium) {
      this.run.premium += def.premium;
      this.emit('onPremium', def.premium);
      this.fx.text(it.x, it.y - 26, `+${def.premium} SPATULA`, '#ffd23f', 20);
    }
    if (def.bubble) {
      this.run.bubbles++;
      this.emit('onBubble');
      this.fx.burst(it.x, it.y, 10, { color: '#bfefff', shape: 'bubble', speed: 90, life: 0.5, size: 6 });
      Sound.play('pop');
    } else if (it.type === 'coin') {
      this.fx.burst(it.x, it.y, 8, { color: '#ffe066', shape: 'spark', speed: 150, life: 0.45, size: 4 });
      Sound.play('coin');
    } else if (it.type === 'treasure') {
      this.fx.burst(it.x, it.y, 26, { color: '#ffd23f', speed: 220, life: 0.9, size: 5, shape: 'spark' });
      this.fx.text(it.x, it.y - 50, 'TREASURE!', '#ffd23f', 26);
      Sound.play('treasure');
    } else {
      this.fx.burst(it.x, it.y, 14, { color: '#fff6c8', speed: 170, life: 0.6, size: 4, shape: 'spark' });
      Sound.play('pickup');
    }
  }

  addCoins(n, x, y) {
    if (n <= 0) return;
    this.run.coins += n;
    this.emit('onCoins', n);
  }

  applyPower(type, x, y) {
    const def = POWERUPS[type];
    if (!def) return;
    this.run.powerups[type] = (this.run.powerups[type] || 0) + 1;
    this.run.powerupsUsed++;
    this.emit('onPowerup', type);
    Sound.play('powerup');
    if (type === 'coinGuard') {
      this.coinGuard++;
      this.fx.text(x, y - 30, 'COINS SAFE', '#ff6b6b', 24);
    } else if (type === 'superBounce') {
      this.timers.superBounce = def.duration;
      // springy launch so the activation is felt immediately
      this.p.vy = Math.min(this.p.vy, -PHYS.jumpVel * 1.0);
      this.p.squash = 1;
      this.fx.text(x, y - 30, 'SUPER BOUNCE!', def.color, 22);
      this.fx.burst(this.p.x, this.p.y, 22, { color: '#ffd23f', speed: 260, life: 0.7, size: 6, shape: 'spark' });
      Sound.play('bounce');
    } else if (type === 'megaBounce') {
      this.megaReady = true;
      this.fx.text(x, y - 30, 'MEGA BOUNCE READY!', '#ff4da6', 22);
    } else {
      this.timers[type] = def.duration;
      this.fx.text(x, y - 30, def.name.toUpperCase(), def.color, 20);
    }
    this.fx.burst(x, y, 20, { color: def.color, speed: 200, life: 0.7, size: 5, shape: 'spark' });
  }

  checkHazards() {
    const p = this.p;
    const box = playerHitRect(p);
    for (let i = 0; i < this.enemies.length; i++) {
      const e = this.enemies[i];
      if (e.dead) continue;
      if (!circleRectOverlap(e.x, e.y, e.r, box.x0, box.y0, box.x1, box.y1)) continue;
      // jumping onto a stompable enemy defeats it and bounces the player up
      if (ENEMIES[e.type] && ENEMIES[e.type].stompable && p.vy > 0 && p.prevY - PHYS.hitBottom <= e.y - e.r * 0.25) {
        this.stompEnemy(e);
        return;
      }
      if (p.invuln > 0) continue;
      if (this.timers.shield) {
        delete this.timers.shield;
        e.dead = true;
        p.invuln = 1.2;
        p.vy = -620;
        this.fx.burst(e.x, e.y, 16, { color: '#7fe7ff', shape: 'bubble', speed: 160, life: 0.6, size: 9 });
        this.fx.text(p.x, p.y - 110, 'POP!', '#7fe7ff', 24);
        Sound.play('shield');
        return;
      }
      this.hurt(e);
      return;
    }
  }

  stompEnemy(e) {
    const p = this.p;
    e.dead = true;
    p.vy = -PHYS.jumpVel * 0.8;
    p.squash = 1;
    this.run.enemiesDefeated++;
    this.run.itemPoints += 25;
    this.emit('onDefeat');
    this.fx.burst(e.x, e.y, 14, { color: '#fff08a', speed: 170, life: 0.5, size: 6 });
    this.fx.text(e.x, e.y - 30, '+25', '#fff08a', 22);
    Sound.play('stomp');
  }

  hurt() {
    const p = this.p;
    this.run.enemiesHit++;
    this.emit('onHit');
    p.invuln = PHYS.invulnTime;
    p.hurtT = 0.7;
    p.vy = -560;
    p.vx = (p.x < W / 2 ? 1 : -1) * 160;
    this.shake = 0.35;
    this.fx.burst(p.x, p.y - 50, 18, { color: '#ff6b6b', speed: 200, life: 0.6, size: 5 });
    Sound.play('hurt');
    // a Coin Guard absorbs the hit completely
    if (this.coinGuard > 0) {
      this.coinGuard--;
      this.fx.text(p.x, p.y - 120, 'COINS SAFE', '#7fe7ff', 24);
      return;
    }
    // nothing left to lose: the run ends
    if (this.run.coins <= 0) {
      this.die(false);
      return;
    }
    const lost = Math.min(this.run.coins, Math.ceil(this.run.coins * HIT_COIN_LOSS));
    this.run.coins -= lost;
    this.emit('onCoinsLost', lost);
    this.fx.text(p.x, p.y - 120, `-${lost} COINS`, '#ff6b6b', 24);
  }

  die(fell) {
    if (this.state !== 'playing') return;
    this.state = 'dying';
    this.dyingT = fell ? 0.3 : 1.0;
    this.p.dead = true;
    this.p.vx *= 0.3;
    if (!fell) this.p.vy = Math.min(this.p.vy, -300);
    this.input.setEnabled(false);
    Sound.stopMusic();
  }

  tickDying(dt) {
    const p = this.p;
    p.vy = Math.min(p.vy + PHYS.gravity * dt, PHYS.maxFall);
    p.y += p.vy * dt;
    p.x += p.vx * dt;
    p.vx *= 0.98;
    p.hurtT = 1;
    this.dyingT -= dt;
    if (this.dyingT <= 0) {
      this.state = 'over';
      this.emit('onGameOver', this.summary());
    }
  }

  updateCamera(dt) {
    const target = this.p.y - H * VIEW_ANCHOR;
    if (target < this.camTop) {
      this.camTop += (target - this.camTop) * (1 - Math.exp(-dt * 6));
    }
  }

  cull() {
    const bottom = this.camTop + H + CULL_BELOW;
    for (let i = this.platforms.length - 1; i >= 0; i--) {
      const pl = this.platforms[i];
      if (pl.dead || pl.y > bottom) {
        this.platforms[i] = this.platforms[this.platforms.length - 1];
        this.platforms.pop();
        this.platPool.put(pl);
      }
    }
    for (let i = this.items.length - 1; i >= 0; i--) {
      const it = this.items[i];
      if (it.dead || it.y > bottom) {
        this.items[i] = this.items[this.items.length - 1];
        this.items.pop();
        this.itemPool.put(it);
      }
    }
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.dead || e.y > bottom + 200 || e.y < this.camTop - 900) {
        this.enemies[i] = this.enemies[this.enemies.length - 1];
        this.enemies.pop();
        this.enemyPool.put(e);
      }
    }
    for (let i = this.decor.length - 1; i >= 0; i--) {
      const d = this.decor[i];
      if (d.y > bottom + 100 || d.y < this.camTop - 900) this.decor.splice(i, 1);
    }
  }

  updateProgress() {
    const metres = Math.max(0, Math.floor((START_Y - this.minY) / 10));
    if (metres > this.run.metres) {
      // height points grow per zone, so higher climbs are worth more
      const gained = metres - this.run.metres;
      this.run.heightScore += gained * (1 + 0.25 * zoneIndexFor(this.run.metres));
      this.run.metres = metres;
    }
    const zi = zoneIndexFor(this.run.metres);
    if (zi !== this.lastZone) {
      const z = ZONES[zi];
      this.lastZone = zi;
      this.bgFade = { t: 0 };
      this.banner = { text: z.name, sub: z.subtitle, t: 2.6 };
      this.run.zoneMax = Math.max(this.run.zoneMax, zi + 1);
      this.emit('onZone', zi);
    }
    this.run.score = Math.floor(this.run.heightScore) + this.run.itemPoints;

    // endless run: crossing a height band changes the background and, at a world boundary, the name
    const band = bandFor(this.run.metres);
    if (this.stage && band !== this.stage.n) {
      const prevBand = this.stage.n;
      const prevWorld = this.stage.world;
      this.setStage(stageInfo(band));
      this.prevBand = prevBand;
      this.bgFade = { t: 0 };
      if (this.stage.world !== prevWorld) {
        this.banner = { text: this.stage.worldName, sub: `WORLD ${this.stage.world}`, label: `WORLD ${this.stage.world}`, t: 2.6 };
        Sound.setWorld(this.stage.world);
      }
      this.emit('onBand', band);
    }
  }

  setStage(info) {
    this.stage = info;
  }


  /** Adds one piece of effect art to the trail. Capped so long runs stay light. */
  spawnTrailSprite(name, x, y) {
    const img = Assets.get(name);
    if (!img) return false;
    if (!this.trailSprites) this.trailSprites = [];
    if (this.trailSprites.length >= 14) this.trailSprites.shift();
    const w = this.settings.reducedEffects ? 30 : 40;
    this.trailSprites.push({ img, x: x + (Math.random() - 0.5) * 16, y, w, h: w * img.height / img.width, t: 0, life: 0.7 });
    return true;
  }

  updateTrailSprites(dt) {
    const arr = this.trailSprites;
    if (!arr || !arr.length) return;
    for (let i = arr.length - 1; i >= 0; i--) {
      const q = arr[i];
      q.t += dt;
      q.y -= 24 * dt;
      if (q.t >= q.life) arr.splice(i, 1);
    }
  }

  drawTrailSprites() {
    const arr = this.trailSprites;
    if (!arr || !arr.length) return;
    const ctx = this.ctx;
    for (const q of arr) {
      const sy = q.y - this.camTop;
      if (sy < -80 || sy > H + 80) continue;
      ctx.globalAlpha = Math.max(0, 1 - q.t / q.life);
      ctx.drawImage(q.img, q.x - q.w / 2, sy - q.h / 2, q.w, q.h);
    }
    ctx.globalAlpha = 1;
  }

  emitTrail(dt) {
    this.trailT -= dt;
    if (this.trailT > 0) return;
    this.trailT = this.settings.reducedEffects ? 0.16 : 0.07;
    const eff = EFFECTS.find((e) => e.id === this.loadout.effect) || EFFECTS[0];
    const p = this.p;
    if (eff.sprite && this.spawnTrailSprite(eff.sprite, p.x, p.y - 30)) return;
    const col = eff.color === 'rainbow' ? `hsl(${(this.time * 200) % 360}, 90%, 70%)` : eff.color;
    if (eff.id === 'bubbles') {
      this.fx.burst(p.x + (Math.random() - 0.5) * 20, p.y - 20, 1, { color: col, shape: 'bubble', speed: 30, up: -60, life: 0.8, size: 5 });
    } else if (eff.id === 'sparkle') {
      this.fx.burst(p.x, p.y - 30, 1, { color: col, shape: 'spark', speed: 60, life: 0.5, size: 4 });
    } else {
      this.fx.burst(p.x, p.y - 30, 1, { color: col, speed: 80, life: 0.5, size: 3 });
    }
  }

  // ---------- data for UI --------------------------------------------------

  summary() {
    const r = this.run;
    return {
      score: r.score,
      metres: r.metres,
      coins: r.coins,
      tokens: r.tokens,
      premium: r.premium,
      bubbles: r.bubbles,
      bounces: r.bounces,
      zone: this.lastZone + 1,
      zoneMax: r.zoneMax,
      revives: r.revives,
      reviveUsed: r.reviveUsed,
      enemiesHit: r.enemiesHit,
      enemiesDefeated: r.enemiesDefeated,
      bossesDefeated: r.bossesDefeated,
      powerupsUsed: r.powerupsUsed,
      duration: Math.max(0, (performance.now() - r.startedAt) / 1000),
    };
  }

  hud() {
    const timers = [];
    for (const key of Object.keys(this.timers)) {
      const def = POWERUPS[key];
      if (!def) continue;
      timers.push({ key, name: def.name, color: def.color, remaining: this.timers[key], max: def.duration });
    }
    if (this.megaReady) timers.push({ key: 'megaBounce', name: 'Mega Bounce ready', color: '#ff4da6', remaining: 1, max: 1 });
    return {
      score: this.run.score,
      metres: this.run.metres,
      coins: this.run.coins,
      zone: this.stage ? this.stage.worldName : ZONES[this.lastZone].name,
      timers,
    };
  }

  // ---------- rendering ----------------------------------------------------

  render() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, W, H);
    if (this.state === 'idle') return;

    // low-end devices redraw the full-screen backdrop every other frame (it scrolls slowly)
    if (!LOW_END || (this.bgFrame = !this.bgFrame)) this.renderBackground();

    ctx.save();
    if (this.shake > 0) {
      ctx.translate((Math.random() - 0.5) * 14 * this.shake, (Math.random() - 0.5) * 14 * this.shake);
    }
    this.drawDecor();
    this.drawPlatforms();
    this.drawItems();
    this.drawEnemies();
    drawBoss(this);
    this.drawTrailSprites();
    this.drawPlayer();
    this.fx.draw(ctx, this.camTop);
    this.drawRockWarnings();
    ctx.restore();

    this.drawBanner();
    if (this.state === 'dying' || this.state === 'over') {
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      ctx.fillRect(0, 0, W, H);
    }
  }

  /** Sets the full-screen backdrop canvas and its matrix (logical 540x960 space to screen pixels). */
  setBackdrop(canvas, matrix) {
    this.bgCanvas = canvas;
    this.bgCtx = canvas ? canvas.getContext('2d') : null;
    this.bgM = matrix;
  }

  /** Draws the environment on the full-screen backdrop, behind the playfield canvas. */
  renderBackground() {
    const bg = this.bgCtx;
    if (!bg || !this.bgM) return;
    const prev = this.ctx;
    this.ctx = bg;
    bg.setTransform(1, 0, 0, 1, 0, 0);
    bg.clearRect(0, 0, this.bgCanvas.width, this.bgCanvas.height);
    bg.setTransform(this.bgM[0], this.bgM[1], this.bgM[2], this.bgM[3], this.bgM[4], this.bgM[5]);
    this.drawBackground();
    bg.globalAlpha = 1;
    this.ctx = prev;
  }

  /** Asset key of the environment tile for a height band (bands 6 and up). */
  tileKeyFor(n) {
    return `stage_${String(n).padStart(2, '0')}`;
  }

  drawBackground() {
    const ctx = this.ctx;
    const z = ZONES[this.lastZone];
    // stages 6-35 have their own environment from the reference sheets: a seamless tile that
    // drifts slowly with the climb. Stages 1-5 keep the zone backgrounds.
    const stageKey = this.stage && this.stage.n >= 6 ? this.tileKeyFor(this.stage.n) : null;
    const stageImg = stageKey ? Assets.get(stageKey) : null;
    if (stageImg) {
      // a band change cross-fades from the previous band's tile
      const prevImg = this.bgFade && this.prevBand >= 6 ? Assets.get(this.tileKeyFor(this.prevBand)) : null;
      if (prevImg) this.drawTiledBg(prevImg, 0.35, 1);
      this.drawTiledBg(stageImg, 0.35, prevImg ? this.bgFade.t : 1);
    } else {
      if (this.bgFade) {
        const prev = ZONES[Math.max(0, this.lastZone - 1)];
        this.drawBgLayer(prev, 1);
        this.drawBgLayer(z, this.bgFade.t);
      } else {
        this.drawBgLayer(z, 1);
      }
      ctx.globalAlpha = 1;
      ctx.fillStyle = z.tint;
      ctx.fillRect(0, 0, W, H);
    }

    if (!this.settings.reducedEffects) {
      ctx.save();
      ctx.globalAlpha = 0.06;
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 4; i++) {
        const x = 70 + i * 130 + Math.sin(this.time * 0.3 + i) * 20;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x + 70, 0);
        ctx.lineTo(x + 260, H);
        ctx.lineTo(x + 120, H);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    }
  }

  /** Repeats a seamless background tile vertically. `speed` is its scroll rate vs the camera. */
  drawTiledBg(img, speed, alpha = 1) {
    const ctx = this.ctx;
    const th = img.height;
    const off = (((this.camTop || 0) * speed) % th + th) % th;
    ctx.globalAlpha = alpha;
    for (let y = -off; y < H; y += th) ctx.drawImage(img, 0, y, W, th);
  }

  drawBgLayer(zone, alpha) {
    const ctx = this.ctx;
    const img = Assets.get(zone.bg);
    ctx.globalAlpha = alpha;
    if (!img) {
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#49c6ff');
      g.addColorStop(1, '#0d5a8a');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
      return;
    }
    const scale = W / img.width;
    const bh = img.height * scale;
    const raw = -this.camTop * BG_PARALLAX;
    const n = Math.floor(raw / bh);
    const sh = raw - n * bh;
    // ping-pong tiling: alternate tiles are flipped so the seams always match
    this.drawBgTile(img, sh - bh, bh, parity(n - 1) === 1);
    this.drawBgTile(img, sh, bh, parity(n) === 1);
    ctx.globalAlpha = 1;
  }

  drawBgTile(img, y0, bh, flip) {
    const ctx = this.ctx;
    if (!flip) {
      ctx.drawImage(img, 0, y0, W, bh);
    } else {
      ctx.save();
      ctx.translate(0, y0 + bh);
      ctx.scale(1, -1);
      ctx.drawImage(img, 0, 0, W, bh);
      ctx.restore();
    }
  }

  drawDecor() {
    const ctx = this.ctx;
    const img = Assets.get('deco_tiki');
    for (const d of this.decor) {
      const sy = d.y - this.camTop;
      if (sy < -200 || sy > H + 200) continue;
      if (!img) continue;
      const w = 90 * d.s;
      const h = w * img.height / img.width;
      ctx.drawImage(img, d.x - w / 2, sy - h, w, h);
    }
  }

  drawPlatforms() {
    const ctx = this.ctx;
    for (let i = 0; i < this.platforms.length; i++) {
      const pl = this.platforms[i];
      if (pl.dead) continue;
      const sy = pl.y - this.camTop;
      if (sy < -80 || sy > H + 80) continue;
      const img = Assets.get(pl.sprite);
      if (pl.hidden) {
        // faded outline while the platform is gone, so the layout stays readable
        ctx.globalAlpha = 0.18;
        if (img) ctx.drawImage(img, pl.x - pl.w / 2, sy, pl.w, pl.h);
        ctx.globalAlpha = 1;
        continue;
      }
      const shake = pl.breakT > 0 ? Math.sin(this.time * 70) * 2.5 : 0;
      const x = pl.x - pl.w / 2 + shake;
      if (img) {
        ctx.drawImage(img, x, sy, pl.w, pl.h);
      } else {
        ctx.fillStyle = '#e8c27a';
        ctx.fillRect(x, sy, pl.w, pl.h);
      }
    }
  }

  drawItems() {
    const ctx = this.ctx;
    for (let i = 0; i < this.items.length; i++) {
      const it = this.items[i];
      if (it.dead) continue;
      const sy = it.y - this.camTop;
      if (sy < -60 || sy > H + 60) continue;
      if (it.cat === 'power') {
        const pulse = 1 + Math.sin(it.t * 5) * 0.08;
        ctx.globalAlpha = 0.4;
        ctx.fillStyle = it.color;
        ctx.beginPath();
        ctx.arc(it.x, sy, 26 * pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
        const img = it.sprite ? Assets.get(it.sprite) : null;
        const bobY = Math.sin(it.t * 3) * 3;
        if (img) {
          const w = 50, h = w * img.height / img.width;
          ctx.drawImage(img, it.x - w / 2, sy - h / 2 + bobY, w, h);
        } else {
          ctx.fillStyle = it.color;
          ctx.beginPath();
          ctx.arc(it.x, sy, 18, 0, Math.PI * 2);
          ctx.fill();
        }
        continue;
      }
      const img = Assets.get(it.sprite);
      if (!img) continue;
      const bob = Math.sin(it.t * 3) * 2;
      if (it.cat === 'coin') {
        const sx = Math.abs(Math.cos(it.t * 4)) * 0.85 + 0.15;
        const w = it.w * sx;
        const h = it.w * img.height / img.width;
        ctx.drawImage(img, it.x - w / 2, sy - h / 2 + bob, w, h);
      } else {
        const h = it.w * img.height / img.width;
        ctx.drawImage(img, it.x - it.w / 2, sy - h / 2 + bob, it.w, h);
      }
    }
  }

  drawEnemies() {
    const ctx = this.ctx;
    for (let i = 0; i < this.enemies.length; i++) {
      const e = this.enemies[i];
      if (e.dead) continue;
      const sy = e.y - this.camTop;
      if (sy < -120 || sy > H + 120) continue;
      const img = Assets.get(e.sprite);
      if (!img) continue;
      const h = e.w * img.height / img.width;
      if (e.type === 'mine') {
        ctx.save();
        ctx.translate(e.x, sy);
        ctx.rotate(e.t * 0.8);
        ctx.drawImage(img, -e.w / 2, -h / 2, e.w, h);
        ctx.restore();
      } else {
        ctx.drawImage(img, e.x - e.w / 2, sy - h / 2, e.w, h);
      }
    }
  }

  drawRockWarnings() {
    const ctx = this.ctx;
    for (const w of this.rockWarn) {
      const pulse = 0.55 + Math.sin(this.time * 14) * 0.45;
      ctx.globalAlpha = pulse;
      ctx.fillStyle = '#ff4d4d';
      ctx.beginPath();
      ctx.moveTo(w.x, 6);
      ctx.lineTo(w.x - 14, 30);
      ctx.lineTo(w.x + 14, 30);
      ctx.closePath();
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  /** Reference art for the equipped outfit, or the equipped character, or null (pose sheet). */
  bodyArt() {
    const outfit = OUTFITS.find((o) => o.id === this.loadout.outfit);
    const ch = CHARACTERS.find((c) => c.id === this.loadout.character);
    const name = (outfit && outfit.sprite) || (ch && ch.id !== 'spongebob' ? ch.sprite : null);
    return name ? Assets.get(name) : null;
  }

  drawPlayer() {
    const ctx = this.ctx;
    const p = this.p;
    const sy = p.y - this.camTop;
    if (sy < -300 || sy > H + 300) return;

    let pose = 'sb_idle';
    if (this.state === 'dying' || p.hurtT > 0) pose = 'sb_hurt';
    else if (p.vy < -220) pose = 'sb_jump';
    else if (p.vy > 650) pose = 'sb_hurt';
    else if (p.landT > 0) pose = 'sb_land';
    else if (Math.abs(p.vx) > 140) pose = 'sb_wobble';

    // an equipped outfit or character (reference art) replaces the pose sheet during play
    const art = this.bodyArt();
    const img = art ? art : (Assets.get(pose) || Assets.get('sb_idle'));
    if (!img) return;
    let m, s;
    if (art) {
      // full-figure art: scale it to the same height as the SpongeBob body
      m = { w: img.width, h: img.height, sw: img.width * 0.8, cx: img.width / 2, st: 0, sb: img.height };
      s = PHYS.spriteH / img.height;
    } else {
      const meta = Assets.poseMeta() || {};
      const idle = meta.sb_idle || { h: img.height, sw: img.width * 0.8 };
      m = meta[pose] || { w: img.width, h: img.height, sw: img.width * 0.8, cx: img.width / 2, st: 0, sb: img.height };
      // every pose is scaled so SpongeBob's body is the same size on screen
      const refScale = PHYS.spriteH / idle.h;
      s = (idle.sw * refScale) / m.sw;
    }
    const dw = img.width * s;
    const dh = img.height * s;
    const centerY = sy - PHYS.spriteH * 0.5;

    // power-up auras behind the character
    if (this.timers.superBounce) {
      ctx.save();
      ctx.globalAlpha = 0.35 + Math.sin(this.time * 8) * 0.12;
      const g = ctx.createRadialGradient(p.x, sy, 4, p.x, sy, 60);
      g.addColorStop(0, 'rgba(255,230,120,0.9)');
      g.addColorStop(1, 'rgba(255,210,60,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(p.x, sy, 60, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    if (this.timers.magnet) {
      ctx.save();
      ctx.strokeStyle = 'rgba(255,122,217,0.45)';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 8]);
      ctx.beginPath();
      ctx.arc(p.x, centerY, 200 * this.mods.magnet, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    ctx.save();
    ctx.translate(p.x, sy);
    const sq = p.squash;
    ctx.scale(1 + 0.12 * sq, 1 - 0.16 * sq);
    ctx.globalAlpha = (p.invuln > 0 && Math.floor(this.time * 14) % 2 === 0) ? 0.35 : 1;
    ctx.drawImage(img, -m.cx * s, -dh, dw, dh);
    if (!art) {
      // the older outfit overlays only apply to the SpongeBob pose sheet
      const spW = m.sw * s;
      const topY = -dh + m.st * s;
      const bodyCY = -dh + (m.st + (m.sb - m.st) / 2) * s;
      this.drawOutfit(ctx, 0, topY, spW, bodyCY);
    }
    ctx.restore();

    // double-coins badge above the character
    if (this.timers.double) {
      const bx = p.x + 40, by = sy - PHYS.spriteH - 4;
      ctx.save();
      ctx.fillStyle = '#ffe066';
      ctx.strokeStyle = '#7a4a00';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(bx, by, 19, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#7a4a00';
      ctx.font = '900 17px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('2X', bx, by + 1);
      ctx.restore();
    }

    // shield bubble
    if (this.timers.shield) {
      const bubble = Assets.get('bubble');
      const r = 64 + Math.sin(this.time * 6) * 3;
      ctx.save();
      ctx.globalAlpha = 0.55 + Math.sin(this.time * 6) * 0.1;
      if (bubble) ctx.drawImage(bubble, p.x - r, centerY - r, r * 2, r * 2);
      else { ctx.strokeStyle = '#7fe7ff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(p.x, centerY, r, 0, Math.PI * 2); ctx.stroke(); }
      ctx.restore();
    }
  }

  drawOutfit(ctx, cx, topY, spW, bodyCY) {
    Game.drawOutfitAt(ctx, this.loadout.outfit, cx, topY, spW, bodyCY);
  }

  /** Static so the shop can preview outfits with exactly the same drawing code. */
  static drawOutfitAt(ctx, id, cx, topY, spW, bodyCY) {
    if (id === 'captain') {
      const w = spW * 0.6;
      const h = spW * 0.2;
      const x = cx - w / 2;
      const y = topY - h * 0.2;
      ctx.fillStyle = '#1d3c7a';
      roundRect(ctx, x, y - h, w, h, h * 0.45);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(cx, y, w * 0.62, h * 0.18, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x + 2, y - h * 0.45, w - 4, h * 0.14);
      ctx.fillStyle = '#ffd23f';
      ctx.beginPath();
      ctx.arc(cx, y - h * 0.6, h * 0.12, 0, Math.PI * 2);
      ctx.fill();
    } else if (id === 'golden_crown') {
      const w = spW * 0.56;
      const h = spW * 0.2;
      const x = cx - w / 2;
      const y = topY + 2;
      ctx.fillStyle = '#ffd23f';
      ctx.strokeStyle = '#8a5a00';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x, y - h * 0.7);
      ctx.lineTo(x + w * 0.25, y - h * 0.35);
      ctx.lineTo(cx, y - h);
      ctx.lineTo(x + w * 0.75, y - h * 0.35);
      ctx.lineTo(x + w, y - h * 0.7);
      ctx.lineTo(x + w, y);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#e63946';
      ctx.beginPath();
      ctx.arc(cx, y - h * 0.8, 3.5, 0, Math.PI * 2);
      ctx.fill();
    } else if (id === 'bubble_helmet') {
      const r = spW * 0.74;
      ctx.fillStyle = 'rgba(170,235,255,0.16)';
      ctx.strokeStyle = 'rgba(200,245,255,0.85)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, bodyCY, r, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.9)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, bodyCY, r * 0.7, Math.PI * 1.1, Math.PI * 1.5);
      ctx.stroke();
    }
  }

  drawBanner() {
    if (!this.banner) return;
    const ctx = this.ctx;
    const t = this.banner.t;
    const a = Math.max(0, Math.min(1, (2.6 - t) / 0.25, t / 0.6));
    ctx.save();
    ctx.globalAlpha = a;
    ctx.fillStyle = 'rgba(8,40,80,0.55)';
    roundRect(ctx, 60, 128, W - 120, 92, 22);
    ctx.fill();
    ctx.textAlign = 'center';
    ctx.font = '14px "Trebuchet MS", Arial, sans-serif';
    ctx.fillStyle = '#ffe14d';
    ctx.fillText(this.banner.label || ('ZONE ' + (this.lastZone + 1)), W / 2, 152);
    // long world names shrink to fit the plate instead of running off the screen
    const title = this.banner.text.toUpperCase();
    let size = 34;
    ctx.font = `${size}px Impact, "Arial Black", sans-serif`;
    while (size > 18 && ctx.measureText(title).width > W - 150) {
      size -= 2;
      ctx.font = `${size}px Impact, "Arial Black", sans-serif`;
    }
    ctx.lineWidth = 5;
    ctx.strokeStyle = 'rgba(40,20,0,0.9)';
    ctx.strokeText(title, W / 2, 192);
    ctx.fillStyle = '#ffffff';
    ctx.fillText(title, W / 2, 192);
    ctx.restore();
  }
}

function parity(k) { return ((k % 2) + 2) % 2; }

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

export { roundRect };
