// Milestone boss encounters. Logic and drawing live here, apart from the core loop, so bosses
// can be added or retuned through config (BOSS_TUNE, BOSS_ART, MILESTONE_BOSSES).
//
// Rules (kept fair, see the stage flow test):
//  - a boss appears every BOSS_EVERY_M metres of the endless run (keys cycle through the seven mapped bosses)
//  - it hovers above the player and attacks in turn: falling drops, then a sweeping bolt
//  - every attack shows a warning first; nothing can hurt until its warning ends
//  - three stomps on its head defeat it; if it is not beaten within BOSS_TUNE.timeLimit
//    seconds it swims away, so a fight can never block or soft-lock a stage
//  - the boss never blocks the climb; the run can continue while it is there
//  - drawing is flat, bright and cartoon-like: no gore, no damage numbers
import { LOGICAL_W as W, LOGICAL_H as H, PHYS, BOSS_TUNE, BOSS_ART, MILESTONE_BOSSES, BOSS_EVERY_M, bossKeyFor } from './config.js';
import { Assets } from './assets.js';
import { Sound } from './audio.js';
import { circleRectOverlap, playerHitRect } from './physics.js';

const WARN_DROP = 1.1;   // seconds of warning before a drop starts falling
const WARN_SWEEP = 0.9;  // seconds of warning before a sweeping bolt moves
const DROP_R = 18;       // drop collision radius
const DROP_GRAVITY = 900;
const DROP_MAX_VY = 620;
const SWEEP_H = 26;      // bolt height
const SWEEP_HALF_W = 40; // bolt half width
const SWEEP_SPEED = 320; // px/s

/** Creates the boss for a boss key. Called once per milestone. */
function spawnBoss(game, key) {
  const art = BOSS_ART[key];
  if (!art) return null;
  const img = Assets.get(art.sprite);
  // if the art is missing, a flat-colour placeholder keeps the fight playable
  const h = img ? art.w * img.height / img.width : art.w * 0.9;
  return {
    name: MILESTONE_BOSSES[key] || 'Boss',
    sprite: art.sprite,
    w: art.w,
    h,
    x: W / 2,
    // a fixed world height above the player: reachable by climbing, and it never blocks the stage
    y: game.p.y - 170,
    baseX: W / 2,
    hp: BOSS_TUNE.hp,
    maxHp: BOSS_TUNE.hp,
    age: 0,
    attackT: 2.0,
    nextKind: 'drop',
    hazards: [],
    flash: 0,
    state: 'active', // active | defeated | fled
    fade: 1,
  };
}

/** Per-frame boss update. Called from the game tick after hazards are checked. */
export function updateBoss(game, dt) {
  if (!game.boss && game.run.metres >= game.nextBossM) {
    const key = bossKeyFor(Math.round(game.nextBossM / BOSS_EVERY_M));
    game.nextBossM += BOSS_EVERY_M;
    const b = spawnBoss(game, key);
    if (b) {
      game.boss = b;
      game.banner = { text: b.name, sub: 'MILESTONE BOSS', t: 2.6 };
      Sound.play('bossAppear');
    }
  }
  const b = game.boss;
  if (!b) return;
  b.age += dt;
  if (b.state === 'active') {
    b.x = b.baseX + Math.sin(b.age * 0.7) * 110;
    b.flash = Math.max(0, b.flash - dt);
    b.attackT -= dt;
    if (b.attackT <= 0) startAttack(game, b);
    checkStomp(game, b);
    if (b.state === 'active' && b.age > BOSS_TUNE.timeLimit) flee(game, b);
  } else {
    b.fade = Math.max(0, b.fade - dt * 1.2);
  }
  updateHazards(game, b, dt);
  if (b.state !== 'active' && b.fade <= 0 && b.hazards.length === 0) game.boss = null;
}

function startAttack(game, b) {
  b.attackT = BOSS_TUNE.attackGap;
  if (b.nextKind === 'drop') {
    // three drops in separate columns, at least 110 px apart so there is always a gap to move into
    const xs = [];
    let guard = 0;
    while (xs.length < 3 && guard++ < 60) {
      const x = 60 + Math.random() * (W - 120);
      if (xs.every((v) => Math.abs(v - x) >= 110)) xs.push(x);
    }
    const top = game.camTop + 150;
    for (const x of xs) b.hazards.push({ kind: 'drop', x, y: top, vy: 0, warnT: WARN_DROP, dead: false });
    b.nextKind = 'sweep';
    game.fx.text(W / 2, top - 6, 'WATCH OUT!', '#ff6b6b', 20);
  } else {
    const dir = Math.random() < 0.5 ? 1 : -1;
    const y = b.y + b.h * 0.5 + 24;
    b.hazards.push({ kind: 'sweep', x: dir > 0 ? -60 : W + 60, y, dir, warnT: WARN_SWEEP, dead: false });
    b.nextKind = 'drop';
    game.fx.text(W / 2, y - 14, 'INCOMING!', '#7fe7ff', 20);
  }
}

function updateHazards(game, b, dt) {
  const p = game.p;
  const box = playerHitRect(p);
  for (const h of b.hazards) {
    if (h.dead) continue;
    if (h.warnT > 0) {
      h.warnT = Math.max(0, h.warnT - dt);
      continue; // warning only: nothing moves and nothing hurts yet
    }
    if (h.kind === 'drop') {
      h.vy = Math.min(h.vy + DROP_GRAVITY * dt, DROP_MAX_VY);
      h.y += h.vy * dt;
      if (h.y > game.camTop + H + 80) { h.dead = true; continue; }
      if (circleRectOverlap(h.x, h.y, DROP_R, box.x0, box.y0, box.x1, box.y1)) applyHit(game, h);
    } else {
      h.x += h.dir * SWEEP_SPEED * dt;
      if (h.x < -90 || h.x > W + 90) { h.dead = true; continue; }
      const hit = box.x1 >= h.x - SWEEP_HALF_W && box.x0 <= h.x + SWEEP_HALF_W &&
        box.y1 >= h.y - SWEEP_H / 2 && box.y0 <= h.y + SWEEP_H / 2;
      if (hit) applyHit(game, h);
    }
  }
  b.hazards = b.hazards.filter((h) => !h.dead);
}

function applyHit(game, h) {
  const p = game.p;
  h.dead = true;
  if (p.invuln > 0) return;
  if (game.timers.shield) {
    // the bubble shield pops the attack instead of costing coins
    delete game.timers.shield;
    p.invuln = 1.2;
    p.vy = -620;
    game.fx.burst(h.x, h.y, 16, { color: '#7fe7ff', shape: 'bubble', speed: 160, life: 0.6, size: 9 });
    game.fx.text(p.x, p.y - 110, 'POP!', '#7fe7ff', 24);
    Sound.play('shield');
    return;
  }
  game.hurt();
}

function checkStomp(game, b) {
  const p = game.p;
  if (p.vy <= 0) return;
  const top = b.y - b.h * 0.42;
  // the feet must come from above the boss's top surface this step
  if (!(p.prevY <= top + 2 && p.y >= top)) return;
  if (Math.abs(p.x - b.x) > b.w * 0.45 + PHYS.landHalfW) return;
  b.hp--;
  b.flash = 0.3;
  p.vy = -PHYS.jumpVel * 0.85;
  p.squash = 1;
  game.fx.burst(p.x, top, 14, { color: '#fff08a', speed: 180, life: 0.5, size: 6 });
  game.fx.text(b.x, top - 16, b.hp > 0 ? 'HIT!' : 'DEFEATED!', '#fff08a', 24);
  Sound.play(b.hp > 0 ? 'bossHit' : 'bossDown');
  if (b.hp <= 0) defeat(game, b);
}

function defeat(game, b) {
  b.state = 'defeated';
  b.hazards.length = 0; // clear attacks at once so the win is clear
  game.addCoins(BOSS_TUNE.coinReward, b.x, b.y);
  game.run.bossesDefeated++;
  game.emit('onBossDown', b.name);
  game.fx.burst(b.x, b.y, 26, { color: '#ffe14d', speed: 220, life: 0.9, size: 8 });
  game.banner = { text: 'BOSS DEFEATED', sub: b.name, t: 2.6 };
}

function flee(game, b) {
  b.state = 'fled';
  b.hazards.length = 0;
  game.banner = { text: 'IT SWAM AWAY', sub: b.name, t: 2.2 };
}

/** Draws the boss, its attack warnings and its falling or sweeping hazards. */
export function drawBoss(game) {
  const b = game.boss;
  if (!b) return;
  const ctx = game.ctx;
  const camTop = game.camTop;
  const alphaBase = b.state === 'active' ? 1 : b.fade;

  for (const h of b.hazards) {
    const sy = h.y - camTop;
    if (h.kind === 'drop') {
      if (h.warnT > 0) {
        drawWarning(ctx, h.x, Math.max(20, sy), game.time);
      } else {
        const img = Assets.get('enemy_urchin');
        const size = 46;
        ctx.save();
        if (img) ctx.drawImage(img, h.x - size / 2, sy - size / 2, size, size * img.height / img.width);
        else { ctx.fillStyle = '#ff6b6b'; ctx.beginPath(); ctx.arc(h.x, sy, DROP_R, 0, Math.PI * 2); ctx.fill(); }
        ctx.restore();
      }
    } else {
      ctx.save();
      if (h.warnT > 0) {
        const pulse = 0.18 + Math.abs(Math.sin(game.time * 9)) * 0.22;
        ctx.globalAlpha = pulse;
        ctx.fillStyle = '#ffe14d';
        ctx.fillRect(0, sy - SWEEP_H / 2, W, SWEEP_H);
        ctx.globalAlpha = 0.9;
        drawWarning(ctx, 26, sy, game.time);
      } else {
        const g = ctx.createLinearGradient(h.x - SWEEP_HALF_W, 0, h.x + SWEEP_HALF_W, 0);
        g.addColorStop(0, 'rgba(127,231,255,0)');
        g.addColorStop(0.5, 'rgba(230,252,255,0.95)');
        g.addColorStop(1, 'rgba(127,231,255,0)');
        ctx.fillStyle = g;
        roundRect(ctx, h.x - SWEEP_HALF_W, sy - SWEEP_H / 2, SWEEP_HALF_W * 2, SWEEP_H, 13);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  const sy = b.y - camTop;
  if (sy < -300 || sy > H + 300) return;
  const img = Assets.get(b.sprite);
  ctx.save();
  ctx.globalAlpha = alphaBase * (b.flash > 0 && Math.floor(game.time * 16) % 2 === 0 ? 0.55 : 1);
  if (img) {
    ctx.drawImage(img, b.x - b.w / 2, sy - b.h / 2, b.w, b.h);
  } else {
    ctx.fillStyle = '#8f5ad6';
    roundRect(ctx, b.x - b.w / 2, sy - b.h / 2, b.w, b.h, 22);
    ctx.fill();
  }
  // health pips above the boss
  for (let i = 0; i < b.maxHp; i++) {
    const px = b.x + (i - (b.maxHp - 1) / 2) * 18;
    const py = sy - b.h / 2 - 14;
    ctx.beginPath();
    ctx.arc(px, py, 6, 0, Math.PI * 2);
    ctx.fillStyle = i < b.hp ? '#ffe14d' : 'rgba(20,30,50,0.45)';
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.stroke();
  }
  ctx.restore();
}

function drawWarning(ctx, x, y, time) {
  ctx.save();
  const r = 15 + Math.abs(Math.sin(time * 10)) * 3;
  ctx.globalAlpha = 0.95;
  ctx.fillStyle = '#ff5a5a';
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 20px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('!', x, y + 1);
  ctx.restore();
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}
