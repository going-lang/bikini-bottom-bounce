// Audio: sound effects and background music are synthesised with the Web Audio API.
// Everything here is original (no third-party audio files), so no licences are needed.
// To use licensed tracks instead, replace `startMusic` with HTMLAudio playback.
// Phase 2: music follows the endless world (1-7), not the five zones. Each world has its own key,
// scale, tempo and lead voice, and every bar gets a soft sustained pad.
const WORLD_MUSIC = [
  null,
  { root: 220, scale: [0, 2, 4, 7, 9], tempo: 104, wave: 'triangle' },      // 1 Bikini Bottom
  { root: 246.94, scale: [0, 2, 3, 7, 9], tempo: 112, wave: 'triangle' },   // 2 Jellyfish Fields
  { root: 196, scale: [0, 3, 5, 7, 10], tempo: 122, wave: 'square' },       // 3 Rock Bottom
  { root: 261.63, scale: [0, 2, 4, 7, 9], tempo: 128, wave: 'triangle' },   // 4 Goo Lagoon
  { root: 174.61, scale: [0, 2, 3, 7, 8], tempo: 134, wave: 'square' },     // 5 Kelp Forest
  { root: 164.81, scale: [0, 2, 3, 7, 8], tempo: 96, wave: 'sine' },        // 6 Flying Dutchman's (slow, eerie)
  { root: 233.08, scale: [0, 2, 4, 6, 7, 9, 11], tempo: 116, wave: 'sine' }, // 7 Mermaid Man's Lair (airy)
];

let ctx = null;
let out = null;
let sfxBus = null;
let musicBus = null;
let lowpass = null;
let noiseBuf = null;
let musicOn = false;
let schedTimer = null;
let nextTime = 0;
let step = 0;
let worldIdx = 1;
let volumes = { music: 0.6, sfx: 0.8 };
let ducked = false;

function ensure() {
  if (ctx) {
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    return true;
  }
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return false;
  try {
    ctx = new AC();
  } catch (e) {
    return false;
  }
  out = ctx.createGain();
  out.gain.value = 1;
  out.connect(ctx.destination);

  lowpass = ctx.createBiquadFilter();
  lowpass.type = 'lowpass';
  lowpass.frequency.value = 2600;
  lowpass.connect(out);
  musicBus = ctx.createGain();
  musicBus.gain.value = volumes.music * 0.32;
  musicBus.connect(lowpass);

  sfxBus = ctx.createGain();
  sfxBus.gain.value = volumes.sfx;
  sfxBus.connect(out);

  // one shared noise buffer for hits / cracks
  noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.5, ctx.sampleRate);
  const d = noiseBuf.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return true;
}

function tone({ freq, dur = 0.2, type = 'sine', vol = 0.3, when = 0, slide = 0, bus = null, attack = 0.005 }) {
  if (!ctx) return;
  const t0 = ctx.currentTime + when;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq * slide), t0 + dur);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t0 + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g);
  g.connect(bus || sfxBus);
  o.start(t0);
  o.stop(t0 + dur + 0.05);
  o.onended = () => { try { o.disconnect(); g.disconnect(); } catch (e) { /* noop */ } };
}

function noise({ dur = 0.2, vol = 0.2, when = 0, freq = 1800 }) {
  if (!ctx || !noiseBuf) return;
  const t0 = ctx.currentTime + when;
  const src = ctx.createBufferSource();
  src.buffer = noiseBuf;
  const f = ctx.createBiquadFilter();
  f.type = 'bandpass';
  f.frequency.value = freq;
  const g = ctx.createGain();
  g.gain.setValueAtTime(vol, t0);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  src.connect(f); f.connect(g); g.connect(sfxBus);
  src.start(t0, Math.random() * 0.3);
  src.stop(t0 + dur + 0.05);
  src.onended = () => { try { src.disconnect(); f.disconnect(); g.disconnect(); } catch (e) { /* noop */ } };
}

const SFX = {
  jump() { tone({ freq: 330, slide: 2.1, dur: 0.18, type: 'sine', vol: 0.28 }); },
  land() { tone({ freq: 190, slide: 0.55, dur: 0.1, type: 'triangle', vol: 0.22 }); },
  coin() {
    tone({ freq: 988, dur: 0.07, type: 'square', vol: 0.09 });
    tone({ freq: 1319, dur: 0.12, type: 'square', vol: 0.09, when: 0.06 });
  },
  pickup() { [523, 659, 784, 1047].forEach((f, i) => tone({ freq: f, dur: 0.12, type: 'triangle', vol: 0.18, when: i * 0.06 })); },
  treasure() { [659, 784, 988, 1319, 1568].forEach((f, i) => tone({ freq: f, dur: 0.16, type: 'triangle', vol: 0.2, when: i * 0.07 })); },
  powerup() {
    tone({ freq: 400, slide: 3, dur: 0.35, type: 'sine', vol: 0.22 });
    [659, 784, 988, 1319].forEach((f, i) => tone({ freq: f, dur: 0.1, type: 'square', vol: 0.08, when: 0.18 + i * 0.05 }));
  },
  extra() { [784, 988, 1175, 1568].forEach((f, i) => tone({ freq: f, dur: 0.1, type: 'triangle', vol: 0.2, when: i * 0.05 })); },
  mega() { tone({ freq: 180, slide: 6, dur: 0.5, type: 'sine', vol: 0.3 }); noise({ dur: 0.4, vol: 0.12, freq: 900 }); },
  shield() { tone({ freq: 600, slide: 1.5, dur: 0.25, type: 'sine', vol: 0.22 }); tone({ freq: 900, dur: 0.18, type: 'triangle', vol: 0.12, when: 0.08 }); },
  pop() { tone({ freq: 900, slide: 1.9, dur: 0.12, type: 'sine', vol: 0.22 }); },
  hurt() {
    tone({ freq: 320, slide: 0.25, dur: 0.35, type: 'sawtooth', vol: 0.18 });
    noise({ dur: 0.18, vol: 0.2, freq: 1200 });
  },
  gameover() {
    [392, 330, 262, 196].forEach((f, i) => tone({ freq: f, dur: 0.32, type: 'sawtooth', vol: 0.16, when: i * 0.3 }));
  },
  click() { tone({ freq: 880, dur: 0.04, type: 'square', vol: 0.07 }); },
  unlock() { [523, 659, 784, 1047, 1319].forEach((f, i) => tone({ freq: f, dur: 0.18, type: 'triangle', vol: 0.2, when: i * 0.11 })); },
  purchase() { tone({ freq: 1319, dur: 0.08, type: 'square', vol: 0.08 }); tone({ freq: 988, dur: 0.12, type: 'square', vol: 0.08, when: 0.07 }); },
  highscore() {
    [523, 659, 784, 659, 784, 1047, 1319].forEach((f, i) => tone({ freq: f, dur: 0.22, type: 'triangle', vol: 0.22, when: i * 0.12 }));
  },
  warn() { tone({ freq: 1000, dur: 0.08, type: 'square', vol: 0.07 }); tone({ freq: 1000, dur: 0.08, type: 'square', vol: 0.07, when: 0.16 }); },
  crack() { noise({ dur: 0.15, vol: 0.18, freq: 700 }); },
  bounce() { tone({ freq: 520, slide: 1.8, dur: 0.14, type: 'sine', vol: 0.22 }); },
  // Phase 2 additions
  stomp() { tone({ freq: 420, slide: 0.45, dur: 0.14, type: 'triangle', vol: 0.26 }); noise({ dur: 0.08, vol: 0.1, freq: 1200 }); },
  bossAppear() {
    tone({ freq: 110, slide: 3, dur: 0.6, type: 'sawtooth', vol: 0.16 });
    [392, 523, 659, 784].forEach((f, i) => tone({ freq: f, dur: 0.22, type: 'triangle', vol: 0.18, when: 0.25 + i * 0.09 }));
  },
  bossHit() { tone({ freq: 300, slide: 0.6, dur: 0.12, type: 'square', vol: 0.12 }); noise({ dur: 0.12, vol: 0.14, freq: 900 }); },
  bossDown() {
    [523, 659, 784, 1047, 1319, 1568].forEach((f, i) => tone({ freq: f, dur: 0.22, type: 'triangle', vol: 0.2, when: i * 0.08 }));
    noise({ dur: 0.5, vol: 0.08, freq: 2000 });
  },
  revive() { [392, 523, 659, 784, 1047].forEach((f, i) => tone({ freq: f, dur: 0.2, type: 'sine', vol: 0.22, when: i * 0.07 })); },
};

// Simple chord progression in scale degrees; a bar is 8 eighth-notes.
const PROG = [0, 3, 4, 2];

function scheduleStep(s, t) {
  const m = WORLD_MUSIC[worldIdx];
  if (!m) return;
  const scale = m.scale;
  const len = scale.length;
  const bar = Math.floor(s / 8);
  const chordDeg = PROG[bar % PROG.length];
  const semi = (deg) => scale[((deg % len) + len) % len] + 12 * Math.floor(deg / len);
  const freq = (deg, oct = 0) => m.root * Math.pow(2, (semi(deg) + 12 * oct) / 12);
  const eighth = 60 / m.tempo / 2;
  const chord = [chordDeg, chordDeg + 2, chordDeg + 4];

  // bass on every 4th eighth note
  if (s % 4 === 0) {
    tone({ freq: freq(chordDeg, -1), dur: eighth * 3.5, type: 'triangle', vol: 0.5, when: t - ctx.currentTime, bus: musicBus });
  }
  // soft pad: the whole chord held for one bar, an octave up
  if (s % 8 === 0) {
    chord.forEach((deg) => tone({ freq: freq(deg, 1), dur: eighth * 7.6, type: 'sine', vol: 0.06, when: t - ctx.currentTime, bus: musicBus, attack: 0.25 }));
  }
  // lead melody: chord tones with some rests
  if (Math.random() > 0.25) {
    const pick = chord[Math.floor(Math.random() * chord.length)];
    tone({ freq: freq(pick, 1), dur: eighth * 0.9, type: m.wave === 'square' ? 'square' : (m.wave === 'sine' ? 'sine' : 'triangle'), vol: m.wave === 'square' ? 0.12 : 0.22, when: t - ctx.currentTime, bus: musicBus });
  }
}

function scheduler() {
  if (!musicOn || !ctx) return;
  const m = WORLD_MUSIC[worldIdx];
  if (!m) return;
  const stepDur = 60 / m.tempo / 2;
  while (nextTime < ctx.currentTime + 0.15) {
    scheduleStep(step, nextTime);
    nextTime += stepDur;
    step++;
  }
}

export const Sound = {
  /** Call from a user gesture (tap) so audio is allowed by the browser. */
  unlock() { return ensure(); },

  setVolumes(v) {
    volumes = { ...volumes, ...v };
    if (sfxBus) sfxBus.gain.value = volumes.sfx;
    if (musicBus) musicBus.gain.value = (ducked ? 0.35 : 1) * volumes.music * 0.32;
  },

  play(name) {
    if (!ensure()) return;
    const fn = SFX[name];
    if (fn) fn();
  },

  startMusic(world = 1) {
    if (!ensure()) return;
    worldIdx = Math.min(WORLD_MUSIC.length - 1, Math.max(1, world));
    if (musicOn) return;
    musicOn = true;
    step = 0;
    nextTime = ctx.currentTime + 0.1;
    clearInterval(schedTimer);
    schedTimer = setInterval(scheduler, 25);
    musicBus.gain.value = (ducked ? 0.35 : 1) * volumes.music * 0.32;
  },

  /** Switches the music to an endless world (1-7). Takes effect on the next bar. */
  setWorld(world) { worldIdx = Math.min(WORLD_MUSIC.length - 1, Math.max(1, world)); },

  stopMusic() {
    musicOn = false;
    clearInterval(schedTimer);
    schedTimer = null;
  },

  /** Lower the music while paused or on menus with a dialog. */
  duck(on) {
    ducked = !!on;
    if (musicBus) musicBus.gain.value = (ducked ? 0.35 : 1) * volumes.music * 0.32;
  },
};
