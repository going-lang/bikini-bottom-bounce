// Procedural level generation. Pure functions (no DOM), so the reachability rules can be
// verified in Node with tools/test_generator.mjs.
//
// Rules that keep every level playable:
//   * vertical gap between rows  <= MAX_GAP (below the base jump apex of ~250px)
//   * horizontal offset to next platform <= maxDx(difficulty), which is reachable at
//     full sideways speed during the airtime of the vertical gap
//   * moving platform travel is subtracted from the horizontal budget
import { PLATFORMS, ZONES, ENEMIES, BONUS_WEIGHTS, POWERUPS, POWERUP_SPAWN_CHANCE, DIFF_METRES, LOGICAL_W, PATTERNS, stageInfo } from './config.js';

export const MAX_GAP = 172;
const TAU = Math.PI * 2;

export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const clamp = (v, a, b) => (v < a ? a : (v > b ? b : v));
const lerp = (a, b, t) => a + (b - a) * t;

export function difficultyFor(metres, offset = 0) {
  return clamp((metres + offset) / DIFF_METRES, 0, 1.3);
}

export function zoneIndexFor(metres) {
  let idx = 0;
  for (let i = 0; i < ZONES.length; i++) if (metres >= ZONES[i].from) idx = i;
  return idx;
}

export function maxDxFor(d) { return lerp(130, 192, d); }

function pickWeighted(rng, list) {
  let total = 0;
  for (const o of list) total += o[1];
  let r = rng() * total;
  for (const o of list) {
    r -= o[1];
    if (r <= 0) return o[0];
  }
  return list[list.length - 1][0];
}

// Kinds unlock by stage number, so the first stages stay simple and stage 35 uses all of them.
function pickKind(rng, zoneIdx, d, prevKind, stage) {
  const P = PATTERNS[stage.pattern] || {};
  const opts = [];
  opts.push(['normal', 60]);
  if (zoneIdx >= 1 || stage.n >= 2) opts.push(['small', 6 + 16 * d]);
  opts.push(['large', Math.max(4, 14 - 8 * d) * (P.largeMul || 1)]);
  opts.push(['bounce', 7]);
  if (zoneIdx >= 1 || stage.n >= 2) opts.push(['moving', (8 + 22 * d) * (P.moveMul || 1)]);
  if ((zoneIdx >= 1 || stage.n >= 3) && prevKind !== 'breakable') opts.push(['breakable', (3 + 12 * d) * (P.breakMul || 1)]);
  if (zoneIdx >= 3) opts.push(['special', 5]);
  if (stage.n >= 2) opts.push(['boost', 4 * (P.boostMul || 1)]);
  if (stage.n >= 6 && prevKind !== 'ice') opts.push(['ice', 4 * (P.iceMul || 1)]);
  if (stage.n >= 8 && prevKind !== 'vanish') opts.push(['vanish', 4 * (P.vanishMul || 1)]);
  return pickWeighted(rng, opts);
}

function pickEnemy(rng, metres) {
  const opts = [];
  for (const key in ENEMIES) {
    const e = ENEMIES[key];
    if (e.weight > 0 && metres >= e.minM) opts.push([key, e.weight]);
  }
  if (!opts.length) return null;
  return pickWeighted(rng, opts);
}

function pickBonus(rng, zoneIdx) {
  let r = rng();
  for (const b of BONUS_WEIGHTS) {
    if (zoneIdx < (b.minZone || 0)) continue;
    if (r < b.weight) return b.type;
    r -= b.weight;
  }
  return null;
}

function pickPower(rng) {
  const list = [];
  for (const key in POWERUPS) list.push([key, POWERUPS[key].weight]);
  return pickWeighted(rng, list);
}

/** First (starting) row: a wide, safe platform under SpongeBob. */
export function makeStartRow(y) {
  return { y, x: LOGICAL_W / 2, kind: 'normal', amp: 0, speed: 0, mult: 1, coins: 0, items: [] };
}

/**
 * Creates the next row above `prev`.
 * metres: height of this row (used for difficulty and unlocks)
 * Returns a plain row description; the game turns it into pooled objects.
 */
export function makeRow(prev, metres, rng, zoneIdx, stage = stageInfo(1)) {
  const P = PATTERNS[stage.pattern] || {};
  const d = difficultyFor(metres, stage.diffOffset || 0);
  const gap = clamp(lerp(96, 160, d) + (rng() - 0.5) * 22 + (P.gapAdd || 0), 84, MAX_GAP);
  const y = prev.y - gap;

  const kind = pickKind(rng, zoneIdx, d, prev.kind, stage);
  const def = PLATFORMS[kind];
  const amp = kind === 'moving' ? lerp(30, 70, d) : 0;
  const speed = kind === 'moving' ? lerp(0.9, 1.5, d) : 0;

  const half = def.w / 2;
  const maxDx = maxDxFor(d) * (P.zigMul || 1) - amp - (prev.amp || 0);
  const margin = half + amp + 8;
  const loX = Math.max(margin, prev.x - maxDx);
  const hiX = Math.min(LOGICAL_W - margin, prev.x + maxDx);
  let x;
  if (loX > hiX) {
    x = clamp(prev.x, margin, LOGICAL_W - margin);
  } else {
    x = lerp(loX, hiX, rng());
    // avoid stacking directly above the previous platform too often
    if (Math.abs(x - prev.x) < 40 && rng() < 0.6) {
      x = clamp(prev.x + (x >= prev.x ? 1 : -1) * 60, loX, hiX);
    }
  }

  const row = {
    y, x, kind, amp, speed, mult: def.mult || 1, coins: def.coins || 0, w: def.w,
    items: [],
  };

  // Coin trail along the path from prev to this platform.
  if (rng() < 0.7) {
    for (const t of [0.3, 0.5, 0.7]) {
      row.items.push({
        cat: 'coin', type: 'coin',
        x: lerp(prev.x, x, t),
        y: lerp(prev.y, y, t) - 38 - Math.sin(t * Math.PI) * 16,
      });
    }
  }

  // Bonus collectible on the path (replaces the middle coin).
  const bonus = pickBonus(rng, zoneIdx);
  if (bonus) {
    row.items.push({ cat: 'bonus', type: bonus, x: lerp(prev.x, x, 0.5), y: lerp(prev.y, y, 0.5) - 52 });
  }

  // Power-ups are rare and sit slightly higher on the path.
  if (rng() < POWERUP_SPAWN_CHANCE + 0.01 * zoneIdx) {
    row.items.push({ cat: 'power', type: pickPower(rng), x: lerp(prev.x, x, 0.5), y: lerp(prev.y, y, 0.5) - 64 });
  }

  // Hazards sit in the gap between rows, away from the main path.
  const pE = clamp((0.08 + 0.42 * d) * (P.enemyMul || 1), 0, 0.5);
  if (metres >= 40 && gap >= 100 && rng() < pE) {
    const type = pickEnemy(rng, metres);
    if (type) {
      const midX = lerp(prev.x, x, 0.5);
      const midY = lerp(prev.y, y, 0.5);
      let ex = midX;
      for (let i = 0; i < 6; i++) {
        ex = lerp(50, LOGICAL_W - 50, rng());
        if (Math.abs(ex - midX) >= 115) break;
      }
      const ey = midY + (rng() - 0.5) * 30;
      const range = type === 'fastJelly' ? Math.min(150, ex - 24, LOGICAL_W - 24 - ex) : 0;
      row.items.push({ cat: 'enemy', type, x: ex, y: ey, phase: rng() * TAU, amp: Math.max(0, range) });
    }
  }

  // Background decoration on the edges (purely visual) in the later zones.
  if (zoneIdx >= 2 && rng() < 0.3) {
    row.items.push({ cat: 'deco', x: rng() < 0.5 ? 34 : LOGICAL_W - 34, y: y + 70, s: 0.85 + rng() * 0.25 });
  }

  return row;
}
