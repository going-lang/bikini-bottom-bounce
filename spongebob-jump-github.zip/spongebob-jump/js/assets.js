// Asset manifest and loader. Each sprite is a separate file cut from the reference
// sheets (see tools/extract_sprites.py). Loading has a timeout and reports failures so
// the loading screen can offer a retry instead of hanging.

const SPRITES = [
  'sb_idle', 'sb_jump', 'sb_land', 'sb_hurt', 'sb_wobble',
  'plat_sand', 'plat_moving', 'plat_special_jelly', 'plat_breakable', 'plat_bounce', 'plat_large',
  'deco_tiki',
  'coin', 'bubble', 'jelly_token', 'spatula', 'treasure',
  'enemy_jelly', 'enemy_jelly_fast', 'enemy_urchin', 'enemy_jelly_large',
  'enemy_mine', 'enemy_bubble_hazard', 'enemy_rock',
];

// Power-up icons, cut from assets/reference/powerups_reference.jpg by tools/extract_powerups.py.
const POWERUP_SPRITES = [
  'pu_super_bounce', 'pu_bubble_shield', 'pu_jelly_magnet', 'pu_speed_boost',
  'pu_double_coins', 'pu_extra_life', 'pu_slow_motion', 'pu_mega_bounce',
];

// Reference art cut from the upload sheets by tools/extract_sheet.py (one file per item).
const REF_SPRITES = [
  'char_patrick', 'char_sandy', 'char_squidward', 'char_mrkrabs', 'char_gary',
  'outfit_superhero', 'outfit_pirate', 'outfit_astronaut', 'outfit_ninja', 'outfit_beach',
  'outfit_sports', 'outfit_royal', 'outfit_winter', 'outfit_space', 'outfit_golden',
  'fx_bubble_trail', 'fx_star_trail', 'fx_golden_coin_trail', 'fx_rainbow_trail', 'fx_water_trail',
  'fx_jellyfish_trail', 'fx_lightning_trail', 'fx_ocean_aura', 'fx_cosmic_trail', 'fx_golden_aura',
  'plat_boost', 'plat_ice', 'plat_disappearing',
  'hazard_rotating_blade', 'hazard_jelly_zap', 'hazard_spike_platform',
  'pick_coinpile', 'pick_star', 'pick_token', 'pick_treasure',
  'chest_wood', 'chest_anchor', 'chest_pearl', 'chest_daily',
  'boss_giant_jellyfish', 'boss_elite_jellyfish', 'boss_giant_sea_urchin', 'boss_angry_bubble',
  'boss_rock_guardian_teal', 'boss_treasure_guardian', 'boss_larry_lobster', 'boss_deep_sea_guardian', 'boss_rock_guardian_dark',
  'boss_final_ocean',
];

// Stage environments 6-35, cut from the environment reference sheets (tools/build_stage_bg.py).
const STAGE_BGS = Array.from({ length: 30 }, (_, i) => `stage_${String(i + 6).padStart(2, '0')}`);

const BACKGROUNDS = [
  'zone1_bikini_bottom', 'zone2_jellyfish_fields', 'zone3_goo_lagoon',
  'zone4_krusty_krab', 'zone5_rock_bottom',
];

const images = new Map();
let poseMeta = {};

export const Assets = {
  get(name) { return images.get(name) || null; },
  poseMeta() { return poseMeta; },
  count() { return images.size; },
};

function loadImage(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load ' + url));
    img.src = url;
  });
}

function withTimeout(promise, ms, label) {
  let timer;
  const to = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error('Timed out: ' + label)), ms);
  });
  return Promise.race([promise, to]).finally(() => clearTimeout(timer));
}

// Loads `items` with at most `limit` requests in flight. Browsers queue requests beyond
// their connection limit, so starting everything at once made queued images time out
// on slower connections.
async function loadPool(items, limit, worker) {
  let next = 0;
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const item = items[next++];
      await worker(item);
    }
  });
  await Promise.all(runners);
}

async function loadWithRetry(url, tries = 3) {
  let lastErr = null;
  for (let t = 0; t < tries; t++) {
    try {
      return await withTimeout(loadImage(url), 25000, url);
    } catch (e) {
      lastErr = e;
      await new Promise((r) => setTimeout(r, 400 * (t + 1)));
    }
  }
  throw lastErr;
}

/**
 * Loads the images the game needs before it can start. onProgress(0..1).
 * Required art is loaded with retries and throws if something cannot be fetched.
 * Stage environments (6-35) are optional: they load in the background and the game
 * draws the zone background until each one arrives.
 */
export async function loadAssets(onProgress = () => {}) {
  // Only what the first screens and the first run need. Reference art (outfits, trails,
  // bosses, chests) and stage environments load in the background afterwards; every
  // draw site treats a missing image as "skip or use a placeholder", so the game starts
  // without them.
  const required = [
    ...SPRITES.map((n) => [n, `assets/sprites/${n}.webp`]),
    ...POWERUP_SPRITES.map((n) => [n, `assets/powerups/${n}.webp`]),
    ...BACKGROUNDS.map((n) => [n, `assets/backgrounds/${n}.webp`]),
  ];
  let done = 0;
  await loadPool(required, 6, async ([name, url]) => {
    try {
      images.set(name, await loadWithRetry(url));
    } catch (e) {
      console.error('Asset failed:', url, e && e.message);
      throw e;
    }
    done++;
    onProgress(done / (required.length + 1));
  });

  // Background pass: reference art first (needed by the first boss, trails and outfits),
  // then the stage environments. Failures are logged and the fallbacks stay in place.
  const deferred = [
    ...REF_SPRITES.map((n) => [n, `assets/sprites/${n}.webp`, 'ref']),
    ...STAGE_BGS.map((n) => [n, `assets/bg/${n}.webp`, 'stage']),
  ];
  (async () => {
    await loadPool(deferred, 4, async ([name, url, kind]) => {
      try {
        images.set(name, await loadWithRetry(url, 2));
      } catch (e) {
        console.warn(kind === 'stage'
          ? 'Stage environment not loaded (zone background used):'
          : 'Reference art not loaded (placeholder used):', url);
      }
    });
  })();

  // pose measurements (optional: falls back to natural sizes)
  try {
    const res = await withTimeout(fetch('assets/sprites/pose_meta.json', { cache: 'no-cache' }), 8000, 'pose_meta');
    if (res.ok) poseMeta = await res.json();
  } catch (e) {
    poseMeta = {};
  }
  onProgress(1);
}
