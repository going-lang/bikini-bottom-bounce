// Touch + keyboard input. Left half of the play area = move left, right half = move right.
// Multiple fingers are tracked by pointer id, so releasing one finger never sticks.

export class Input {
  constructor(zoneEl, hooks = {}) {
    this.zone = zoneEl;
    this.hooks = hooks;
    this.swap = false;
    this.pointers = new Map(); // pointerId -> -1 | 1
    this.keys = { left: false, right: false };
    this.enabled = false;

    this._down = (e) => {
      if (!this.enabled) return;
      e.preventDefault();
      const rect = this.zone.getBoundingClientRect();
      const localX = (e.clientX - rect.left) / Math.max(1, rect.width);
      let side = localX < 0.5 ? -1 : 1;
      if (this.swap) side = -side;
      this.pointers.set(e.pointerId, side);
      try { this.zone.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    };
    this._up = (e) => {
      this.pointers.delete(e.pointerId);
    };
    this._key = (e, down) => {
      const k = e.code;
      if (k === 'ArrowLeft' || k === 'KeyA') this.keys.left = down;
      else if (k === 'ArrowRight' || k === 'KeyD') this.keys.right = down;
      else if (down && (k === 'Escape' || k === 'KeyP') && this.hooks.onPause) this.hooks.onPause();
    };
    this._kd = (e) => this._key(e, true);
    this._ku = (e) => this._key(e, false);
    this._blur = () => this.clear();

    this.zone.addEventListener('pointerdown', this._down);
    this.zone.addEventListener('pointerup', this._up);
    this.zone.addEventListener('pointercancel', this._up);
    this.zone.addEventListener('lostpointercapture', this._up);
    window.addEventListener('keydown', this._kd);
    window.addEventListener('keyup', this._ku);
    window.addEventListener('blur', this._blur);
  }

  /** Current steering direction: -1, 0 or 1. */
  dir() {
    let left = this.keys.left;
    let right = this.keys.right;
    for (const side of this.pointers.values()) {
      if (side < 0) left = true; else right = true;
    }
    if (left === right) return 0;
    return left ? -1 : 1;
  }

  clear() {
    this.pointers.clear();
    this.keys.left = false;
    this.keys.right = false;
  }

  setEnabled(on) {
    this.enabled = !!on;
    if (!on) this.clear();
  }

  destroy() {
    this.zone.removeEventListener('pointerdown', this._down);
    this.zone.removeEventListener('pointerup', this._up);
    this.zone.removeEventListener('pointercancel', this._up);
    this.zone.removeEventListener('lostpointercapture', this._up);
    window.removeEventListener('keydown', this._kd);
    window.removeEventListener('keyup', this._ku);
    window.removeEventListener('blur', this._blur);
  }
}
