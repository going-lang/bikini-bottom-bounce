// Local save data. Versioned, validated on load, and safe if localStorage is unavailable.

const KEY = 'bikinibottom-bounce.save';
const VERSION = 1;

export function defaultSave() {
  return {
    version: VERSION,
    coins: 0,
    premium: 0,
    bestScore: 0,
    bestHeight: 0,
    bestZone: 1,
    runs: 0,
    lifetimeCoins: 0,
    lifetimeTokens: 0,
    premiumCollected: 0,
    bubbles: 0,
    bounces: 0,
    enemiesHit: 0,
    enemiesDefeated: 0,  // enemies removed by jumping on them
    bossesDefeated: 0,
    revives: 0,
    purchases: 0,
    powerupsUsed: 0,
    powerups: {},
    owned: { characters: ['spongebob'], outfits: ['none'], effects: ['bubbles'] },
    equipped: { character: 'spongebob', outfit: 'none', effect: 'bubbles' },
    missionsClaimed: [],
    noHitRuns: 0,        // runs that reached BAND_M metres without a hit
    achievements: [],
    settings: { musicVol: 0.6, sfxVol: 0.8, sensitivity: 1, swap: false, reducedEffects: false },
    tutorialDone: false,
  };
}

function isObj(v) { return v && typeof v === 'object' && !Array.isArray(v); }

function merge(base, data) {
  const out = { ...base };
  for (const key of Object.keys(base)) {
    const bv = base[key];
    const dv = data[key];
    if (typeof bv === 'number') {
      if (typeof dv === 'number' && Number.isFinite(dv) && dv >= 0) out[key] = dv;
    } else if (typeof bv === 'string') {
      // equipped character / outfit / effect ids; loadSave() checks they are owned
      if (typeof dv === 'string') out[key] = dv;
    } else if (typeof bv === 'boolean') {
      if (typeof dv === 'boolean') out[key] = dv;
    } else if (Array.isArray(bv)) {
      if (Array.isArray(dv)) out[key] = dv.filter((x) => typeof x === 'string');
    } else if (isObj(bv)) {
      out[key] = merge(bv, isObj(dv) ? dv : {});
    }
  }
  return out;
}

// Reads a progress stat for missions and achievements. Lists count their entries.
export function statOf(save, key) {
  if (key === 'bestHeight') return save.bestHeight || 0;
  const v = save[key];
  if (Array.isArray(v)) return v.length;
  return typeof v === 'number' ? v : 0;
}

export function loadSave() {
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return defaultSave();
    const data = JSON.parse(raw);
    if (!isObj(data)) return defaultSave();
    const save = merge(defaultSave(), data);
    // make sure equipped items are owned
    if (!save.owned.characters.includes(save.equipped.character)) save.equipped.character = 'spongebob';
    if (!save.owned.outfits.includes(save.equipped.outfit)) save.equipped.outfit = 'none';
    if (!save.owned.effects.includes(save.equipped.effect)) save.equipped.effect = 'bubbles';
    if (!save.owned.characters.includes('spongebob')) save.owned.characters.unshift('spongebob');
    return save;
  } catch (e) {
    console.warn('Save data unreadable, starting fresh', e);
    return defaultSave();
  }
}

export function writeSave(save) {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(save));
    return true;
  } catch (e) {
    return false;
  }
}

export function clearSave() {
  try {
    window.localStorage.removeItem(KEY);
  } catch (e) { /* ignore */ }
}
