// Central game configuration: physics, zones, platforms, enemies, collectibles,
// power-ups, characters and shop items. Everything gameplay-related lives here so
// new zones / characters / hazards can be added without touching the engine.

export const LOGICAL_W = 540;
export const LOGICAL_H = 960;

export const PHYS = {
  gravity: 2000,          // px/s^2
  jumpVel: 1000,          // base bounce velocity -> apex ~250px
  maxFall: 1500,          // terminal velocity
  baseMaxSpeed: 380,      // sideways top speed (px/s)
  baseAccel: 1800,        // sideways acceleration while steering
  friction: 2600,         // deceleration when released
  wrapPad: 26,            // horizontal wrap margin (screen wrap)
  landHalfW: 16,          // feet hitbox half width used for landing
  hitHalfW: 16,           // body hitbox half width used for hazards
  hitTop: 72,             // hitbox top, relative to feet
  hitBottom: 8,           // hitbox bottom, relative to feet
  spriteH: 118,           // rendered SpongeBob height (px)
  invulnTime: 1.5,
};

// Difficulty ramps with height: 0 at the start, 1.0 at DIFF_METRES.
export const DIFF_METRES = 900;

// No health bar. A hit costs this share of the coins collected in the current run (rounded up).
// Coins are only lost from this run's total, never from coins saved before the run.
export const HIT_COIN_LOSS = 0.5;

// Zones are unlocked by height in metres. Add more entries to extend the game;
// the last zone repeats (with increasing difficulty) when the list runs out.
export const ZONES = [
  {
    id: 1, name: 'Bikini Bottom', subtitle: 'Easy waters', from: 0,
    bg: 'zone1_bikini_bottom', tint: 'rgba(0,0,0,0)', accent: '#7fe7ff',
    music: { root: 220, scale: [0, 2, 4, 7, 9], tempo: 104, wave: 'triangle' },
  },
  {
    id: 2, name: 'Jellyfish Fields', subtitle: 'Watch the jellies', from: 150,
    bg: 'zone2_jellyfish_fields', tint: 'rgba(120,60,200,0.08)', accent: '#ff9ce6',
    music: { root: 246.94, scale: [0, 2, 3, 7, 9], tempo: 112, wave: 'triangle' },
  },
  {
    id: 3, name: 'Goo Lagoon', subtitle: 'Faster and slimier', from: 350,
    bg: 'zone3_goo_lagoon', tint: 'rgba(120,200,40,0.10)', accent: '#b8ff5c',
    music: { root: 196, scale: [0, 3, 5, 7, 10], tempo: 122, wave: 'square' },
  },
  {
    id: 4, name: 'Krusty Krab Area', subtitle: 'Special platforms ahead', from: 600,
    bg: 'zone4_krusty_krab', tint: 'rgba(255,160,40,0.08)', accent: '#ffd23f',
    music: { root: 261.63, scale: [0, 2, 4, 7, 9], tempo: 128, wave: 'triangle' },
  },
  {
    id: 5, name: 'Rock Bottom', subtitle: 'Watch the skies', from: 900,
    bg: 'zone5_rock_bottom', tint: 'rgba(20,10,50,0.35)', accent: '#ff6b8a',
    music: { root: 174.61, scale: [0, 2, 3, 7, 8], tempo: 134, wave: 'square' },
  },
];

// Platform kinds. `sprite` is a key from the sprite manifest (assets.js).
// `w` is the rendered width in px; height follows the sprite's aspect ratio.
export const PLATFORMS = {
  normal:    { sprite: 'plat_sand',          w: 112 },
  small:     { sprite: 'plat_sand',          w: 74 },
  large:     { sprite: 'plat_large',         w: 200 },
  moving:    { sprite: 'plat_moving',        w: 118 },
  bounce:    { sprite: 'plat_bounce',        w: 110, mult: 1.35 },
  breakable: { sprite: 'plat_breakable',     w: 116 },
  special:   { sprite: 'plat_special_jelly', w: 96,  mult: 1.45, coins: 5 },
  boost:     { sprite: 'plat_boost',          w: 100, mult: 1.6 },
  ice:       { sprite: 'plat_ice',            w: 104, ice: true },
  vanish:    { sprite: 'plat_disappearing',   w: 100, vanish: true },
};

// Enemies / hazards. r = circular hit radius, minM = first height (m) they appear.
export const ENEMIES = {
  jelly:      { sprite: 'enemy_jelly',         w: 58, r: 19, minM: 40,  weight: 10, stompable: true },
  fastJelly:  { sprite: 'enemy_jelly_fast',    w: 80, r: 20, minM: 150, weight: 6, stompable: true },
  urchin:     { sprite: 'enemy_urchin',        w: 52, r: 18, minM: 200, weight: 5, stompable: false },
  largeJelly: { sprite: 'enemy_jelly_large',   w: 84, r: 34, minM: 350, weight: 4, stompable: true },
  mine:       { sprite: 'enemy_mine',          w: 54, r: 24, minM: 350, weight: 4 },
  bubble:     { sprite: 'enemy_bubble_hazard', w: 56, r: 24, minM: 350, weight: 3, stompable: true },
  rock:       { sprite: 'enemy_rock',          w: 56, r: 24, minM: 900, weight: 0 }, // timer spawned
  blade:      { sprite: 'hazard_rotating_blade', w: 52, r: 22, minM: 120, weight: 4 },
  zap:        { sprite: 'hazard_jelly_zap',      w: 50, r: 18, minM: 250, weight: 3 },
  spikes:     { sprite: 'hazard_spike_platform', w: 74, r: 24, minM: 180, weight: 3 },
};

// Collectibles. coins = coin value, points = score value, premium = golden spatulas.
export const COLLECTIBLES = {
  coin:     { sprite: 'coin',        w: 26, r: 18, points: 5,   coins: 1 },
  bubble:   { sprite: 'bubble',      w: 26, r: 18, points: 25,  coins: 0, bubble: true },
  token:    { sprite: 'jelly_token', w: 28, r: 18, points: 20,  coins: 5 },
  spatula:  { sprite: 'spatula',     w: 32, r: 20, points: 100, coins: 0, premium: 1 },
  treasure: { sprite: 'treasure',    w: 40, r: 22, points: 200, coins: 30, premium: 2 },
};

// Relative spawn weights for bonus collectibles on a path (per row roll).
export const BONUS_WEIGHTS = [
  { type: 'bubble', weight: 0.10 },
  { type: 'token', weight: 0.06 },
  { type: 'spatula', weight: 0.03, minZone: 1 },
  { type: 'treasure', weight: 0.012, minZone: 2 },
];

// Power-ups. duration in seconds (0 = instant / one-shot).
// `sprite` is a key in assets/powerups/ (extracted from the power-up reference sheet).
export const POWERUPS = {
  superBounce: { name: 'Super Bounce', duration: 8,  color: '#ffd23f', sprite: 'pu_super_bounce', weight: 16, desc: 'Much stronger bounces.' },
  shield:      { name: 'Bubble Shield', duration: 15, color: '#7fe7ff', sprite: 'pu_bubble_shield', weight: 14, desc: 'Blocks one hazard hit.' },
  magnet:      { name: 'Jellyfish Magnet', duration: 8, color: '#ff7ad9', sprite: 'pu_jelly_magnet', weight: 14, desc: 'Pulls in nearby coins.' },
  speed:       { name: 'Speed Boost', duration: 6,  color: '#7CFF6B', sprite: 'pu_speed_boost', weight: 14, desc: 'Faster sideways movement.' },
  double:      { name: 'Double Coins', duration: 10, color: '#ffe066', sprite: 'pu_double_coins', weight: 14, desc: 'Coins count double.' },
  slowmo:      { name: 'Slow Motion', duration: 6,  color: '#b58bff', sprite: 'pu_slow_motion', weight: 10, desc: 'Enemies slow down.' },
  coinGuard:   { name: 'Coin Guard', duration: 0,  color: '#ff6b6b', sprite: 'pu_extra_life', weight: 6, desc: 'Your next hit costs no coins.' },
  megaBounce:  { name: 'Mega Bounce', duration: 0, color: '#ff4da6', sprite: 'pu_mega_bounce', weight: 4, desc: 'Next bounce launches very high.' },
};

export const POWERUP_SPAWN_CHANCE = 0.045; // per row (rises slightly with zone)

// Characters. `art` = true when official reference art is available.
// `mods` are small, non-pay-to-win ability modifiers.
export const RARITY = {
  common:    { label: 'COMMON',    color: '#9be15d' },
  rare:      { label: 'RARE',      color: '#4cc9f0' },
  epic:      { label: 'EPIC',      color: '#b983ff' },
  legendary: { label: 'LEGENDARY', color: '#ffb703' },
};

export const CHARACTERS = [
  { id: 'spongebob', name: 'SpongeBob', rarity: 'common', price: 0, currency: 'coins', art: true,
    ability: 'Balanced movement and jumping.', mods: {} },
  { id: 'patrick', name: 'Patrick', rarity: 'rare', price: 1500, currency: 'coins', art: true, sprite: 'char_patrick',
    ability: 'Slightly stronger bounce.', mods: { bounce: 1.07 } },
  { id: 'sandy', name: 'Sandy', rarity: 'rare', price: 1800, currency: 'coins', art: true, sprite: 'char_sandy',
    ability: 'Improved horizontal control.', mods: { accel: 1.25, maxSpeed: 1.04 } },
  { id: 'squidward', name: 'Squidward', rarity: 'epic', price: 20, currency: 'premium', art: true, sprite: 'char_squidward',
    ability: 'Occasional extra bounce.', mods: { extraBounceChance: 0.12 } },
  { id: 'mrkrabs', name: 'Mr. Krabs', rarity: 'epic', price: 25, currency: 'premium', art: true, sprite: 'char_mrkrabs',
    ability: 'Small coin-earning bonus.', mods: { coinMult: 1.1 } },
  { id: 'gary', name: 'Gary', rarity: 'common', price: 800, currency: 'coins', art: true, sprite: 'char_gary',
    ability: 'Stronger jellyfish magnet range.', mods: { magnet: 1.15 } },
];

export const OUTFITS = [
  { id: 'none', name: 'Default', rarity: 'common', price: 0, currency: 'coins' },
  { id: 'captain', name: 'Pirate Captain', rarity: 'common', price: 400, currency: 'coins', sprite: 'outfit_pirate' },
  { id: 'bubble_helmet', name: 'Astronaut', rarity: 'rare', price: 900, currency: 'coins', sprite: 'outfit_astronaut' },
  { id: 'golden_crown', name: 'Royal King', rarity: 'epic', price: 15, currency: 'premium', sprite: 'outfit_royal' },
  { id: 'superhero', name: 'Super Sponge', rarity: 'rare', price: 1000, currency: 'coins', sprite: 'outfit_superhero' },
  { id: 'ninja', name: 'Ninja', rarity: 'rare', price: 1100, currency: 'coins', sprite: 'outfit_ninja' },
  { id: 'beach', name: 'Beach Day', rarity: 'common', price: 350, currency: 'coins', sprite: 'outfit_beach' },
  { id: 'sports', name: 'Hoops Star', rarity: 'common', price: 500, currency: 'coins', sprite: 'outfit_sports' },
  { id: 'winter', name: 'Winter Cozy', rarity: 'common', price: 450, currency: 'coins', sprite: 'outfit_winter' },
  { id: 'space', name: 'Space Ranger', rarity: 'epic', price: 18, currency: 'premium', sprite: 'outfit_space' },
  { id: 'golden', name: 'Golden Sponge', rarity: 'epic', price: 25, currency: 'premium', sprite: 'outfit_golden' },
];

export const EFFECTS = [
  { id: 'bubbles', name: 'Bubble Trail', rarity: 'common', price: 0, currency: 'coins', color: '#bfefff', sprite: 'fx_bubble_trail' },
  { id: 'sparkle', name: 'Star Trail', rarity: 'common', price: 300, currency: 'coins', color: '#fff08a', sprite: 'fx_star_trail' },
  { id: 'golden', name: 'Golden Coin Trail', rarity: 'rare', price: 700, currency: 'coins', color: '#ffb703', sprite: 'fx_golden_coin_trail' },
  { id: 'rainbow', name: 'Rainbow Trail', rarity: 'epic', price: 12, currency: 'premium', color: 'rainbow', sprite: 'fx_rainbow_trail' },
  { id: 'water', name: 'Water Splash', rarity: 'common', price: 250, currency: 'coins', color: '#7fd8ff', sprite: 'fx_water_trail' },
  { id: 'jellyfish', name: 'Jellyfish Spark', rarity: 'rare', price: 900, currency: 'coins', color: '#c77dff', sprite: 'fx_jellyfish_trail' },
  { id: 'lightning', name: 'Lightning Trail', rarity: 'epic', price: 14, currency: 'premium', color: '#9ff3ff', sprite: 'fx_lightning_trail' },
  { id: 'ocean', name: 'Ocean Aura', rarity: 'rare', price: 1000, currency: 'coins', color: '#4cc9f0', sprite: 'fx_ocean_aura' },
  { id: 'cosmic', name: 'Cosmic Trail', rarity: 'epic', price: 16, currency: 'premium', color: '#b5179e', sprite: 'fx_cosmic_trail' },
  { id: 'goldaura', name: 'Golden Glow', rarity: 'epic', price: 18, currency: 'premium', color: '#ffd23f', sprite: 'fx_golden_aura' },
];

export const REVIVE_COST_COINS = 100;

export const MISSIONS = [
  { id: 'm_climb100', text: 'Reach 100 m in one run', stat: 'bestHeight', target: 100, reward: { coins: 200 } },
  { id: 'm_coins500', text: 'Collect 500 coins in total', stat: 'lifetimeCoins', target: 500, reward: { coins: 200 } },
  { id: 'm_powers3', text: 'Use 3 power-ups', stat: 'powerupsUsed', target: 3, reward: { coins: 150 } },
  { id: 'm_bubbles10', text: 'Pop 10 bubbles', stat: 'bubbles', target: 10, reward: { coins: 100 } },
  { id: 'm_zone3', text: 'Reach Goo Lagoon (Zone 3)', stat: 'bestZone', target: 3, reward: { premium: 1 } },
  { id: 'm_bounces100', text: 'Bounce 100 times', stat: 'bounces', target: 100, reward: { coins: 200 } },
  { id: 'm_tokens50', text: 'Collect 50 jellyfish tokens', stat: 'lifetimeTokens', target: 50, reward: { coins: 150 } },
  { id: 'm_runs10', text: 'Finish 10 runs', stat: 'runs', target: 10, reward: { coins: 150 } },
  { id: 'm_climb300', text: 'Reach 300 m in one run', stat: 'bestHeight', target: 300, reward: { coins: 300 } },
  { id: 'm_nohit3', text: 'Reach 60 m without being hit, 3 times', stat: 'noHitRuns', target: 3, reward: { coins: 250 } },
  { id: 'm_defeat25', text: 'Defeat 25 enemies by jumping on them', stat: 'enemiesDefeated', target: 25, reward: { coins: 200 } },
  { id: 'm_boss1', text: 'Defeat a boss', stat: 'bossesDefeated', target: 1, reward: { premium: 1 } },
];

export const ACHIEVEMENTS = [
  { id: 'first_splash', name: 'First Splash', text: 'Finish your first run', stat: 'runs', target: 1 },
  { id: 'h100', name: 'Bubble Climber', text: 'Reach 100 m', stat: 'bestHeight', target: 100 },
  { id: 'h500', name: 'Kelp Crawler', text: 'Reach 500 m', stat: 'bestHeight', target: 500 },
  { id: 'h1000', name: 'Bikini Bottom Legend', text: 'Reach 1000 m', stat: 'bestHeight', target: 1000 },
  { id: 'coins1000', name: 'Coin Hoarder', text: 'Collect 1000 coins in total', stat: 'lifetimeCoins', target: 1000 },
  { id: 'zone5', name: 'Rock Bottom Survivor', text: 'Reach Rock Bottom', stat: 'bestZone', target: 5 },
  { id: 'revive', name: 'Second Chance', text: 'Revive once', stat: 'revives', target: 1 },
  { id: 'shop', name: 'Shell Shopper', text: 'Buy an item in the shop', stat: 'purchases', target: 1 },
  { id: 'powers25', name: 'Power Hungry', text: 'Use 25 power-ups', stat: 'powerupsUsed', target: 25 },
  { id: 'spatula5', name: 'Golden Hunter', text: 'Collect 5 golden spatulas', stat: 'premiumCollected', target: 5 },
  { id: 'h1500', name: 'Deep Diver', text: 'Reach 1500 m', stat: 'bestHeight', target: 1500 },
  { id: 'h2100', name: 'Ocean Champion', text: 'Reach 2100 m', stat: 'bestHeight', target: 2100 },
  { id: 'untouched', name: 'Untouchable', text: 'Reach 60 m without being hit', stat: 'noHitRuns', target: 1 },
  { id: 'stomp50', name: 'Jelly Stomper', text: 'Defeat 50 enemies by jumping on them', stat: 'enemiesDefeated', target: 50 },
  { id: 'bossdown', name: 'Boss Breaker', text: 'Defeat a boss', stat: 'bossesDefeated', target: 1 },
];

export const TUTORIAL_STEPS = [
  { title: 'Move', text: 'Touch the LEFT or RIGHT side of the screen and hold to move. Let go to stop.', sprite: 'sb_wobble' },
  { title: 'Bounce', text: 'SpongeBob jumps automatically. Just steer him.', sprite: 'sb_jump' },
  { title: 'Land', text: 'Land on platforms to keep climbing higher.', sprite: 'plat_sand' },
  { title: 'Collect', text: 'Grab coins and bubbles along the way.', sprite: 'coin' },
  { title: 'Avoid', text: 'Dodge jellyfish, urchins, mines and falling rocks. Each hit costs half the coins you collected this run.', sprite: 'enemy_jelly' },
  { title: 'Climb', text: 'Keep climbing and beat your best score!', sprite: 'sb_idle' },
];


// ---------- endless height bands ----------------------------------------------
// The run has no stages and no goal. Height is split into bands of BAND_M metres. A band sets
// the background, the difficulty and the world name. Worlds group five bands each, following the
// progression map (reference #21). Bands past BAND_MAX keep the hardest settings.
export const BAND_M = 60;
export const BAND_MAX = 35;
export const STAGE_COUNT = BAND_MAX; // number of background tiles and worlds x bands
export const BOSS_EVERY_M = 300;     // a milestone boss appears every 300 m, in order, looping

/** Height band for a height in metres. Band 1 is 0-59 m, band 2 is 60-119 m, and so on. */
export function bandFor(metres) {
  return Math.min(BAND_MAX, Math.floor(Math.max(0, metres) / BAND_M) + 1);
}

/** Milestone boss key for the k-th boss (k = 1, 2, ...): cycles the seven mapped bosses. */
export function bossKeyFor(k) {
  return ((k - 1) % 7 + 1) * 5;
}

export const WORLDS = [
  { n: 1, name: 'Bikini Bottom', from: 1, to: 5 },
  { n: 2, name: 'Jellyfish Fields', from: 6, to: 10 },
  { n: 3, name: 'Rock Bottom', from: 11, to: 15 },
  { n: 4, name: 'Goo Lagoon', from: 16, to: 20 },
  { n: 5, name: 'Kelp Forest', from: 21, to: 25 },
  { n: 6, name: "Flying Dutchman's Shipwreck", from: 26, to: 30 },
  { n: 7, name: "Mermaid Man & Barnacle Boy's Lair", from: 31, to: 35 },
];

// Milestone bosses from reference #21, keyed by boss key (see bossKeyFor). They appear every
// BOSS_EVERY_M metres in this order, then loop.
export const MILESTONE_BOSSES = {
  5: "Plankton's Kelp Forest",
  10: "King Jellyfish's Buzz",
  15: 'The Tattletale Strangler',
  20: "Larry's Lobster Lift",
  25: "The Dirty Bubble's Menace",
  30: 'Ghostly Galleon',
  35: "Man Ray's Revenge",
};

// Boss encounter tuning. A milestone boss appears every BOSS_EVERY_M metres of the endless run.
// Three stomps defeat it. If it is not beaten within `timeLimit` seconds it leaves, so a fight
// can never soft-lock a stage. Every attack shows a warning before it can hurt.
export const BOSS_TUNE = { hp: 3, timeLimit: 60, attackGap: 2.6, coinReward: 60 };

// Boss art: one sprite per milestone boss key (reference #15, plus the generated lobster). Separate asset files.
export const BOSS_ART = {
  5:  { sprite: 'boss_deep_sea_guardian',  w: 150 },
  10: { sprite: 'boss_giant_jellyfish',    w: 170 },
  15: { sprite: 'boss_rock_guardian_dark', w: 160 },
  20: { sprite: 'boss_larry_lobster',      w: 170 }, // generated lobster art (see assets/reference/MANIFEST.md)
  25: { sprite: 'boss_angry_bubble',       w: 140 },
  30: { sprite: 'boss_elite_jellyfish',    w: 130 },
  35: { sprite: 'boss_final_ocean',        w: 230 },
};

// Platform-difficulty patterns from reference #14. Each stage uses one pattern.
// Multipliers scale the platform-kind weights; gapAdd widens/narrows vertical gaps (px).
export const PATTERNS = {
  1:  { name: 'Easy Start',          gapAdd: -12, enemyMul: 0.5 },
  2:  { name: 'Slightly Tougher',    gapAdd: -4,  moveMul: 0.3, enemyMul: 0.7 },
  3:  { name: 'Moving Platforms',    moveMul: 2.2, enemyMul: 0.9 },
  4:  { name: 'Wider Vertical Gaps', gapAdd: 18,  moveMul: 0.8, enemyMul: 1 },
  5:  { name: 'Narrow Spacing',      gapAdd: -6,  largeMul: 0.3, boostMul: 0.5 },
  6:  { name: 'Breakable Platforms', breakMul: 2.5, enemyMul: 1 },
  7:  { name: 'Steep Zigzag',        gapAdd: 6,   zigMul: 0.95, enemyMul: 1.1 },
  8:  { name: 'Small Moving Gaps',   gapAdd: 10,  moveMul: 1.8, enemyMul: 1.1 },
  9:  { name: 'Complex Tightness',   gapAdd: 4,   vanishMul: 2, iceMul: 2, enemyMul: 1.25 },
  10: { name: 'Master Challenge',    gapAdd: 6,   moveMul: 1.5, breakMul: 1.5, vanishMul: 1.5, iceMul: 1.5, enemyMul: 1.4 },
};

// Height band n (see bandFor): the background, world name and difficulty for that band.
// Players only see the world name and the height. The run never ends on a band.
export function stageInfo(n) {
  const num = Math.max(1, Math.min(BAND_MAX, Math.round(Number(n)) || 1));
  const world = WORLDS[Math.floor((num - 1) / 5)];
  const pattern = num <= 2 ? 1 : ((num - 3) % 8) + 2;
  return {
    n: num,
    world: world.n,
    worldName: world.name,
    from: (num - 1) * BAND_M,
    to: num * BAND_M,
    diffOffset: (num - 1) * 7,
    pattern,
    patternName: PATTERNS[pattern].name,
  };
}

// Low-end devices (4 GB RAM or less, or 4 cores or fewer) get a cheaper render: the main canvas
// is capped at 2x pixel ratio and the full-screen backdrop is redrawn every other frame.
// Set ?lowend=1 (or ?lowend=0) in the URL to force it for testing.
export const LOW_END = (() => {
  const q = typeof location !== 'undefined' ? new URLSearchParams(location.search).get('lowend') : null;
  if (q === '1') return true;
  if (q === '0') return false;
  const mem = (typeof navigator !== 'undefined' && navigator.deviceMemory) || 8;
  const cores = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency) || 8;
  return mem <= 4 || cores <= 4;
})();
