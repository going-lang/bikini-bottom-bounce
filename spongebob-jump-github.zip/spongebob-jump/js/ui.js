// DOM UI: screen switching, menus, shop, missions, HUD and dialogs.
// Rendering only. Game decisions (buying, claiming, starting runs) are made in main.js.
import { CHARACTERS, OUTFITS, EFFECTS, RARITY, MISSIONS, ACHIEVEMENTS, TUTORIAL_STEPS, POWERUPS, ZONES, REVIVE_COST_COINS, WORLDS, stageInfo, bandFor, BAND_M } from './config.js';
import { statOf } from './storage.js';
import { Assets } from './assets.js';
import { Game } from './game.js';

export const $ = (id) => document.getElementById(id);

let toastTimer = null;
let currentScreen = 'loading';

let screenListener = null;
/** main.js registers one callback, run after every screen change (used to show or hide the ad banner). */
export function onScreenChange(fn) { screenListener = fn; }

export function showScreen(name) {
  currentScreen = name;
  const map = { splash: 'screen-splash', loading: 'screen-loading', menu: 'screen-menu', stages: 'screen-stages', shop: 'screen-shop', missions: 'screen-missions', settings: 'screen-settings', howto: 'screen-howto' };
  for (const key of Object.keys(map)) {
    const el = $(map[key]);
    if (el) el.classList.toggle('active', key === name);
  }
  // the full-screen environment is shown only while a run is on screen
  document.body.classList.toggle('in-game', name === 'game');
  if (screenListener) screenListener(name);
}

export function currentScreenName() { return currentScreen; }

export function showModal(id) { const el = $(id); if (el) el.classList.remove('hidden'); }
export function hideModal(id) { const el = $(id); if (el) el.classList.add('hidden'); }
export function isModalOpen(id) { const el = $(id); return !!el && !el.classList.contains('hidden'); }

export function toast(msg, ms = 2200) {
  const el = $('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), ms);
}

export function fmt(n) { return Math.floor(n || 0).toLocaleString('en-US'); }

// ---------- character / item artwork ----------------------------------------
/** Draws a card preview into a 150x150 canvas. */
export function drawPreview(canvas, kind, item, save) {
  const ctx = canvas.getContext('2d');
  const size = 150;
  canvas.width = size; canvas.height = size;
  ctx.clearRect(0, 0, size, size);
  // reference artwork: fit the whole sprite inside the card, keeping its proportions
  if (item.sprite) {
    const art = Assets.get(item.sprite);
    if (art) {
      const k = Math.min((size - 16) / art.width, (size - 16) / art.height);
      const dw = art.width * k, dh = art.height * k;
      ctx.drawImage(art, (size - dw) / 2, (size - dh) / 2, dw, dh);
      return;
    }
  }
  if (kind === 'characters' && !item.art) {
    ctx.fillStyle = 'rgba(20,50,80,0.25)';
    ctx.beginPath(); ctx.arc(size / 2, size / 2 + 6, 52, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#0a3a5a';
    ctx.font = '52px Impact, Arial Black, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('?', size / 2, size / 2 + 18);
    return;
  }
  const sb = Assets.get('sb_idle');
  if (!sb) return;
  const meta = Assets.poseMeta() || {};
  const idleMeta = meta.sb_idle || { h: sb.height, sw: sb.width * 0.8, cx: sb.width / 2, st: 0, sb: sb.height };
  const h = 118;
  const s = h / idleMeta.h;
  const dw = sb.width * s;
  const dh = sb.height * s;
  const left = size / 2 - idleMeta.cx * s;
  const bottom = size - 14;
  const top = bottom - dh;
  // ground shadow
  ctx.fillStyle = 'rgba(0,0,0,0.18)';
  ctx.beginPath(); ctx.ellipse(size / 2, bottom, 42, 7, 0, 0, Math.PI * 2); ctx.fill();
  ctx.drawImage(sb, left, top, dw, dh);

  if (kind === 'outfits' && item.id !== 'none') {
    Game.drawOutfitAt(ctx, item.id, size / 2, top + idleMeta.st * s, idleMeta.sw * s, top + (idleMeta.st + (idleMeta.sb - idleMeta.st) / 2) * s);
  }
  if (kind === 'effects') {
    ctx.save();
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2 + 0.3;
      const r = 62 + (i % 3) * 8;
      ctx.globalAlpha = 0.85 - (i % 3) * 0.2;
      ctx.fillStyle = item.color === 'rainbow' ? `hsl(${i * 40}, 90%, 70%)` : item.color;
      ctx.beginPath();
      ctx.arc(size / 2 + Math.cos(a) * r * 0.9, bottom - 40 + Math.sin(a) * r * 0.7, 4 + (i % 2) * 2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }
}

// ---------- menu ------------------------------------------------------------
export function renderMenu(save) {
  $('menu-coins').textContent = fmt(save.coins);
  $('menu-premium').textContent = fmt(save.premium);
  $('menu-best').textContent = fmt(save.bestScore);
  $('menu-height').textContent = fmt(save.bestHeight) + ' m';
  // endless run: the chips show runs played and the world reached at the best height
  const info = stageInfo(bandFor(save.bestHeight || 0));
  $('menu-stage').textContent = fmt(save.runs || 0);
  $('menu-world').textContent = info.worldName;
  // The reference artwork already shows the default SpongeBob. Only overlay the hero when the
  // player has equipped a different character or an outfit (outfit art is a full figure).
  const eq = CHARACTERS.find((c) => c.id === save.equipped.character) || CHARACTERS[0];
  const outfit = OUTFITS.find((o) => o.id === save.equipped.outfit);
  // the menu always shows the equipped hero (the reference menu has no baked character)
  const heroSprite = (outfit && outfit.sprite) || (eq.id !== 'spongebob' ? eq.sprite : null) || 'sb_idle';
  $('menu-hero').src = `assets/sprites/${heroSprite}.webp`;
  $('menu-hero-name').textContent = eq.name;
}

// ---------- shop ------------------------------------------------------------
const SHOP_LISTS = { characters: CHARACTERS, outfits: OUTFITS, effects: EFFECTS };
const OWNED_KEY = { characters: 'characters', outfits: 'outfits', effects: 'effects' };
const EQUIP_KEY = { characters: 'character', outfits: 'outfit', effects: 'effect' };

// the item selected in the featured panel, per shop tab (defaults to the equipped item)
const shopFocus = {};

/** Featured panel: the selected item, large, with its rarity, ability and one action button. */
function renderFeature(save, tab, item, handlers) {
  const box = $('shop-feature');
  box.innerHTML = '';
  const isOwned = (save.owned[OWNED_KEY[tab]] || []).includes(item.id);
  const isEq = save.equipped[EQUIP_KEY[tab]] === item.id;

  const left = document.createElement('div');
  left.className = 'feat-art';
  const cv = document.createElement('canvas');
  left.appendChild(cv);
  drawPreview(cv, tab, item, save);
  box.appendChild(left);

  const info = document.createElement('div');
  info.className = 'feat-info';
  const rar = RARITY[item.rarity] || RARITY.common;
  info.innerHTML = `<h3></h3><span class="feat-rarity" style="background:${rar.color}">${rar.label}</span>`
    + `<div class="feat-label">Ability</div><p class="feat-desc"></p>`;
  info.querySelector('h3').textContent = item.name;
  info.querySelector('.feat-desc').textContent = item.ability || item.desc || '';

  const btn = document.createElement('button');
  btn.className = 'btn feat-btn';
  if (isEq) {
    btn.textContent = 'EQUIPPED';
    btn.classList.add('green');
    btn.disabled = true;
  } else if (isOwned) {
    btn.textContent = 'EQUIP';
    btn.classList.add('blue');
    btn.addEventListener('click', () => handlers.equip(tab, item.id));
  } else if (tab === 'characters' && !item.art) {
    btn.textContent = 'COMING SOON';
    btn.classList.add('locked');
    btn.disabled = true;
  } else {
    const cur = item.currency === 'premium' ? 'spatula' : 'coin';
    const have = item.currency === 'premium' ? save.premium : save.coins;
    btn.innerHTML = `<img src="assets/sprites/${cur}.webp" alt=""><span></span>`;
    btn.querySelector('span').textContent = fmt(item.price);
    if (have < item.price) {
      btn.classList.add('locked');
      btn.title = `Need ${fmt(item.price - have)} more`;
    } else {
      btn.classList.add('green');
    }
    btn.addEventListener('click', () => handlers.buy(tab, item.id));
  }
  info.appendChild(btn);
  box.appendChild(info);
}

export function renderShop(save, tab, handlers) {
  $('shop-coins').textContent = fmt(save.coins);
  $('shop-premium').textContent = fmt(save.premium);
  const grid = $('shop-grid');
  grid.innerHTML = '';
  const list = SHOP_LISTS[tab];
  const owned = save.owned[OWNED_KEY[tab]] || [];
  const equipped = save.equipped[EQUIP_KEY[tab]];
  const focusId = shopFocus[tab] || equipped;
  const focus = list.find((i) => i.id === focusId) || list[0];
  renderFeature(save, tab, focus, handlers);
  for (const item of list) {
    const card = document.createElement('div');
    const isOwned = owned.includes(item.id);
    const isEq = equipped === item.id;
    card.className = 'item-card' + (isEq ? ' equipped' : '') + (!isOwned ? ' locked' : '') + (item.id === focus.id ? ' focused' : '');
    card.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      shopFocus[tab] = item.id;
      renderShop(save, tab, handlers);
    });

    const artBox = document.createElement('div');
    artBox.className = 'art-box';
    const cv = document.createElement('canvas');
    artBox.appendChild(cv);
    if (tab === 'characters' && !item.art) {
      const soon = document.createElement('div');
      soon.className = 'soon';
      soon.textContent = 'ART COMING SOON';
      artBox.appendChild(soon);
    }
    card.appendChild(artBox);

    const rar = RARITY[item.rarity] || RARITY.common;
    const badge = document.createElement('span');
    badge.className = 'rarity';
    badge.style.background = rar.color;
    badge.textContent = rar.label;
    card.appendChild(badge);

    const name = document.createElement('div');
    name.className = 'item-name';
    name.textContent = item.name;
    card.appendChild(name);

    const desc = document.createElement('div');
    desc.className = 'item-desc';
    desc.textContent = item.ability || '';
    card.appendChild(desc);

    const btn = document.createElement('button');
    btn.className = 'btn';
    if (isEq) {
      btn.textContent = 'EQUIPPED';
      btn.classList.add('green');
      btn.disabled = true;
    } else if (isOwned) {
      btn.textContent = 'EQUIP';
      btn.classList.add('blue');
      btn.addEventListener('click', () => handlers.equip(tab, item.id));
    } else {
      const priceRow = document.createElement('div');
      priceRow.className = 'price';
      const cur = item.currency === 'premium' ? 'spatula' : 'coin';
      const cost = item.price;
      const have = item.currency === 'premium' ? save.premium : save.coins;
      priceRow.innerHTML = `<img src="assets/sprites/${cur}.webp" alt=""><span>${fmt(cost)}</span>`;
      if (tab === 'characters' && !item.art) {
        btn.textContent = 'COMING SOON';
        btn.classList.add('locked');
        btn.disabled = true;
      } else {
        btn.innerHTML = '';
        btn.appendChild(priceRow);
        if (have < cost) {
          btn.classList.add('locked');
          btn.title = `Need ${fmt(cost - have)} more`;
        } else {
          btn.classList.add('green');
        }
        btn.addEventListener('click', () => handlers.buy(tab, item.id));
      }
    }
    card.appendChild(btn);
    grid.appendChild(card);
    drawPreview(cv, tab, item, save);
  }
}

// ---------- missions / achievements / stats ----------------------------------
function statValue(save, key) {
  return statOf(save, key);
}

export function renderMissions(save, handlers) {
  $('mis-coins').textContent = fmt(save.coins);
  const list = $('missions-list');
  list.innerHTML = '';
  for (const m of MISSIONS) {
    const val = Math.min(m.target, statValue(save, m.stat));
    const done = val >= m.target;
    const claimed = save.missionsClaimed.includes(m.id);
    const reward = [];
    if (m.reward.coins) reward.push(`${m.reward.coins} coins`);
    if (m.reward.premium) reward.push(`${m.reward.premium} spatula`);
    const row = document.createElement('div');
    row.className = 'row-card';
    row.innerHTML = `
      <div class="txt">
        <b>${m.text}</b>
        <span>Reward: ${reward.join(' + ')}</span>
        <div class="bar thin"><div style="width:${Math.round(val / m.target * 100)}%"></div></div>
        <span>${fmt(val)} / ${fmt(m.target)}</span>
      </div>`;
    const btn = document.createElement('button');
    btn.className = 'btn';
    if (claimed) {
      btn.textContent = 'CLAIMED';
      btn.disabled = true;
      btn.classList.add('locked');
    } else if (done) {
      btn.textContent = 'CLAIM';
      btn.classList.add('green');
      btn.addEventListener('click', () => handlers.claim(m.id));
    } else {
      btn.textContent = 'LOCKED';
      btn.disabled = true;
      btn.classList.add('locked');
    }
    row.appendChild(btn);
    list.appendChild(row);
  }

  const al = $('achievements-list');
  al.innerHTML = '';
  for (const a of ACHIEVEMENTS) {
    const val = Math.min(a.target, statValue(save, a.stat));
    const done = val >= a.target;
    const row = document.createElement('div');
    row.className = 'row-card';
    row.innerHTML = `
      <div class="txt">
        <b>${done ? '★ ' : ''}${a.name}</b>
        <span>${a.text}</span>
        <div class="bar thin"><div style="width:${Math.round(val / a.target * 100)}%"></div></div>
      </div>
      <span class="badge" style="background:${done ? '#ffe14d' : '#e8e0c8'}">${done ? 'DONE' : fmt(val) + '/' + fmt(a.target)}</span>`;
    al.appendChild(row);
  }

  const sl = $('stats-list');
  sl.innerHTML = '';
  const lines = [
    ['Runs played', fmt(save.runs)],
    ['Best score', fmt(save.bestScore)],
    ['Highest height', fmt(save.bestHeight) + ' m'],
    ['Best zone reached', ZONES[Math.min(ZONES.length, save.bestZone) - 1].name],
    ['Total coins collected', fmt(save.lifetimeCoins)],
    ['Golden spatulas collected', fmt(save.premiumCollected)],
    ['Bubbles popped', fmt(save.bubbles)],
    ['Bounces', fmt(save.bounces)],
    ['Hazards hit', fmt(save.enemiesHit)],
    ['Revives used', fmt(save.revives)],
    ['Power-ups used', fmt(save.powerupsUsed)],
  ];
  for (const key of Object.keys(POWERUPS)) {
    lines.push([POWERUPS[key].name, fmt(save.powerups[key] || 0)]);
  }
  for (const [k, v] of lines) {
    const row = document.createElement('div');
    row.className = 'stat-line';
    row.innerHTML = `<span>${k}</span><b>${v}</b>`;
    sl.appendChild(row);
  }
}

// ---------- settings --------------------------------------------------------
export function renderSettings(save) {
  const s = save.settings;
  $('set-music').value = s.musicVol;
  $('set-sfx').value = s.sfxVol;
  $('set-sens').value = s.sensitivity;
  $('set-swap').checked = !!s.swap;
  $('set-reduced').checked = !!s.reducedEffects;
  $('set-music-v').textContent = Math.round(s.musicVol * 100) + '%';
  $('set-sfx-v').textContent = Math.round(s.sfxVol * 100) + '%';
  $('set-sens-v').textContent = Math.round(s.sensitivity * 100) + '%';
}

// ---------- HUD -------------------------------------------------------------

let lastHudKey = '';
export function renderHud(h) {
  const key = `${h.score}|${h.metres}|${h.coins}|${h.zone}|${h.timers.map((t) => t.key + Math.ceil(t.remaining)).join(',')}`;
  if (key === lastHudKey) return;
  lastHudKey = key;
  $('hud-score').textContent = fmt(h.score);
  $('hud-height').textContent = fmt(h.metres);
  $('hud-coins').textContent = fmt(h.coins);
  $('hud-zone').textContent = h.zone;
  const box = $('hud-powers');
  box.innerHTML = '';
  for (const t of h.timers) {
    const chip = document.createElement('div');
    chip.className = 'chip';
    const def = POWERUPS[t.key];
    const iconImg = def && def.sprite ? Assets.get(def.sprite) : null;
    const icon = iconImg ? `<img src="${iconImg.src}" alt="">` : '';
    const pct = t.max > 0 ? Math.max(0, Math.min(100, t.remaining / t.max * 100)) : 100;
    chip.innerHTML = `
      <span class="dot" style="background:${t.color}">${icon}</span>
      <span>${t.name}</span>
      <span class="meter"><div style="width:${pct}%"></div></span>
      <span class="secs">${t.max > 0 ? Math.ceil(t.remaining) + 's' : ''}</span>`;
    box.appendChild(chip);
  }
}

// ---------- game over -------------------------------------------------------
export function renderGameOver(summary, save, isRecord, canRevive, canReviveCoins) {
  $('over-score').textContent = fmt(summary.score);
  $('over-height').textContent = fmt(summary.metres) + ' m';
  $('over-coins').textContent = fmt(summary.coins);
  $('over-best').textContent = fmt(save.bestScore);
  $('over-record').classList.toggle('hidden', !isRecord);
  const rev = $('btn-revive');
  rev.disabled = !canRevive;
  rev.classList.toggle('disabled', !canRevive);
  const revC = $('btn-revive-coins');
  revC.disabled = !canReviveCoins;
  revC.textContent = canRevive ? `or revive for ${REVIVE_COST_COINS} coins` : 'Revive already used this run';
}

// ---------- tutorial --------------------------------------------------------
let tutStep = 0;
export function renderTutorial(step) {
  tutStep = step;
  const s = TUTORIAL_STEPS[step];
  $('tut-count').textContent = `${step + 1} / ${TUTORIAL_STEPS.length}`;
  $('tut-title').textContent = s.title;
  $('tut-text').textContent = s.text;
  const img = $('tut-img');
  img.src = `assets/sprites/${s.sprite}.webp`;
  const dots = $('tut-dots');
  dots.innerHTML = '';
  TUTORIAL_STEPS.forEach((_, i) => {
    const d = document.createElement('i');
    if (i === step) d.className = 'on';
    dots.appendChild(d);
  });
  $('btn-tut-next').textContent = step === TUTORIAL_STEPS.length - 1 ? "LET'S GO!" : 'NEXT';
}
export function currentTutorialStep() { return tutStep; }

// ---------- HUD visibility / hint -------------------------------------------
export function setHudVisible(on) {
  $('hud').classList.toggle('hidden', !on);
  $('touchzone').classList.toggle('hidden', !on);
  if (on) {
    const hint = $('touch-hint');
    hint.classList.remove('fade');
    setTimeout(() => hint.classList.add('fade'), 3000);
  }
}

export function setLoadProgress(p, text) {
  $('load-bar-fill').style.width = Math.round(p * 100) + '%';
  if (text) $('load-text').textContent = text;
}

/** Confirmation dialog. Resolves true / false. */
export function confirmDialog(text) {
  return new Promise((resolve) => {
    $('confirm-text').textContent = text;
    showModal('modal-confirm');
    const yes = $('btn-confirm-yes');
    const no = $('btn-confirm-no');
    const done = (v) => {
      hideModal('modal-confirm');
      yes.onclick = null;
      no.onclick = null;
      resolve(v);
    };
    yes.onclick = () => done(true);
    no.onclick = () => done(false);
  });
}

// ---------- worlds (endless height bands, read-only) ----------------------

/** Lists the seven worlds with their height ranges and progress. The run has no end, so none is locked. */
export function renderStages(save) {
  const list = $('stage-list');
  list.innerHTML = '';
  const best = save.bestHeight || 0;
  for (const w of WORLDS) {
    const startM = (w.from - 1) * BAND_M;
    const endM = w.to * BAND_M;
    const reached = best >= startM;
    const pct = Math.max(0, Math.min(100, Math.round((best - startM) / (endM - startM) * 100)));
    const range = w.n === WORLDS.length ? `${startM} m and up` : `${startM} – ${endM} m`;
    const row = document.createElement('div');
    row.className = 'row-card';
    row.innerHTML = `
      <div class="txt">
        <b>World ${w.n} · ${w.name}</b>
        <span>${range} · ${reached ? 'reached' : 'ahead'}</span>
        <div class="bar thin"><div style="width:${pct}%"></div></div>
      </div>`;
    list.appendChild(row);
  }
}
