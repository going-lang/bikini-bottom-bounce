// Object pooling plus pooled particles and floating text. Everything is capped so
// effects can never grow without bound.

export class Pool {
  constructor(make, maxFree = 400) {
    this.make = make;
    this.free = [];
    this.maxFree = maxFree;
  }
  get() { return this.free.length ? this.free.pop() : this.make(); }
  put(o) { if (this.free.length < this.maxFree) this.free.push(o); }
}

const TAU = Math.PI * 2;

export class Fx {
  constructor(max = 240) {
    this.max = max;
    this.reduced = false;
    this.parts = [];
    this.partPool = new Pool(() => ({}));
    this.texts = [];
    this.textPool = new Pool(() => ({}), 40);
  }

  /** World-space burst. o: { color, speed, life, size, shape: 'dot'|'bubble'|'spark', up, g } */
  burst(x, y, n, o = {}) {
    if (this.reduced) n = Math.ceil(n / 2);
    for (let i = 0; i < n && this.parts.length < this.max; i++) {
      const p = this.partPool.get();
      const a = Math.random() * TAU;
      const sp = (o.speed || 140) * (0.35 + 0.65 * Math.random());
      p.x = x; p.y = y;
      p.vx = Math.cos(a) * sp;
      p.vy = Math.sin(a) * sp + (o.up || 0);
      p.max = (o.life || 0.5) * (0.7 + 0.6 * Math.random());
      p.life = p.max;
      p.size = (o.size || 4) * (0.7 + 0.6 * Math.random());
      p.color = o.color || '#ffffff';
      p.shape = o.shape || 'dot';
      p.g = o.g || 0;
      this.parts.push(p);
    }
  }

  /** Floating text (score popups, banners). */
  text(x, y, str, color = '#ffffff', size = 22) {
    if (this.texts.length >= 14) return;
    const t = this.textPool.get();
    t.x = x; t.y = y; t.str = str; t.color = color; t.size = size;
    t.max = 0.9; t.life = 0.9;
    this.texts.push(t);
  }

  update(dt) {
    if (dt <= 0) return;
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.parts[i] = this.parts[this.parts.length - 1];
        this.parts.pop();
        this.partPool.put(p);
        continue;
      }
      p.vy += p.g * dt;
      p.vx *= 1 - 1.6 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.life -= dt;
      t.y -= 40 * dt;
      if (t.life <= 0) {
        this.texts[i] = this.texts[this.texts.length - 1];
        this.texts.pop();
        this.textPool.put(t);
      }
    }
  }

  clear() {
    for (const p of this.parts) this.partPool.put(p);
    for (const t of this.texts) this.textPool.put(t);
    this.parts.length = 0;
    this.texts.length = 0;
  }

  draw(ctx, camTop) {
    for (const p of this.parts) {
      const a = Math.max(0, p.life / p.max);
      ctx.globalAlpha = a;
      if (p.shape === 'bubble') {
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(p.x, p.y - camTop, p.size, 0, TAU);
        ctx.stroke();
      } else if (p.shape === 'spark') {
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x - p.size * 0.5, p.y - camTop - p.size * 0.5, p.size, p.size);
      } else {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y - camTop, p.size, 0, TAU);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
    for (const t of this.texts) {
      ctx.globalAlpha = Math.max(0, Math.min(1, t.life / t.max * 1.6));
      ctx.font = `${t.size}px Impact, "Arial Black", sans-serif`;
      ctx.textAlign = 'center';
      ctx.lineWidth = 5;
      ctx.strokeStyle = 'rgba(40,20,0,0.85)';
      const sy = t.y - camTop;
      ctx.strokeText(t.str, t.x, sy);
      ctx.fillStyle = t.color;
      ctx.fillText(t.str, t.x, sy);
    }
    ctx.globalAlpha = 1;
    ctx.textAlign = 'left';
  }
}
