// App controller: boots assets, owns the save data, connects the game engine to menus,
// and runs the single requestAnimationFrame loop.
import { loadSave, writeSave, clearSave, statOf } from './storage.js';
import { loadAssets } from './assets.js';
import { showRevive, setFallbackRewarded, initAds, setBannerWanted, setInsetListener, getAdInset, maybeShowAppOpen, disposeAds } from './ads.js';
import { Sound } from './audio.js';
import { Input } from './input.js';
import { Game } from './game.js';
import * as UI from './ui.js';
import { LOW_END, LOGICAL_W, LOGICAL_H, CHARACTERS, OUTFITS, EFFECTS, MISSIONS, ACHIEVEMENTS, REVIVE_COST_COINS, POWERUPS, WORLDS, stageInfo, BAND_M } from './config.js';

const $ = UI.$;
let save = loadSave();
let game = null;
let input = null;
let canvas = null;
let saveDirty = false;
let lastSave = 0;
let resetting = false;
let shopTab = 'characters';
let missionTab = 'missions';
let settingsFromPause = false;
let tutorialThenPlay = false;
let tutorialStep = 0;
let adOpen = false;
let lastHudAt = 0;
let loopErrors = 0;

// ---------- persistence ---------------------------------------------------
function persistNow() {
  if (resetting) return;
  writeSave(save);
  saveDirty = false;
  lastSave = performance.now();
}
function markDirty() { saveDirty = true; }

// ---------- layout --------------------------------------------------------
function fitStage() {
  const vw = window.innerWidth, vh = window.innerHeight;
  // the playfield fits above the ad banner (0 px when no banner is shown)
  const s = Math.min(vw / LOGICAL_W, (vh - getAdInset()) / LOGICAL_H);
  document.documentElement.style.setProperty('--s', String(Math.max(0.1, s)));
  const dpr = Math.min(window.devicePixelRatio || 1, LOW_END ? 2 : 3);
  if (canvas) {
    canvas.width = Math.round(LOGICAL_W * s * dpr);
    canvas.height = Math.round(LOGICAL_H * s * dpr);
    const ctx = canvas.getContext('2d');
    ctx.setTransform(s * dpr, 0, 0, s * dpr, 0, 0);
  }
  // full-screen backdrop: the environment covers the whole viewport (cover fit), centred on the
  // playfield. It is soft art, so it renders at no more than 1.5x to keep low-end phones smooth.
  const bg = $('bg-canvas');
  if (bg) {
    const bgDpr = Math.min(dpr, LOW_END ? 1 : 1.5);
    const cover = Math.max(vw / LOGICAL_W, vh / LOGICAL_H);
    const ox = (vw - LOGICAL_W * cover) / 2, oy = (vh - LOGICAL_H * cover) / 2;
    bg.width = Math.round(vw * bgDpr);
    bg.height = Math.round(vh * bgDpr);
    bg.style.width = vw + 'px';
    bg.style.height = vh + 'px';
    if (game) game.setBackdrop(bg, [cover * bgDpr, 0, 0, cover * bgDpr, ox * bgDpr, oy * bgDpr]);
  }
}

// ---------- achievements --------------------------------------------------
function checkAchievements() {
  let changed = false;
  for (const a of ACHIEVEMENTS) {
    if (save.achievements.includes(a.id)) continue;
    const val = statOf(save, a.stat);
    if (val >= a.target) {
      save.achievements.push(a.id);
      changed = true;
      UI.toast(`Achievement unlocked: ${a.name}`, 2600);
      Sound.play('unlock');
    }
  }
  if (changed) markDirty();
}

// ---------- screens -------------------------------------------------------
function currentLoadout() {
  const ch = CHARACTERS.find((c) => c.id === save.equipped.character);
  return {
    character: ch && ch.art ? ch.id : 'spongebob',
    outfit: save.equipped.outfit,
    effect: save.equipped.effect,
  };
}

function hideAllModals() {
  for (const id of ['modal-pause', 'modal-over', 'modal-tutorial', 'modal-confirm', 'modal-ad']) UI.hideModal(id);
}

function goMenu() {
  if (game) game.quit();
  hideAllModals();
  UI.setHudVisible(false);
  UI.showScreen('menu');
  UI.renderMenu(save);
  Sound.duck(false);
  Sound.startMusic(0);
}

function startRun() {
  hideAllModals();
  game.setStage(stageInfo(1));
  game.setLoadout(currentLoadout());
  game.setSettings({ sensitivity: save.settings.sensitivity, reducedEffects: save.settings.reducedEffects });
  input.swap = !!save.settings.swap;
  UI.showScreen('game');
  UI.setHudVisible(true);
  game.start();
  markDirty();
}

function onPlay() {
  Sound.play('click');
  if (!save.tutorialDone) {
    openTutorial(true);
  } else {
    startRun();
  }
}

function pauseGame() {
  if (!game.pause()) return;
  UI.showModal('modal-pause');
  persistNow();
}

function resumeGame() {
  if (!game.resume()) return;
  UI.hideModal('modal-pause');
}

// ---------- Android back button (native app only) -------------------------------
// Back moves one step up. It never ends a rewarded ad, closes the confirm dialog, resumes a
// paused run, closes other overlays to the menu, pauses a live run, and exits only from the
// main menu. The App plugin is present only in the Android build with @capacitor/app.
let nativeApp = null;

function handleBackButton() {
  const open = [...document.querySelectorAll('.modal:not(.hidden)')].map((m) => m.id);
  if (open.includes('modal-ad')) return;                 // a rewarded ad must play to the end
  if (open.includes('modal-confirm')) { $('btn-confirm-no').click(); return; }
  if (open.includes('modal-pause')) { resumeGame(); return; }
  if (open.length) { goMenu(); return; }                 // game over, tutorial, etc.
  const screen = UI.currentScreenName();
  if (screen === 'game') {
    if (game && game.state === 'playing') pauseGame();
    return;
  }
  if (screen === 'menu' || screen === 'splash' || screen === 'loading') {
    if (nativeApp) nativeApp.exitApp();
    return;
  }
  goMenu();                                              // shop, missions, stages, settings, how-to
}

// App Open ads may show on resume only from these menu-type screens. Never during a run
// (game, pause, game over), never over a modal, never on the splash or loading screens.
const APP_OPEN_SCREENS = ['menu', 'stages', 'shop', 'missions', 'settings', 'howto'];
function onAppResume() {
  if (!booted) return;
  if (!APP_OPEN_SCREENS.includes(UI.currentScreenName())) return;
  if (document.querySelector('.modal:not(.hidden)')) return;
  maybeShowAppOpen('resume');
}

function setupAndroidBack() {
  const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
  if (!App) return;                                      // browser, or @capacitor/app not installed
  nativeApp = App;
  App.addListener('backButton', handleBackButton).catch((e) => console.warn('back button not wired', e && e.message));
  App.addListener('appStateChange', (state) => { if (state && state.isActive) onAppResume(); })
    .catch((e) => console.warn('app state not wired', e && e.message));
}

// ---------- tutorial -------------------------------------------------------
function openTutorial(thenPlay) {
  tutorialThenPlay = thenPlay;
  tutorialStep = 0;
  UI.renderTutorial(0);
  UI.showModal('modal-tutorial');
}

function finishTutorial() {
  UI.hideModal('modal-tutorial');
  save.tutorialDone = true;
  markDirty();
  persistNow();
  if (tutorialThenPlay) startRun();
}

// ---------- rewarded ad --------------------------------------------------------
// Ad calls go through js/ads.js. In the browser (or before the AdMob plugin is installed)
// this stand-in ad is used. It resolves true only when the player waits out the timer.
function simulatedRewardedAd() {
  return new Promise((resolve) => {
    if (adOpen) { resolve(false); return; }
    adOpen = true;
    let t = 3;
    const timerEl = $('ad-timer');
    const claim = $('btn-ad-close');
    timerEl.textContent = String(t);
    claim.classList.add('hidden');
    UI.showModal('modal-ad');
    const tick = setInterval(() => {
      t--;
      timerEl.textContent = String(Math.max(0, t));
      if (t <= 0) {
        clearInterval(tick);
        timerEl.textContent = '';
        claim.classList.remove('hidden');
      }
    }, 1000);
    claim.onclick = () => {
      claim.onclick = null;
      clearInterval(tick);
      UI.hideModal('modal-ad');
      adOpen = false;
      resolve(true);
    };
  });
}

// ---------- game over and revive ---------------------------------------------
let lastRecord = false;

// ---------- worlds (endless) ----------------------------------------------
function openStages() {
  UI.renderStages(save);
  UI.showScreen('stages');
}

function onGameOver(sum) {
  const isRecord = sum.score > 0 && sum.score > save.bestScore;
  lastRecord = isRecord;
  save.runs++;
  if (sum.score > save.bestScore) save.bestScore = sum.score;
  if (sum.metres > save.bestHeight) save.bestHeight = sum.metres;
  if (sum.zone > save.bestZone) save.bestZone = sum.zone;
  if (sum.enemiesHit === 0 && sum.metres >= BAND_M) save.noHitRuns++;
  checkAchievements();
  persistNow();
  Sound.play(isRecord ? 'highscore' : 'gameover');
  UI.setHudVisible(false);
  if (game && game.stage) $('over-stage').textContent = `${game.stage.worldName} · ${Math.floor(sum.metres)} M`;
  const canRevive = !sum.reviveUsed;
  const canReviveCoins = canRevive && save.coins >= REVIVE_COST_COINS;
  UI.renderGameOver(sum, save, isRecord, canRevive, canReviveCoins);
  UI.showModal('modal-over');
}

function afterRevive(message) {
  UI.hideModal('modal-over');
  UI.setHudVisible(true);
  save.revives++;
  checkAchievements();
  markDirty();
  UI.toast(message);
}

let reviveInFlight = false;
async function reviveWithAd() {
  if (reviveInFlight) return;
  Sound.play('click');
  reviveInFlight = true;
  try {
    const result = await showRevive();
    if (result === 'rewarded') {
      if (game.revive()) afterRevive('Revived! Back in the run.');
    } else if (result === 'closed') {
      UI.toast('Watch the whole ad to revive');
    } else {
      UI.toast('No ad available right now. Try again or revive with coins.');
    }
  } finally {
    reviveInFlight = false;
  }
}

function reviveWithCoins() {
  Sound.play('click');
  if (save.coins < REVIVE_COST_COINS) {
    UI.toast(`You need ${REVIVE_COST_COINS} coins to revive`);
    return;
  }
  if (game.revive()) {
    save.coins -= REVIVE_COST_COINS;
    persistNow();
    afterRevive('Revived for ' + REVIVE_COST_COINS + ' coins!');
  }
}

// ---------- shop ---------------------------------------------------------------
function findItem(tab, id) {
  const list = tab === 'characters' ? CHARACTERS : tab === 'outfits' ? OUTFITS : EFFECTS;
  return list.find((i) => i.id === id);
}

const EQUIP_FIELD = { characters: 'character', outfits: 'outfit', effects: 'effect' };
const OWN_FIELD = { characters: 'characters', outfits: 'outfits', effects: 'effects' };

function renderShopView() {
  UI.renderShop(save, shopTab, { buy: buyItem, equip: equipItem });
}

function buyItem(tab, id) {
  const item = findItem(tab, id);
  if (!item) return;
  const owned = save.owned[OWN_FIELD[tab]];
  if (owned.includes(id)) return;
  if (tab === 'characters' && !item.art) {
    UI.toast(`${item.name} artwork is coming soon`);
    return;
  }
  const cur = item.currency === 'premium' ? 'premium' : 'coins';
  if (save[cur] < item.price) {
    UI.toast(`Not enough ${cur === 'premium' ? 'golden spatulas' : 'coins'} (need ${item.price - save[cur]} more)`);
    Sound.play('click');
    return;
  }
  save[cur] -= item.price;
  owned.push(id);
  save.equipped[EQUIP_FIELD[tab]] = id;
  save.purchases++;
  Sound.play('purchase');
  UI.toast(`Unlocked ${item.name}!`);
  checkAchievements();
  markDirty();
  persistNow();
  renderShopView();
}

function equipItem(tab, id) {
  const item = findItem(tab, id);
  if (!item) return;
  if (!save.owned[OWN_FIELD[tab]].includes(id)) return;
  save.equipped[EQUIP_FIELD[tab]] = id;
  if (game) game.setLoadout(currentLoadout());
  Sound.play('click');
  markDirty();
  persistNow();
  renderShopView();
}

// ---------- missions ---------------------------------------------------------
function claimMission(id) {
  const m = MISSIONS.find((x) => x.id === id);
  if (!m || save.missionsClaimed.includes(id)) return;
  const val = statOf(save, m.stat);
  if (val < m.target) return;
  save.missionsClaimed.push(id);
  if (m.reward.coins) save.coins += m.reward.coins;
  if (m.reward.premium) save.premium += m.reward.premium;
  Sound.play('unlock');
  UI.toast('Mission reward claimed!');
  markDirty();
  persistNow();
  UI.renderMissions(save, { claim: claimMission });
}

function showMissionTab(tab) {
  missionTab = tab;
  document.querySelectorAll('[data-mtab]').forEach((b) => b.classList.toggle('active', b.dataset.mtab === tab));
  $('missions-list').classList.toggle('hidden', tab !== 'missions');
  $('achievements-list').classList.toggle('hidden', tab !== 'achievements');
  $('stats-list').classList.toggle('hidden', tab !== 'stats');
  UI.renderMissions(save, { claim: claimMission });
}

// ---------- settings ---------------------------------------------------------
function openSettings(fromPause) {
  settingsFromPause = fromPause;
  UI.renderSettings(save);
  UI.showScreen('settings');
}

function closeSettings() {
  Sound.play('click');
  if (settingsFromPause) {
    settingsFromPause = false;
    UI.showScreen('game');
    UI.setHudVisible(false);
    UI.showModal('modal-pause');
    UI.setHudVisible(true);
    return;
  }
  UI.renderMenu(save);
  UI.showScreen('menu');
  persistNow();
}

async function resetProgress() {
  const yes = await UI.confirmDialog('Erase all coins, unlocks, records and achievements on this device? This cannot be undone.');
  if (!yes) return;
  resetting = true;
  clearSave();
  UI.toast('Progress reset. Reloading...');
  setTimeout(() => window.location.reload(), 600);
}

// ---------- binding ----------------------------------------------------------
function bindUI() {
  document.querySelectorAll('[data-go]').forEach((el) => {
    el.addEventListener('click', () => {
      Sound.play('click');
      const to = el.dataset.go;
      if (to === 'menu') { UI.renderMenu(save); UI.showScreen('menu'); persistNow(); }
      else if (to === 'shop') { shopTab = 'characters'; setShopTabs(); renderShopView(); UI.showScreen('shop'); }
      else if (to === 'missions') { UI.showScreen('missions'); showMissionTab('missions'); }
      else if (to === 'stages') openStages();
      else if (to === 'achievements') { UI.showScreen('missions'); showMissionTab('achievements'); }
      else if (to === 'settings') openSettings(false);
      else if (to === 'howto') UI.showScreen('howto');
    });
  });
  document.querySelectorAll('[data-action="play"]').forEach((el) => el.addEventListener('click', onPlay));

  document.querySelectorAll('[data-tab]').forEach((el) => el.addEventListener('click', () => {
    Sound.play('click');
    shopTab = el.dataset.tab;
    setShopTabs();
    renderShopView();
  }));
  document.querySelectorAll('[data-mtab]').forEach((el) => el.addEventListener('click', () => {
    Sound.play('click');
    showMissionTab(el.dataset.mtab);
  }));

  $('btn-start').addEventListener('click', () => {
    Sound.unlock();
    Sound.startMusic(0);
    Sound.play('click');
    UI.showScreen('menu');
    UI.renderMenu(save);
    maybeShowAppOpen('launch');
  });
  $('btn-retry').addEventListener('click', () => { boot(); });

  // pause & HUD
  $('btn-pause').addEventListener('click', () => { Sound.play('click'); pauseGame(); });
  $('btn-resume').addEventListener('click', () => { Sound.play('click'); resumeGame(); });
  $('btn-restart').addEventListener('click', () => { Sound.play('click'); startRun(); });
  $('btn-pause-settings').addEventListener('click', () => {
    Sound.play('click');
    UI.hideModal('modal-pause');
    UI.setHudVisible(false);
    openSettings(true);
  });
  $('btn-quit').addEventListener('click', () => { Sound.play('click'); persistNow(); goMenu(); });

  // game over
  $('btn-revive').addEventListener('click', reviveWithAd);
  $('btn-revive-coins').addEventListener('click', reviveWithCoins);
  $('btn-try-again').addEventListener('click', () => { Sound.play('click'); startRun(); });
  $('btn-home').addEventListener('click', () => { Sound.play('click'); persistNow(); goMenu(); });
  $('btn-splash-skip').addEventListener('click', leaveSplash);

  // tutorial
  $('btn-tut-next').addEventListener('click', () => {
    Sound.play('click');
    if (tutorialStep >= 5) { finishTutorial(); return; }
    tutorialStep++;
    UI.renderTutorial(tutorialStep);
  });
  $('btn-tut-skip').addEventListener('click', () => { Sound.play('click'); finishTutorial(); });
  $('btn-tutorial').addEventListener('click', () => { Sound.play('click'); openTutorial(false); });

  // settings
  $('settings-back').addEventListener('click', closeSettings);
  $('set-music').addEventListener('input', (e) => {
    save.settings.musicVol = Number(e.target.value);
    Sound.setVolumes({ music: save.settings.musicVol });
    UI.renderSettings(save);
    markDirty();
  });
  $('set-sfx').addEventListener('input', (e) => {
    save.settings.sfxVol = Number(e.target.value);
    Sound.setVolumes({ sfx: save.settings.sfxVol });
    UI.renderSettings(save);
    markDirty();
  });
  $('set-sfx').addEventListener('change', () => Sound.play('click'));
  $('set-sens').addEventListener('input', (e) => {
    save.settings.sensitivity = Number(e.target.value);
    if (game) game.setSettings({ sensitivity: save.settings.sensitivity });
    UI.renderSettings(save);
    markDirty();
  });
  $('set-swap').addEventListener('change', (e) => {
    save.settings.swap = e.target.checked;
    if (input) input.swap = save.settings.swap;
    markDirty();
    persistNow();
  });
  $('set-reduced').addEventListener('change', (e) => {
    save.settings.reducedEffects = e.target.checked;
    if (game) game.setSettings({ reducedEffects: save.settings.reducedEffects });
    markDirty();
    persistNow();
  });
  $('btn-reset').addEventListener('click', resetProgress);

  // lifecycle: leaving the app pauses the run and saves
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (game && game.state === 'playing') pauseGame();
      persistNow();
    }
  });
  window.addEventListener('pagehide', (e) => { persistNow(); if (!e.persisted) disposeAds(); });
  window.addEventListener('resize', fitStage);
  window.addEventListener('orientationchange', fitStage);
  document.addEventListener('contextmenu', (e) => e.preventDefault());
  UI.onScreenChange((name) => setBannerWanted(name === 'game'));
  setInsetListener(() => fitStage());
}

function setShopTabs() {
  document.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('active', b.dataset.tab === shopTab));
}

// ---------- engine setup ------------------------------------------------------
function createEngine() {
  canvas = $('game-canvas');
  input = new Input($('touchzone'), { onPause: () => {
    if (!game) return;
    if (game.state === 'playing') pauseGame();
    else if (game.state === 'paused') resumeGame();
  } });
  game = new Game(canvas, input, {
    onCoins: (n) => { save.coins += n; save.lifetimeCoins += n; markDirty(); },
    onCoinsLost: (n) => { save.coins = Math.max(0, save.coins - n); markDirty(); },
    onToken: () => { save.lifetimeTokens++; markDirty(); },
    onPremium: (n) => { save.premium += n; save.premiumCollected += n; markDirty(); },
    onPowerup: (type) => { save.powerups[type] = (save.powerups[type] || 0) + 1; save.powerupsUsed++; markDirty(); },
    onBubble: () => { save.bubbles++; markDirty(); },
    onBounce: () => { save.bounces++; markDirty(); },
    onHit: () => { save.enemiesHit++; markDirty(); },
    onDefeat: () => { save.enemiesDefeated++; markDirty(); },
    onBossDown: () => { save.bossesDefeated++; markDirty(); },
    onZone: (zi) => {
      if (zi + 1 > save.bestZone) { save.bestZone = zi + 1; markDirty(); }
      checkAchievements();
    },
    onGameOver,
  });
  game.setSettings({ sensitivity: save.settings.sensitivity, reducedEffects: save.settings.reducedEffects });
  input.swap = !!save.settings.swap;
  Sound.setVolumes({ music: save.settings.musicVol, sfx: save.settings.sfxVol });
  fitStage();
}

let booted = false;
async function boot() {
  $('load-error').classList.add('hidden');
  $('load-box').classList.remove('hidden');
  $('btn-start').classList.add('hidden');
  $('screen-loading').classList.remove('ready');
  UI.setLoadProgress(0, 'Loading Bikini Bottom...');
  try {
    await loadAssets((p) => UI.setLoadProgress(p));
    if (!booted) {
      createEngine();
      bindUI();
      setupAndroidBack();
      booted = true;
      requestAnimationFrame(frame);
    }
    UI.setLoadProgress(1, 'Ready!');
    initAds(); // native only: starts the AdMob SDK in the background (no-op in the browser)
    $('load-box').classList.add('hidden');
    $('btn-start').classList.remove('hidden');
    $('screen-loading').classList.add('ready');
  } catch (err) {
    console.error(err);
    $('load-box').classList.add('hidden');
    $('load-error').classList.remove('hidden');
  }
}

// ---------- main loop ------------------------------------------------------------
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  let dt = (now - last) / 1000;
  last = now;
  if (dt > 0.1) dt = 0.1;
  if (dt < 0) dt = 0;
  try {
    const advancing = game.state === 'playing' || game.state === 'dying';
    game.update(advancing ? dt : 0);
    game.render();
    if (game.state === 'playing' && now - lastHudAt > 100) {
      lastHudAt = now;
      UI.renderHud(game.hud());
    }
    if (saveDirty && now - lastSave > 2500) persistNow();
    loopErrors = 0;
  } catch (err) {
    // never crash the app: drop back to the menu with a message
    console.error('Game loop error', err);
    loopErrors++;
    if (loopErrors <= 3) {
      try { goMenu(); UI.toast('Something went wrong. Returning to the menu.', 3000); } catch (e2) { console.error(e2); }
    }
  }
}

// initial screen & boot: the WRLDgames splash shows first, then loading
let splashDone = false;
function leaveSplash() {
  if (splashDone) return;
  splashDone = true;
  UI.showScreen('loading');
}
setFallbackRewarded(simulatedRewardedAd); // browser stand-in until a real ad provider is installed
fitStage(); // size the playfield before the first screen shows, so the splash fits the phone
UI.showScreen('splash');
setTimeout(leaveSplash, 2600);
boot();
