// Pure physics helpers. No DOM or canvas access, so they can be unit-tested in Node.
import { PHYS, LOGICAL_W } from './config.js';

export function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
export function lerp(a, b, t) { return a + (b - a) * t; }

/**
 * Advances the player by dt seconds.
 * dir: -1 (left), 0 (none), 1 (right)
 * m: { maxSpeed, accel } multipliers (already include character/power-up effects)
 * The feet position is p.y (screen y grows downward; jumping lowers y).
 */
export function stepPlayer(p, dt, dir, m) {
  const maxSpeed = PHYS.baseMaxSpeed * m.maxSpeed;
  const accel = PHYS.baseAccel * m.accel;
  const target = dir * maxSpeed;
  // m.grip < 1 on ice: slower acceleration and slower stopping
  const rate = (dir !== 0 ? accel : PHYS.friction) * (m.grip || 1);
  const lim = rate * dt;
  p.vx += clamp(target - p.vx, -lim, lim);

  p.vy = Math.min(p.vy + PHYS.gravity * dt, PHYS.maxFall);
  p.prevY = p.y;
  p.x += p.vx * dt;
  p.y += p.vy * dt;

  // Screen wrap: leaving one side re-enters from the other.
  const L = -PHYS.wrapPad;
  const R = LOGICAL_W + PHYS.wrapPad;
  if (p.x < L) p.x += R - L;
  else if (p.x > R) p.x -= R - L;
}

/**
 * True when the player's feet cross a platform's top surface from above this step.
 * Only downward motion can land, so platforms never block upward movement.
 */
export function landedOn(p, plat) {
  if (plat.broken || plat.dead) return false;
  if (p.vy <= 0) return false;
  const top = plat.y;
  if (!(p.prevY <= top + 2 && p.y >= top)) return false;
  return Math.abs(p.x - plat.x) <= plat.w / 2 + PHYS.landHalfW;
}

export function circleRectOverlap(cx, cy, r, x0, y0, x1, y1) {
  const nx = clamp(cx, x0, x1);
  const ny = clamp(cy, y0, y1);
  const dx = cx - nx;
  const dy = cy - ny;
  return dx * dx + dy * dy <= r * r;
}

export function playerHitRect(p) {
  return {
    x0: p.x - PHYS.hitHalfW,
    y0: p.y - PHYS.hitTop,
    x1: p.x + PHYS.hitHalfW,
    y1: p.y - PHYS.hitBottom,
  };
}
