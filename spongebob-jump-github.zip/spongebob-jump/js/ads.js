// Ad service. The game talks to ads only through this module, so gameplay and UI code never
// touch the ad SDK directly.
//
// Three formats, all via @capacitor-community/admob (Android app only):
//   - Adaptive banner at the bottom of gameplay. It is drawn by the native layer above the
//     WebView, so the game is inset by the banner's height (--ad-inset) and never sits under it.
//   - Revive: rewarded interstitial. Only offered voluntarily from the game-over screen. The
//     reward is granted only after the SDK's Rewarded event (never on Dismissed alone).
//   - App open: shown only on launch and on resume to a non-run screen, with a cooldown.
//     Never during a run, a pause, a game over or a level change.
//
// In the browser (or any build without the plugin) every call is a no-op, except the revive
// stand-in that main.js registers, so the game stays fully playable there.
//
// Test vs release: AD_BUILD is 'dev' in the source. `node tools/build_www.mjs --release`
// writes 'release' into the copied www/js/ads.js, which switches to the production ad units.
// Development builds therefore always use Google's test units.
//
// Every SDK call has a timeout and a try/catch. An ad failure is logged and treated as "no
// ad"; it never blocks, freezes or crashes the game.

export const AD_BUILD = 'dev';

const TEST_UNITS = {
  // Google's published sample units. Safe for development; they never pay out.
  banner: 'ca-app-pub-3940256099942544/6300978111',
  revive: 'ca-app-pub-3940256099942544/5354046379',
  appOpen: 'ca-app-pub-3940256099942544/9257395921',
};
const LIVE_UNITS = {
  banner: 'ca-app-pub-2098402970512007/8438434150',
  revive: 'ca-app-pub-2098402970512007/8260139055',
  appOpen: 'ca-app-pub-2098402970512007/2582280270',
};
const UNITS = AD_BUILD === 'release' ? LIVE_UNITS : TEST_UNITS;

const CALL_TIMEOUT_MS = 15000;      // loads, consent, initialise, show calls
const CONSENT_FORM_TIMEOUT_MS = 180000;
const REVIVE_MAX_MS = 180000;       // hard limit on the whole revive ad
const REVIVE_AFTER_SHOW_MS = 90000; // if Dismissed never arrives after the ad was shown
const APP_OPEN_MAX_MS = 180000;
const APP_OPEN_COOLDOWN_MS = 30 * 60 * 1000; // minimum gap between App Open ads (launch counts)
const APP_OPEN_MAX_AGE_MS = 4 * 60 * 60 * 1000; // discard a preloaded App Open older than this
const QUIET_AFTER_AD_MS = 2500;     // ignore resume events right after a full-screen ad closes

const BANNER_SIZE = 'ADAPTIVE_BANNER';   // BannerAdSize enum value
const BANNER_POSITION = 'BOTTOM_CENTER'; // BannerAdPosition enum value
const BANNER_MAX_PX = 240;

const state = {
  plugin: null,
  listenersAdded: false,
  handles: [],
  initStarted: false,
  ready: false,            // consent handled and SDK initialised
  // banner
  banner: 'none',          // 'none' (not created), 'shown', 'hidden'
  bannerWanted: false,
  bannerHeight: 0,
  syncing: false,
  resync: false,
  // reward interstitial (revive)
  rewardReady: false,
  reviveBusy: false,
  reviveWait: null,
  // app open
  appOpenLoaded: false,
  appOpenLoadedAt: 0,
  appOpenLoading: false,
  appOpenShowing: false,
  appOpenTimer: null,
  lastAppOpenAt: 0,
  // shared: true while any full-screen ad is open
  fullscreenBusy: false,
  quietUntil: 0,
};

let onInsetChange = null;

// ---------- helpers ---------------------------------------------------------------

/** True inside the Capacitor native shell, false in a normal browser. */
export function isNative() {
  return !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
}

function adPlugin() {
  if (!isNative()) return null;
  if (window.Capacitor.getPlatform && window.Capacitor.getPlatform() !== 'android') return null;
  return (window.Capacitor.Plugins && window.Capacitor.Plugins.AdMob) || null;
}

function withTimeout(promise, ms, label) {
  let timer;
  const limit = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(label + ' timed out')), ms);
  });
  return Promise.race([Promise.resolve(promise), limit]).finally(() => clearTimeout(timer));
}

function warn(label, e) {
  console.warn('[ads] ' + label, e && (e.message || e));
}

/** Current height in CSS px of the banner strip at the bottom (0 when no banner is shown). */
export function getAdInset() {
  if (!state.bannerWanted || state.banner !== 'shown') return 0;
  return state.bannerHeight;
}

function applyInset() {
  const px = getAdInset();
  document.documentElement.style.setProperty('--ad-inset', px + 'px');
  if (onInsetChange) onInsetChange(px);
}

/** main.js registers a callback so the playfield is re-fitted when the banner appears or leaves. */
export function setInsetListener(fn) {
  onInsetChange = fn;
}

// ---------- listeners (registered once) -------------------------------------------

async function addListeners(p) {
  if (state.listenersAdded) return;
  state.listenersAdded = true;
  const on = async (event, fn) => {
    try {
      state.handles.push(await p.addListener(event, fn));
    } catch (e) {
      warn('listener ' + event, e);
    }
  };
  await on('bannerAdSizeChanged', (info) => {
    state.bannerHeight = Math.max(0, Math.min(BANNER_MAX_PX, Number(info && info.height) || 0));
    applyInset();
  });
  await on('bannerAdFailedToLoad', () => {
    state.bannerHeight = 0;
    applyInset();
  });
  await on('onRewardedInterstitialAdLoaded', () => { state.rewardReady = true; });
  await on('onRewardedInterstitialAdFailedToLoad', () => { state.rewardReady = false; });
  await on('onRewardedInterstitialAdReward', () => {
    if (state.reviveWait) state.reviveWait.earned = true;
  });
  await on('onRewardedInterstitialAdDismissed', () => {
    if (state.reviveWait) state.reviveWait.finish();
  });
  await on('onRewardedInterstitialAdFailedToShow', () => {
    if (state.reviveWait) { state.reviveWait.failed = true; state.reviveWait.finish(); }
  });
  await on('appOpenAdLoaded', () => { state.appOpenLoaded = true; state.appOpenLoadedAt = Date.now(); });
  await on('appOpenAdFailedToLoad', () => { state.appOpenLoaded = false; state.appOpenLoading = false; });
  await on('appOpenAdClosed', () => appOpenDone());
  await on('appOpenAdFailedToShow', () => appOpenDone());
}

// ---------- startup: consent, then one SDK initialisation -------------------------

/**
 * Call once after the game has loaded. Runs the consent check (UMP form where the law requires
 * it), initialises the SDK exactly once, then preloads the revive and App Open ads.
 * Resolves quietly in every case. In the browser it does nothing.
 */
export async function initAds() {
  if (state.initStarted) return;
  state.initStarted = true;
  const p = adPlugin();
  if (!p) return;
  state.plugin = p;
  try {
    await addListeners(p);
    let info = await withTimeout(p.requestConsentInfo(), CALL_TIMEOUT_MS, 'consent info');
    if (info && info.isConsentFormAvailable && info.status === 'REQUIRED') {
      info = await withTimeout(p.showConsentForm(), CONSENT_FORM_TIMEOUT_MS, 'consent form');
    }
    if (!info || !info.canRequestAds) {
      console.info('[ads] consent does not allow ads; ads stay off this session');
      return;
    }
    await withTimeout(p.initialize(), CALL_TIMEOUT_MS, 'initialize');
    state.ready = true;
    prepareReward();
    ensureAppOpenLoaded();
    syncBanner();
  } catch (e) {
    warn('init', e);
  }
}

// ---------- banner --------------------------------------------------------------------

/**
 * Tells the ads module whether the banner should be visible (true during a run, including
 * pause and game over; false on menus and full-screen screens). The banner is created once,
 * then hidden and resumed. It is never recreated per run.
 */
export function setBannerWanted(wanted) {
  state.bannerWanted = !!wanted;
  syncBanner();
}

async function syncBanner() {
  const p = state.plugin;
  if (!p || !state.ready) { applyInset(); return; }
  if (state.syncing) { state.resync = true; return; }
  state.syncing = true;
  try {
    do {
      state.resync = false;
      const want = state.bannerWanted;
      if (want && state.banner === 'none') {
        await withTimeout(p.showBanner({ adId: UNITS.banner, adSize: BANNER_SIZE, position: BANNER_POSITION, margin: 0 }), CALL_TIMEOUT_MS, 'showBanner');
        state.banner = 'shown';
      } else if (want && state.banner === 'hidden') {
        await withTimeout(p.resumeBanner(), CALL_TIMEOUT_MS, 'resumeBanner');
        state.banner = 'shown';
      } else if (!want && state.banner === 'shown') {
        await withTimeout(p.hideBanner(), CALL_TIMEOUT_MS, 'hideBanner');
        state.banner = 'hidden';
      }
    } while (state.resync);
  } catch (e) {
    // no banner this time; the game keeps its full height. The next setBannerWanted call retries.
    warn('banner', e);
  } finally {
    state.syncing = false;
    applyInset();
  }
}

/** Removes the banner and every listener. Called only when the page is really unloading. */
export async function disposeAds() {
  const p = state.plugin;
  if (!p) return;
  for (const h of state.handles) {
    try { await h.remove(); } catch (e) { /* already gone */ }
  }
  state.handles = [];
  state.listenersAdded = false;
  if (state.banner !== 'none') {
    try { await p.removeBanner(); } catch (e) { /* already gone */ }
  }
  state.banner = 'none';
  state.bannerHeight = 0;
  applyInset();
}

// ---------- revive: rewarded interstitial ---------------------------------------------

async function prepareReward() {
  const p = state.plugin;
  if (!p || !state.ready || state.rewardReady) return;
  try {
    await withTimeout(p.prepareRewardInterstitialAd({ adId: UNITS.revive }), CALL_TIMEOUT_MS, 'prepare reward');
    state.rewardReady = true;
  } catch (e) {
    state.rewardReady = false;
    warn('prepare reward', e);
  }
}

/**
 * Shows the voluntary revive ad. Resolves to:
 *   'rewarded'    the player earned the reward (grant the revive)
 *   'closed'      the ad was closed without the reward (grant nothing)
 *   'unavailable' no ad could be shown right now (grant nothing)
 * In the browser, the stand-in registered with setFallbackRewarded is used instead.
 */
let fallbackRewarded = null;
export function setFallbackRewarded(fn) { fallbackRewarded = fn; }

export async function showRevive() {
  const p = state.plugin || adPlugin();
  if (!p) {
    if (!fallbackRewarded) return 'unavailable';
    return (await fallbackRewarded()) ? 'rewarded' : 'closed';
  }
  if (!state.ready || state.reviveBusy || state.fullscreenBusy) return 'unavailable';
  state.reviveBusy = true;
  state.fullscreenBusy = true;
  try {
    if (!state.rewardReady) {
      await prepareReward();
      if (!state.rewardReady) return 'unavailable';
    }
    return await new Promise((resolve) => {
      let settled = false;
      let fallback = null;
      const wait = {
        earned: false,   // the reward event was received
        failed: false,   // the ad could not be shown
        finish: () => {
          if (settled) return;
          settled = true;
          clearTimeout(hardStop);
          clearTimeout(fallback);
          state.reviveWait = null;
          resolve(wait.earned ? 'rewarded' : wait.failed ? 'unavailable' : 'closed');
        },
      };
      const hardStop = setTimeout(wait.finish, REVIVE_MAX_MS);
      state.reviveWait = wait;
      state.rewardReady = false;
      withTimeout(p.showRewardInterstitialAd({ adId: UNITS.revive }), REVIVE_MAX_MS, 'show reward')
        .then((item) => {
          // the reward event normally sets earned first; the resolved item counts too
          if (item) wait.earned = true;
          // Dismissed normally ends the ad. Fallback in case it never arrives.
          if (!settled) fallback = setTimeout(wait.finish, REVIVE_AFTER_SHOW_MS);
        })
        .catch((e) => {
          warn('show reward', e);
          wait.failed = true;
          wait.finish();
        });
    });
  } catch (e) {
    warn('revive', e);
    return 'unavailable';
  } finally {
    state.reviveBusy = false;
    state.fullscreenBusy = false;
    state.quietUntil = Date.now() + QUIET_AFTER_AD_MS;
    prepareReward(); // preload the next one
  }
}

// ---------- app open ------------------------------------------------------------------

async function ensureAppOpenLoaded() {
  const p = state.plugin;
  if (!p || !state.ready || state.appOpenLoading) return;
  if (state.appOpenLoaded && Date.now() - state.appOpenLoadedAt < APP_OPEN_MAX_AGE_MS) return;
  state.appOpenLoading = true;
  state.appOpenLoaded = false;
  try {
    await withTimeout(p.loadAppOpen({ adId: UNITS.appOpen }), CALL_TIMEOUT_MS, 'load app open');
    state.appOpenLoaded = true;
    state.appOpenLoadedAt = Date.now();
  } catch (e) {
    warn('load app open', e);
  } finally {
    state.appOpenLoading = false;
  }
}

function appOpenDone() {
  if (!state.appOpenShowing) return;
  state.appOpenShowing = false;
  state.fullscreenBusy = false;
  state.appOpenLoaded = false;
  state.quietUntil = Date.now() + QUIET_AFTER_AD_MS;
  clearTimeout(state.appOpenTimer);
  state.appOpenTimer = null;
  ensureAppOpenLoaded(); // reload after each close
}

/**
 * Shows an App Open ad if it is allowed right now. Call it only from a launch or from a resume
 * to a menu screen (never during a run, pause, game over or level change). Returns quietly
 * when the cooldown, a full-screen ad, or a missing/stale ad rules it out.
 * @param {'launch'|'resume'} reason
 */
export async function maybeShowAppOpen(reason) {
  const p = state.plugin;
  if (!p || !state.ready) return false;
  if (state.fullscreenBusy || state.appOpenShowing) return false;
  if (Date.now() < state.quietUntil) return false;
  if (state.lastAppOpenAt && Date.now() - state.lastAppOpenAt < APP_OPEN_COOLDOWN_MS) return false;
  if (!state.appOpenLoaded || Date.now() - state.appOpenLoadedAt >= APP_OPEN_MAX_AGE_MS) {
    ensureAppOpenLoaded();
    return false;
  }
  try {
    const res = await withTimeout(p.isAppOpenLoaded({ adId: UNITS.appOpen }), CALL_TIMEOUT_MS, 'isAppOpenLoaded');
    if (!res || !res.value) { state.appOpenLoaded = false; ensureAppOpenLoaded(); return false; }
  } catch (e) {
    warn('isAppOpenLoaded', e);
    return false;
  }
  state.appOpenShowing = true;
  state.fullscreenBusy = true;
  state.lastAppOpenAt = Date.now();
  state.appOpenTimer = setTimeout(appOpenDone, APP_OPEN_MAX_MS);
  try {
    await withTimeout(p.showAppOpen({ adId: UNITS.appOpen }), CALL_TIMEOUT_MS, 'showAppOpen');
    return true;
  } catch (e) {
    warn('showAppOpen (' + reason + ')', e);
    appOpenDone();
    return false;
  }
}
