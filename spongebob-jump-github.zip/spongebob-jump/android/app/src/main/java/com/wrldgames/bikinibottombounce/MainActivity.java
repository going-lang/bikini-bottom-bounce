package com.wrldgames.bikinibottombounce;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
