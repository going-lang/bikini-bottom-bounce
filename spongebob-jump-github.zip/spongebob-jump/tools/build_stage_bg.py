"""Builds one seamless vertical background tile per stage from the reference panels.

Input : assets/bg/panels/stage_NN.jpg (panels cut from the environment sheets)
Output: assets/bg/stage_NN.jpg (540 px wide, panel mirrored top-to-bottom so the tile loops
        without a visible seam)
"""
import glob, os
import numpy as np
from PIL import Image

W = 540
for path in sorted(glob.glob('assets/bg/panels/stage_*.jpg')):
    name = os.path.basename(path)
    im = Image.open(path).convert('RGB')
    a = np.asarray(im).astype(int)
    bg = np.median(np.concatenate([a[:, 0], a[:, -1]]), axis=0)
    # trim grey side margins that some sheets carry around the panel
    colsDiff = (np.abs(a - bg).max(axis=2) > 24).mean(axis=0)
    cols = np.where(colsDiff > 0.5)[0]
    if cols.size > 40:
        im = im.crop((int(cols[0]), 0, int(cols[-1]) + 1, im.height))
    h = round(im.height * W / im.width)
    panel = im.resize((W, h), Image.LANCZOS)
    flipped = panel.transpose(Image.FLIP_TOP_BOTTOM)
    tile = Image.new('RGB', (W, h * 2))
    tile.paste(panel, (0, 0))
    tile.paste(flipped, (0, h))
    out = name.replace('stage_', 'stage_')
    tile.save(os.path.join('assets/bg', out), quality=82, optimize=True)
    print(out, tile.size)
