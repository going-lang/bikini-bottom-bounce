// Copies the runtime game into www/, the folder Capacitor packages into the app.
// Only what the browser loads is copied: index.html, css/, js/ and assets/ (except
// assets/reference, which is kept only as source material for the extraction tools).
// Run with: node tools/build_www.mjs   (npm run build:www)
// Release: node tools/build_www.mjs --release   (production AdMob units; see js/ads.js)
import { cpSync, rmSync, mkdirSync, existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(root, 'www');
const SKIP = [join(root, 'assets', 'reference')];

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
for (const item of ['index.html', 'css', 'js', 'assets']) {
  const src = join(root, item);
  if (!existsSync(src)) throw new Error(`missing ${item}`);
  cpSync(src, join(out, item), {
    recursive: true,
    filter: (p) => !SKIP.some((s) => resolve(p) === s || resolve(p).startsWith(s + '/')),
  });
}
// --release: the copied ads.js uses the production ad units. Development builds keep the test units.
if (process.argv.includes('--release')) {
  const adsFile = join(out, 'js', 'ads.js');
  const src = readFileSync(adsFile, 'utf8');
  const marked = "export const AD_BUILD = 'dev';";
  if (!src.includes(marked)) throw new Error('ads.js: AD_BUILD marker not found; cannot set release units');
  writeFileSync(adsFile, src.replace(marked, "export const AD_BUILD = 'release';"));
  console.log('release build: ads.js uses production ad units');
}
console.log(`www/ ready: ${relative(root, out)} (index.html, css, js, assets)`);
