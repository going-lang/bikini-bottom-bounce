"""
Splits the supplied reference sheets into individual transparent sprites.

* Background is removed by flood-filling from the crop border using the sheet's
  background colour, so highlights enclosed inside a sprite survive.
* Each sprite is cropped from an explicit box (coordinates measured on the
  supplied reference sheets) so neighbouring items never bleed in.

Usage: python3 tools/extract_sprites.py
Output: assets/sprites/*.png
"""
import os
import numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage

HERE = os.path.dirname(os.path.abspath(__file__))
UPLOADS = os.path.expanduser('~/uploads')
OUT = os.path.join(HERE, '..', 'assets', 'sprites')
os.makedirs(OUT, exist_ok=True)

SHEETS = {
    'chars': ('1791406286697.jpg', 18, {
        # name: (x0, y0, x1, y1)
        'sb_wobble': (144, 96, 349, 376),   # top-left: lean / wobble
        'sb_idle':   (521, 138, 891, 669),  # centre: hero idle pose
        'sb_jump':   (998, 51, 1307, 376),  # top-right: arms up, rising
        'sb_land':   (141, 492, 375, 720),  # bottom-left: landing / squash
        'sb_hurt':   (1048, 445, 1302, 719) # bottom-right: startled / hurt / fall
    }),
    'platforms': ('1791406354124.jpg', 34, {
        'plat_sand':          (30, 120, 358, 300),
        'plat_moving':        (405, 122, 720, 338),   # includes teal direction arrows
        'plat_special_jelly': (770, 90, 975, 348),
        'plat_breakable':     (1028, 112, 1346, 328),
        'plat_bounce':        (58, 468, 330, 640),
        'plat_large':         (394, 396, 1002, 644),
        'deco_tiki':          (1050, 396, 1322, 668)
    }),
    'collect': ('1791406471741.jpg', 30, {
        'coin':         (84, 276, 304, 492),
        'bubble':       (362, 276, 576, 492),
        'jelly_token':  (632, 288, 786, 480),
        'spatula':      (844, 250, 1054, 520),
        'treasure':     (1098, 276, 1338, 516)
    }),
    'enemies': ('1791406553554.jpg', 34, {
        'enemy_jelly':         (76, 56, 280, 352),
        'enemy_jelly_fast':    (326, 50, 592, 336),
        'enemy_urchin':        (602, 48, 958, 336),
        'enemy_jelly_large':   (968, 46, 1360, 734),
        'enemy_mine':          (42, 392, 342, 706),
        'enemy_bubble_hazard': (360, 416, 610, 670),
        'enemy_rock':          (658, 354, 900, 656)
    }),
}

def remove_bg(img, tol):
    arr = np.asarray(img.convert('RGB')).astype(np.int16)
    h, w, _ = arr.shape
    corners = np.array([arr[0, 0], arr[0, w - 1], arr[h - 1, 0], arr[h - 1, w - 1]])
    bg = np.median(corners, axis=0)
    dist = np.abs(arr - bg).max(axis=2)
    lab, _ = ndimage.label(dist <= tol)
    border = np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))
    border = border[border != 0]
    bg_mask = np.isin(lab, border)
    alpha = np.where(bg_mask, 0, 255).astype(np.uint8)
    alpha_img = Image.fromarray(alpha, 'L').filter(ImageFilter.MinFilter(3))
    rgba = img.convert('RGBA')
    rgba.putalpha(alpha_img)
    return rgba

def main():
    for key, (src, tol, boxes) in SHEETS.items():
        img = Image.open(os.path.join(UPLOADS, src))
        rgba = remove_bg(img, tol)
        for name, box in boxes.items():
            crop = rgba.crop(box)
            # trim fully transparent margin
            bbox = crop.getbbox()
            if bbox:
                crop = crop.crop(bbox)
            crop.save(os.path.join(OUT, name + '.png'), optimize=True)
            print(f'{name:22s} {crop.size}')

if __name__ == '__main__':
    main()
