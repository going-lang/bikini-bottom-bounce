"""Extract the 8 power-up icons from assets/reference/powerups_reference.jpg.

Each icon is cropped from its grid cell (labels and numbers excluded), the flat
gray sheet background is removed by flood-filling from the crop edges, and the
result is trimmed to the artwork. Original colours, outlines and glows are kept.
Run: python3 tools/extract_powerups.py
"""
from collections import deque
from PIL import Image
import numpy as np
import os

SRC = 'assets/reference/powerups_reference.jpg'
OUT = 'assets/powerups'
COLS, CELL_W = 4, 352
# (key, col, row, crop_y0, crop_y1, [number-label boxes to erase])
ITEMS = [
    ('super_bounce',  0, 0,  62, 340),
    ('bubble_shield', 1, 0,  62, 340),
    ('jelly_magnet',  2, 0,  62, 340),
    ('speed_boost',   3, 0,  62, 340),
    ('double_coins',  0, 1, 405, 698),
    ('extra_life',    1, 1, 405, 698),
    ('slow_motion',   2, 1, 405, 698),
    ('mega_bounce',   3, 1, 405, 698),
]
TOL = 30  # max per-channel distance from the sheet background


def label_boxes(col, row):
    """Boxes (x0, y0, x1, y1) covering the printed step number of a cell."""
    x = col * CELL_W + 8          # printed numbers sit near the cell's top-left corner
    y = 40 if row == 0 else 404
    return [(x, y, x + 76, y + 46)]


def main():
    img = np.asarray(Image.open(SRC).convert('RGB')).astype(np.int16)
    H, W, _ = img.shape
    border = np.concatenate([img[0], img[-1], img[:, 0], img[:, -1]])
    bg = np.median(border, axis=0)
    os.makedirs(OUT, exist_ok=True)

    for key, col, row, y0, y1 in ITEMS:
        x0, x1 = col * CELL_W + 4, (col + 1) * CELL_W - 4
        crop = img[y0:y1, x0:x1].copy()
        h, w, _ = crop.shape
        bgmask = (np.abs(crop - bg) <= TOL).all(axis=2)
        # erase printed step number
        for bx0, by0, bx1, by1 in label_boxes(col, row):
            ax0, ay0 = max(bx0 - x0, 0), max(by0 - y0, 0)
            ax1, ay1 = min(bx1 - x0, w), min(by1 - y0, h)
            bgmask[ay0:ay1, ax0:ax1] = True
        # flood fill: background pixels connected to the crop border
        removed = np.zeros_like(bgmask)
        q = deque()
        for x in range(w):
            for y in (0, h - 1):
                if bgmask[y, x] and not removed[y, x]:
                    removed[y, x] = True; q.append((y, x))
        for y in range(h):
            for x in (0, w - 1):
                if bgmask[y, x] and not removed[y, x]:
                    removed[y, x] = True; q.append((y, x))
        while q:
            y, x = q.popleft()
            for ny, nx in ((y+1, x), (y-1, x), (y, x+1), (y, x-1)):
                if 0 <= ny < h and 0 <= nx < w and bgmask[ny, nx] and not removed[ny, nx]:
                    removed[ny, nx] = True; q.append((ny, nx))
        alpha = np.where(removed, 0, 255).astype(np.uint8)
        rgba = np.dstack([crop.clip(0, 255).astype(np.uint8), alpha])
        im = Image.fromarray(rgba, 'RGBA')
        bbox = im.getbbox()
        pad = 4
        bbox = (max(bbox[0]-pad, 0), max(bbox[1]-pad, 0), min(bbox[2]+pad, w), min(bbox[3]+pad, h))
        im = im.crop(bbox)
        path = os.path.join(OUT, f'pu_{key}.png')
        im.save(path, optimize=True)
        print(path, im.size)


if __name__ == '__main__':
    main()
