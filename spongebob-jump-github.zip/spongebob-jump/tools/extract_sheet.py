"""Generic sprite extractor for reference sheets.

Splits a sheet into separate items (connected components on a dilated foreground
mask), removes the flat background connected to each crop's edges, and writes one
transparent PNG per item plus a numbered index image for naming.

Usage: python3 tools/extract_sheet.py <sheet.jpg> <out_prefix> [--min-area N] [--min-h N]
Outputs: assets/sprites/<out_prefix>_NN.png (scratch index in /home/user/sheets/)
"""
import argparse, os
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage
from collections import deque

TOL = 28  # per-channel distance from the sheet background


def flood_clear(bgmask):
    h, w = bgmask.shape
    removed = np.zeros_like(bgmask)
    q = deque()
    for x in range(w):
        for y in (0, h - 1):
            if bgmask[y, x] and not removed[y, x]:
                removed[y, x] = True; q.append((y, x))
    for y in range(h):
        for x in (0, w - 1):
            if bgmask[y, x] and not removed[y, x]:
                removed[y, x] = True; q.append((y, x))
    while q:
        y, x = q.popleft()
        for ny, nx in ((y+1, x), (y-1, x), (y, x+1), (y, x-1)):
            if 0 <= ny < h and 0 <= nx < w and bgmask[ny, nx] and not removed[ny, nx]:
                removed[ny, nx] = True; q.append((ny, nx))
    return removed


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sheet'); ap.add_argument('prefix')
    ap.add_argument('--min-area', type=int, default=900)
    ap.add_argument('--min-h', type=int, default=40)
    ap.add_argument('--dilate', type=int, default=9)
    a = ap.parse_args()

    img = np.asarray(Image.open(a.sheet).convert('RGB')).astype(np.int16)
    H, W, _ = img.shape
    border = np.concatenate([img[0], img[-1], img[:, 0], img[:, -1]])
    bg = np.median(border, axis=0)
    fg = (np.abs(img - bg) > TOL).any(axis=2)
    dil = ndimage.binary_dilation(fg, iterations=a.dilate)
    lab, n = ndimage.label(dil)

    items = []
    for sl in ndimage.find_objects(lab):
        if sl is None:
            continue
        y0, y1 = sl[0].start, sl[0].stop
        x0, x1 = sl[1].start, sl[1].stop
        sub = fg[y0:y1, x0:x1]
        area = int(sub.sum())
        rows_hit = np.where(sub.any(axis=1))[0]
        cols_hit = np.where(sub.any(axis=0))[0]
        if area == 0 or rows_hit.size == 0:
            continue
        # tight bounds of the real artwork (dilation excluded)
        ty0, ty1 = y0 + rows_hit[0], y0 + rows_hit[-1] + 1
        tx0, tx1 = x0 + cols_hit[0], x0 + cols_hit[-1] + 1
        h, w = ty1 - ty0, tx1 - tx0
        if area < a.min_area or h < a.min_h:
            continue  # sparkles, dots and text labels
        items.append((ty0, ty1, tx0, tx1, area))

    # reading order: group into rows by centre y, then left to right
    items.sort(key=lambda t: (t[0] + t[1]) / 2)
    rows, cur, last = [], [], None
    for it in items:
        cy = (it[0] + it[1]) / 2
        if last is not None and cy - last > 140:
            rows.append(cur); cur = []
        cur.append(it); last = cy
    if cur: rows.append(cur)
    ordered = []
    for r in rows:
        ordered += sorted(r, key=lambda t: t[2])

    os.makedirs('assets/sprites', exist_ok=True)
    os.makedirs('/home/user/sheets', exist_ok=True)
    tiles = []
    for i, (y0, y1, x0, x1, area) in enumerate(ordered, 1):
        pad = 6
        ay0, ay1 = max(y0 - pad, 0), min(y1 + pad, H)
        ax0, ax1 = max(x0 - pad, 0), min(x1 + pad, W)
        crop = img[ay0:ay1, ax0:ax1]
        bgm = (np.abs(crop - bg) <= TOL).all(axis=2)
        cleared = flood_clear(bgm)
        alpha = np.where(cleared, 0, 255).astype(np.uint8)
        im = Image.fromarray(np.dstack([crop.clip(0, 255).astype(np.uint8), alpha]), 'RGBA')
        bb = im.getbbox()
        if bb is None:
            continue
        im = im.crop(bb)
        name = f"{a.prefix}_{i:02d}.png"
        im.save(os.path.join('assets/sprites', name), optimize=True)
        tiles.append((i, name, im))
        print(name, im.size, 'src', (x0, y0, x1 - x0, y1 - y0))

    # numbered index for naming (scratch, outside the project)
    cell = 220
    cols = 4
    rows_n = (len(tiles) + cols - 1) // cols
    sheet = Image.new('RGB', (cols * cell, max(rows_n, 1) * cell), (120, 170, 200))
    d = ImageDraw.Draw(sheet)
    for i, name, im in tiles:
        t = im.copy(); t.thumbnail((cell - 30, cell - 40))
        k = i - 1
        x = (k % cols) * cell + 10; y = (k // cols) * cell + 10
        sheet.paste(t, (x, y), t)
        d.text((x, y + cell - 30), f"{i:02d} {name}", fill=(0, 0, 0))
    out = f"/home/user/sheets/{a.prefix}_index.png"
    sheet.save(out)
    print('index', out, len(tiles), 'items')


if __name__ == '__main__':
    main()
