// Headless playability test: runs an autopilot with near-perfect steering through
// procedurally generated levels and checks it never falls. Run: node tools/test_generator.mjs
import { makeRow, makeStartRow, mulberry32, zoneIndexFor } from '../js/generator.js';
import { stepPlayer, landedOn } from '../js/physics.js';
import { PHYS, PLATFORMS, LOGICAL_W } from '../js/config.js';

const START_Y = 820;
const SEEDS = 40;
const TARGET_METRES = 1500;
let failures = 0;
let worstGap = 0, worstDx = 0, totalRows = 0;

for (let seed = 1; seed <= SEEDS; seed++) {
  const rng = mulberry32(seed * 7919);
  const rows = [makeStartRow(START_Y)];
  // generate rows up to the target height
  while (true) {
    const prev = rows[rows.length - 1];
    const metres = Math.max(0, (START_Y - prev.y) / 10);
    if (metres >= TARGET_METRES) break;
    const row = makeRow(prev, metres, rng, zoneIndexFor(metres));
    const dy = prev.y - row.y;
    const dxNominal = Math.abs(row.x - prev.x);
    worstGap = Math.max(worstGap, dy);
    worstDx = Math.max(worstDx, dxNominal);
    rows.push(row);
  }
  totalRows += rows.length;

  // autopilot simulation
  const p = { x: LOGICAL_W / 2, y: START_Y, prevY: START_Y, vx: 0, vy: -PHYS.jumpVel };
  let target = 1; // index of the row we are steering towards
  let t = 0;
  const dt = 1 / 120;
  let ok = true;
  let lastLanded = 0;
  const platX = (r) => r.kind === 'moving' ? r.x + Math.sin(t * r.speed) * r.amp : r.x;
  const plats = rows.map((r) => ({ x: r.x, y: r.y, w: r.w || 112, broken: false, dead: false, r }));
  const cur = { idx: 0 };
  for (let step = 0; step < 120 * 900; step++) {
    t += dt;
    // steer toward the next target platform (moving ones use their live x)
    const tgt = rows[target];
    if (!tgt) break; // reached the top of the generated level
    const tx = platX(tgt);
    const dx = tx - p.x;
    const dir = Math.abs(dx) > 6 ? Math.sign(dx) : 0;
    stepPlayer(p, dt, dir, { maxSpeed: 1, accel: 1 });
    // update live positions of moving platforms
    for (const pl of plats) if (pl.r.kind === 'moving') pl.x = platX(pl.r);
    for (const pl of plats) {
      if (pl.y < p.y - 800) continue;
      if (landedOn(p, pl)) {
        const idx = plats.indexOf(pl);
        if (idx >= target - 1 && idx < rows.length) {
          const mult = pl.r.mult || 1;
          p.vy = -PHYS.jumpVel * mult;
          lastLanded = idx;
          if (idx === target - 1 || idx >= target) target = Math.max(target, idx + 1);
        }
        break;
      }
    }
    // fell below the last platform we were aiming for => failure
    if (p.y > rows[Math.max(0, lastLanded)].y + 260) {
      ok = false;
      console.log(`seed ${seed}: FELL at ~${Math.round((START_Y - rows[lastLanded].y) / 10)} m (target row ${target})`);
      break;
    }
    if (target >= rows.length - 2) break;
  }
  if (!ok) failures++;
}

console.log(`rows generated: ${totalRows} (avg ${(totalRows / SEEDS).toFixed(0)} per run)`);
console.log(`worst vertical gap: ${worstGap.toFixed(1)} px (base apex ${(PHYS.jumpVel ** 2 / (2 * PHYS.gravity)).toFixed(0)} px)`);
console.log(`worst horizontal offset: ${worstDx.toFixed(1)} px`);
console.log(failures === 0 ? `PASS: autopilot survived all ${SEEDS} generated levels` : `FAIL: ${failures} runs fell`);
process.exit(failures ? 1 : 0);
