"""
Measures the yellow sponge body in each SpongeBob pose so the game can draw
every pose at the same body size. Writes assets/sprites/pose_meta.json.
"""
import json, os
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SPR = os.path.join(HERE, '..', 'assets', 'sprites')
POSES = ['sb_idle', 'sb_jump', 'sb_land', 'sb_hurt', 'sb_wobble']

meta = {}
for name in POSES:
    im = Image.open(os.path.join(SPR, name + '.png')).convert('RGBA')
    a = np.asarray(im).astype(int)
    h, w = a.shape[:2]
    r, g, b, al = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    yellow = (r > 200) & (g > 170) & (b < 140) & (al > 128)
    # use the upper 60% of the sprite (the sponge sits above the legs)
    mask = yellow.copy()
    mask[int(h * 0.6):, :] = False
    # the sponge is a wide solid block; arms/hands are thin. Keep only rows and
    # columns whose yellow density is high, so arms are excluded from the measure.
    row_counts = mask.sum(axis=1)
    rows = np.nonzero(row_counts > 0.45 * row_counts.max())[0]
    ry0, ry1 = rows.min(), rows.max()
    band = mask[ry0:ry1 + 1, :]
    col_counts = band.sum(axis=0)
    cols = np.nonzero(col_counts > 0.45 * col_counts.max())[0]
    cx0, cx1 = cols.min(), cols.max()
    x0, x1 = float(cx0), float(cx1)
    y0, y1 = float(ry0), float(ry1)
    meta[name] = {
        'w': w, 'h': h,
        'sw': float(x1 - x0),        # sponge width (px in sprite)
        'cx': float((x0 + x1) / 2),  # sponge centre x
        'st': float(y0),             # sponge top y
        'sb': float(y1),             # sponge bottom y
    }
    print(name, meta[name])

with open(os.path.join(SPR, 'pose_meta.json'), 'w') as f:
    json.dump(meta, f, indent=2)
