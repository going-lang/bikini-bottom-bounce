# Extracted sprite map (Phase 1)

Cut from the reference sheets with `tools/extract_sheet.py`. Each file is one reusable sprite.
Numbers are the item order on the sheet index (reading order, left to right, top to bottom).

| Final file | Sheet | Item |
|---|---|---|
| char_patrick.png | #7 pose sheet | Patrick, front idle (05) |
| char_sandy.png | #7 | Sandy, standing (06) |
| char_squidward.png | #7 | Squidward, standing (28) |
| char_mrkrabs.png | #7 | Mr. Krabs, front (21) |
| char_gary.png | #7 | Gary, front (29) |
| outfit_superhero.png | #9 outfits | Super Sponge (01) |
| outfit_pirate.png | #9 | Pirate Captain (03) |
| outfit_astronaut.png | #9 | Astronaut (05) |
| outfit_ninja.png | #9 | Ninja (07) |
| outfit_beach.png | #9 | Beach Day (09) |
| outfit_sports.png | #9 | Hoops Star (12) |
| outfit_royal.png | #9 | Royal King (14). Label fragment removed. |
| outfit_winter.png | #9 | Winter Cozy (16) |
| outfit_space.png | #9 | Space Ranger (18) |
| outfit_golden.png | #9 | Golden Sponge (20) |
| fx_bubble_trail.png | #10 effects | Bubble trail (02) |
| fx_jellyfish_trail.png | #10 | Jellyfish spark (03) |
| fx_golden_coin_trail.png | #10 | Golden coin trail (04) |
| fx_star_trail.png | #10 | Star trail (05) |
| fx_rainbow_trail.png | #10 | Rainbow trail (06) |
| fx_lightning_trail.png | #10 | Lightning (07) |
| fx_water_trail.png | #10 | Water splash (08) |
| fx_ocean_aura.png | #10 | Ocean aura (09) |
| fx_golden_aura.png | #10 | Golden glow (10) |
| fx_cosmic_trail.png | #10 | Cosmic trail (11) |
| plat_spring.png | #16 platforms | Spring bounce (01). Art only, not yet wired to gameplay. |
| plat_moving.png | #16 | Moving platform with arrows (02) |
| plat_moving_vertical.png | #16 | Vertical moving platform (03). Art only. |
| plat_breakable.png | #16 | Breakable crate (04) |
| plat_disappearing.png | #16 | Disappearing bubble platform (05) |
| plat_boost.png | #16 | Boost fan platform (06) |
| plat_ice.png | #16 | Ice platform (07) |
| plat_bubble_bounce.png | #16 | Bubble bounce (08). Art only. |
| hazard_spike_platform.png | #16 | Spike block (09) |
| hazard_falling_rock.png | #16 | Falling rock (10). Art only, game uses enemy_rock. |
| hazard_rotating_blade.png | #16 | Rotating blade (11) |
| hazard_sea_mine.png | #16 | Sea mine (12). Art only, game uses enemy_mine. |
| hazard_jelly_zap.png | #16 | Jelly zap (13) |
| chest_wood.png | #18 chests | Wooden chest (01). Stage clear reward. |
| chest_anchor.png | #18 | Anchor chest (02). Milestone stage reward. |
| chest_pearl.png | #18 | Pearl chest (03). Stage 35 reward. |
| chest_daily.png | #18 | Timer chest (04). Art only. |
| pick_coinpile.png | #18 | Coin pile (05) |
| pick_spatula.png | #18 | Golden spatula (06). Art only, game uses spatula.png. |
| pick_token.png | #18 | Jellyfish token (07). Art only, game uses jelly_token.png. |
| pick_star.png | #18 | Star (08) |
| pick_gem.png | #18 | Gem (09). Art only. |
| pick_key.png | #18 | Seahorse key (10). Art only. |
| pick_bonusbox.png | #18 | Bonus box (11). Art only. |
| pick_treasure.png | #18 | Treasure heap (12). Art only. |

Splash: `assets/ui/splash_wrldgames.jpg` is reference #20 (1791415216760.jpg), used as-is.

## Environments and main menu (master update)

| Reference file | Content | Used as |
|---|---|---|
| 1791415952835.jpg | Stages 6–10 environments | assets/bg/stage_06..10.jpg |
| 1791416154444.jpg | Stages 11–15 environments | assets/bg/stage_11..15.jpg |
| 1791416161416.jpg | Stages 16–20 environments | assets/bg/stage_16..20.jpg |
| 1791416136616.jpg | Stages 21–25 environments | assets/bg/stage_21..25.jpg |
| 1791416143136.jpg | Stages 26–30 environments | assets/bg/stage_26..30.jpg |
| 1791416148757.jpg | Stages 31–35 environments | assets/bg/stage_31..35.jpg |
| 1791415894799.jpg | Main menu | assets/ui/menu_reference.jpg (shown as-is; live values and buttons overlaid) |

Stages 1–5 have no supplied environment and keep the zone backgrounds.
Each stage tile is built by `tools/build_stage_bg.py` from the five panels on each sheet (panels are cut at the grey separator rows, top to bottom in stage order). The tile is the panel at 540 px wide, mirrored so it loops without a seam.


## Milestone boss art (reference #15, `1791414904207.jpg`)

Extracted with `tools/extract_sheet.py`; captions removed.

| Final file | Item | Used for |
|---|---|---|
| boss_giant_jellyfish.png | Giant Jellyfish (01) | Stage 10, King Jellyfish's Buzz |
| boss_elite_jellyfish.png | Elite Jellyfish (02) | Stage 30, Ghostly Galleon |
| boss_giant_sea_urchin.png | Giant Sea Urchin (03) | Art only |
| boss_angry_bubble.png | Angry Bubble Creature (04) | Stage 25, The Dirty Bubble's Menace |
| boss_rock_guardian_teal.png | Rock Bottom Guardian, teal (05) | Art only |
| boss_treasure_guardian.png | Treasure Guardian (06) | Not assigned (replaced by the generated lobster) |
| boss_larry_lobster.png | Generated lobster (not in the uploads; see MANIFEST.md) | Boss key 20, Larry's Lobster Lift |
| boss_deep_sea_guardian.png | Deep Sea Guardian (07) | Stage 5, Plankton's Kelp Forest |
| boss_rock_guardian_dark.png | Rock Bottom Guardian, dark (08) | Stage 15, The Tattletale Strangler |
| boss_final_ocean.png | Final Ocean Boss (09) | Stage 35, Man Ray's Revenge |
