# Reference manifest

Every uploaded reference, what it shows, and where it is used. Files live in `assets/reference/`
(copy the originals from `/home/user/uploads/`).

| # | File | Shows | Status |
|---|------|-------|--------|
| 1 | 1791406286697.jpg | SpongeBob pose sheet (5 poses) | In use (sprites `sb_*`) |
| 2 | 1791406354124.jpg | Platform sheet (8 items) | In use (`plat_*`) |
| 3 | 1791406408056.jpg | Zone 1 Bikini Bottom background | In use (`zone1_bikini_bottom`) |
| 4 | 1791406471741.jpg | Collectibles and power-up sheet | In use (`coin`, `bubble`, `jelly_token`, `spatula`, `treasure`) |
| 5 | 1791406553554.jpg | Enemy sheet | In use (`enemy_*`) |
| 6 | 1791406619902.jpg | Power-up icons (8) | In use (`assets/powerups/pu_*`) |
| 7 | 1791414191909.jpg | Patrick, Sandy, Squidward, Mr. Krabs, Gary pose sheet | **New.** Real art for the five placeholder characters |
| 8 | 1791414312379.jpg | Character shop UI (portrait) | **New.** Layout reference for the shop |
| 9 | 1791414412770.jpg | Outfit sheet (10 outfits) | **New.** Outfit art |
| 10 | 1791414458085.jpg | Effect sheet (10 trails and auras) | **New.** Effect art |
| 11 | 1791414565392.jpg | Missions and achievements UI | **New.** Layout reference |
| 12 | 1791414627018.jpg | Game over and revive UI | **New.** Layout reference |
| 13 | 1791414685037.jpg | Tutorial and mobile controls layout | **New.** Controls and HUD reference |
| 14 | 1791414839835.jpg | Platform difficulty patterns (10) | **New.** Generator reference |
| 15 | 1791414904207.jpg | Enemies and bosses (9) | **New.** Enemy and boss art |
| 16 | 1791414977678.jpg | Special platforms and gameplay obstacles | **New.** Platform and hazard art |
| 17 | 1791415032426.jpg | Stage map, world map, stage complete, reward UI | **New.** Stage-flow UI reference |
| 18 | 1791415086722.jpg | Treasure chests and rewards | **New.** Chest and reward art |
| 19 | 1791415136888.jpg | Logos, loading screens, app icon, splash | **New.** Branding reference |
| 20 | 1791415216760.jpg | WRLDgames opening screen | **New.** Opening screen |
| 21 | 1791415269251.jpg | 35-stage progression map | **New.** Stage order and milestone bosses |
| 22 | 1791415894799.jpg | Main menu artwork (portrait, PLAY and nav) | In use (`assets/ui/menu_reference.jpg`, `.menu-art`) |
| 23 | 1791415952835.jpg | Stage environments 6 to 10 (Jellyfish Fields) | In use (`assets/bg/stage_06`–`stage_10`) |
| 24 | 1791416136616.jpg | Stage environments 31 to 35 (Mermaid Man's Lair) | In use (`assets/bg/stage_31`–`stage_35`) |
| 25 | 1791416143136.jpg | Stage environments 26 to 30 (Flying Dutchman's Shipwreck) | In use (`assets/bg/stage_26`–`stage_30`) |
| 26 | 1791416148757.jpg | Stage environment panels (tall sheet, labels not legible at index size) | In use (`assets/bg/`, cut by `tools/build_stage_bg.py`) |
| 27 | 1791416154444.jpg | Stage environments 11 to 15 (Rock Bottom) | In use (`assets/bg/stage_11`–`stage_15`) |
| 28 | 1791416161416.jpg | Stage environments 16 to 20 (Goo Lagoon) | In use (`assets/bg/stage_16`–`stage_20`) |

Reference #15 (`1791414904207.jpg`) is used for boss art: nine items extracted as `assets/sprites/boss_*.png`. See `SPRITE_MAP.md`.

## Missing references

- **Audio direction:** no audio reference was uploaded. Music and SFX are procedural placeholders (`js/audio.js`). Replace them when licensed audio is supplied.
- **Zone backgrounds 2 to 5** (`assets/backgrounds/zone2`–`zone5`): their source is not recorded in the uploads. They are used as fallbacks and tinted per world.
- **Stage 35 "ultimate" design:** the progression map (#21) gives its name only; the stage uses the standard layout with its milestone boss.
- **Boss names without matching art:** the progression map names seven milestone bosses; reference #15 has nine items with different names. Mapping: Plankton's Kelp Forest → Deep Sea Guardian; King Jellyfish's Buzz → Giant Jellyfish; The Tattletale Strangler → Rock Bottom Guardian (dark); Larry's Lobster Lift → Treasure Guardian (no lobster art exists, so this is the closest available); The Dirty Bubble's Menace → Angry Bubble Creature; Ghostly Galleon → Elite Jellyfish; Man Ray's Revenge → Final Ocean Boss.
- **Unused boss art:** Rock Bottom Guardian (teal) and Giant Sea Urchin (`boss_rock_guardian_teal`, `boss_giant_sea_urchin`) are extracted but not assigned to a milestone boss.

## Generated references (added after the original uploads)

- **Larry's Lobster boss (progression map #21, milestone 20):** no uploaded reference shows a lobster, so the art was generated to match reference #15's cartoon style. Raw image: `assets/reference/generated/larry_lobster_boss_raw.png` (flat grey background). Cut-out sprite: `assets/sprites/boss_larry_lobster.png` (transparent). It replaces the Treasure Guardian stand-in for stage/boss key 20. `boss_treasure_guardian.png` stays in the sprites folder but is no longer assigned.

## GUI direction references (supplied for the visual pass)

Files are matched to the sheet order in the attachment. Each is the visual target for its screens.

| # | File | Contents | Used for |
|---|------|----------|----------|
| 29 | 1791415136888.jpg | Logos (main "Bikini Bottom Bounce!" and alternate "Vertical Venture"), loading screens (16:9 and with progress area), app icon, splash screen | Main logo (chosen by user), loading screen, app icon, splash |
| 30 | 1791414627018.jpg | Game over and revive screens, button sheet | Game over, revive |
| 31 | 1791414565392.jpg | Missions and achievements screens | Missions, achievements |
| 32 | 1791414685037.jpg | Game UI sheet: tutorial callouts, mobile controls layout, HUD | HUD, controls |
| 33 | 1791414312379.jpg | Character shop | Shop |

Decisions from the user: main logo "Bikini Bottom Bounce!" on the menu and loading screen. Premium currency stays as golden spatulas (the shop sheet shows gems; layout is followed, currency name is not changed).

Note: the wood plank tones are drawn in CSS (css/reference-theme.css). An earlier plank crop from the missions sheet was discarded because it contained reference text and a green button edge.
